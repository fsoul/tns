-- MySQL dump 10.11
--
-- Host: localhost    Database: t1pool
-- ------------------------------------------------------
-- Server version	5.0.88

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_mode`
--

DROP TABLE IF EXISTS `access_mode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_mode` (
  `id` int(11) NOT NULL,
  `access_mode_name` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_mode`
--

LOCK TABLES `access_mode` WRITE;
/*!40000 ALTER TABLE `access_mode` DISABLE KEYS */;
INSERT INTO `access_mode` VALUES (1,'Everyone has an access'),(2,'Only listed groups has an access');
/*!40000 ALTER TABLE `access_mode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `var` varchar(50) NOT NULL default '',
  `val` text,
  `description` varchar(150) default NULL,
  `sortOrder` int(11) default '0',
  `lang_code` char(2) NOT NULL default '',
  PRIMARY KEY  (`var`,`lang_code`),
  KEY `config_language_code_idx` (`lang_code`),
  CONSTRAINT `config_ibfk_1` FOREIGN KEY (`lang_code`) REFERENCES `language` (`language_code`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES ('abesent_browser_lang_aforward_target_url','a:2:{s:4:\"link\";s:21:\"test1.tns.2kgroup.com\";s:9:\"link_type\";s:3:\"url\";}','',0,''),('absent_browser_language_autoforwarding','1','',0,''),('alias_rule','<%:language%>/<%:page_folder%>/<%:page_name%>.<%:page_type%>','System alias creation rule',11,''),('alias_rule_example','<%:language%>/<%:page_folder%>/<%:page_name%>.<%:page_type%>','Example of system alias creation rule',11,''),('antispam_security','1','',0,''),('change_frequency','weekly','',0,''),('default_active_period','5','default_active_period',0,''),('ee_cache_html','','',0,''),('error_handle','a:3:{i:1;a:13:{i:8;s:1:\"1\";i:1024;s:1:\"1\";i:2048;s:1:\"1\";i:2;s:1:\"1\";i:32;s:1:\"1\";i:128;s:1:\"1\";i:512;s:1:\"1\";i:1;s:1:\"1\";i:4;s:1:\"1\";i:16;s:1:\"1\";i:64;s:1:\"1\";i:256;s:1:\"1\";i:4096;s:1:\"1\";}i:2;a:13:{i:8;s:1:\"0\";i:1024;s:1:\"0\";i:2048;s:1:\"0\";i:2;s:1:\"1\";i:32;s:1:\"1\";i:128;s:1:\"1\";i:512;s:1:\"1\";i:1;s:1:\"1\";i:4;s:1:\"1\";i:16;s:1:\"1\";i:64;s:1:\"1\";i:256;s:1:\"1\";i:4096;s:1:\"1\";}i:3;a:13:{i:8;s:1:\"0\";i:1024;s:1:\"0\";i:2048;s:1:\"0\";i:2;s:1:\"0\";i:32;s:1:\"0\";i:128;s:1:\"0\";i:512;s:1:\"0\";i:1;s:1:\"0\";i:4;s:1:\"0\";i:16;s:1:\"0\";i:64;s:1:\"0\";i:256;s:1:\"0\";i:4096;s:1:\"0\";}}','',0,''),('error_pages','a:25:{i:400;a:4:{s:2:\"id\";i:400;s:11:\"description\";s:11:\"Bad Request\";s:9:\"page_type\";i:2;s:5:\"value\";s:23:\"Error 400 - Bad Request\";}i:401;a:4:{s:2:\"id\";i:401;s:11:\"description\";s:12:\"Unauthorized\";s:9:\"page_type\";i:2;s:5:\"value\";s:24:\"Error 401 - Unauthorized\";}i:402;a:4:{s:2:\"id\";i:402;s:11:\"description\";s:16:\"Payment Required\";s:9:\"page_type\";i:2;s:5:\"value\";s:28:\"Error 402 - Payment Required\";}i:403;a:4:{s:2:\"id\";s:3:\"403\";s:11:\"description\";s:9:\"Forbidden\";s:9:\"page_type\";s:1:\"0\";s:5:\"value\";s:2:\"67\";}i:404;a:4:{s:2:\"id\";s:3:\"404\";s:11:\"description\";s:9:\"Not Found\";s:9:\"page_type\";s:1:\"0\";s:5:\"value\";s:2:\"63\";}i:405;a:4:{s:2:\"id\";i:405;s:11:\"description\";s:18:\"Method Not Allowed\";s:9:\"page_type\";i:2;s:5:\"value\";s:30:\"Error 405 - Method Not Allowed\";}i:406;a:4:{s:2:\"id\";i:406;s:11:\"description\";s:14:\"Not Acceptable\";s:9:\"page_type\";i:2;s:5:\"value\";s:26:\"Error 406 - Not Acceptable\";}i:407;a:4:{s:2:\"id\";i:407;s:11:\"description\";s:29:\"Proxy Authentication Required\";s:9:\"page_type\";i:2;s:5:\"value\";s:41:\"Error 407 - Proxy Authentication Required\";}i:408;a:4:{s:2:\"id\";i:408;s:11:\"description\";s:15:\"Request Timeout\";s:9:\"page_type\";i:2;s:5:\"value\";s:27:\"Error 408 - Request Timeout\";}i:409;a:4:{s:2:\"id\";i:409;s:11:\"description\";s:8:\"Conflict\";s:9:\"page_type\";i:2;s:5:\"value\";s:20:\"Error 409 - Conflict\";}i:410;a:4:{s:2:\"id\";i:410;s:11:\"description\";s:4:\"Gone\";s:9:\"page_type\";i:2;s:5:\"value\";s:16:\"Error 410 - Gone\";}i:411;a:4:{s:2:\"id\";i:411;s:11:\"description\";s:15:\"Length Required\";s:9:\"page_type\";i:2;s:5:\"value\";s:27:\"Error 411 - Length Required\";}i:412;a:4:{s:2:\"id\";i:412;s:11:\"description\";s:19:\"Precondition Failed\";s:9:\"page_type\";i:2;s:5:\"value\";s:31:\"Error 412 - Precondition Failed\";}i:413;a:4:{s:2:\"id\";i:413;s:11:\"description\";s:24:\"Request Entity Too Large\";s:9:\"page_type\";i:2;s:5:\"value\";s:36:\"Error 413 - Request Entity Too Large\";}i:414;a:4:{s:2:\"id\";i:414;s:11:\"description\";s:20:\"Request-URI Too Long\";s:9:\"page_type\";i:2;s:5:\"value\";s:32:\"Error 414 - Request-URI Too Long\";}i:415;a:4:{s:2:\"id\";i:415;s:11:\"description\";s:22:\"Unsupported Media Type\";s:9:\"page_type\";i:2;s:5:\"value\";s:34:\"Error 415 - Unsupported Media Type\";}i:416;a:4:{s:2:\"id\";i:416;s:11:\"description\";s:31:\"Requested Range Not Satisfiable\";s:9:\"page_type\";i:2;s:5:\"value\";s:43:\"Error 416 - Requested Range Not Satisfiable\";}i:417;a:4:{s:2:\"id\";i:417;s:11:\"description\";s:18:\"Expectation Failed\";s:9:\"page_type\";i:2;s:5:\"value\";s:30:\"Error 417 - Expectation Failed\";}i:500;a:4:{s:2:\"id\";i:500;s:11:\"description\";s:21:\"Internal Server Error\";s:9:\"page_type\";i:2;s:5:\"value\";s:33:\"Error 500 - Internal Server Error\";}i:501;a:4:{s:2:\"id\";i:501;s:11:\"description\";s:15:\"Not Implemented\";s:9:\"page_type\";i:2;s:5:\"value\";s:27:\"Error 501 - Not Implemented\";}i:502;a:4:{s:2:\"id\";i:502;s:11:\"description\";s:11:\"Bad Gateway\";s:9:\"page_type\";i:2;s:5:\"value\";s:23:\"Error 502 - Bad Gateway\";}i:503;a:4:{s:2:\"id\";i:503;s:11:\"description\";s:19:\"Service Unavailable\";s:9:\"page_type\";i:2;s:5:\"value\";s:31:\"Error 503 - Service Unavailable\";}i:504;a:4:{s:2:\"id\";i:504;s:11:\"description\";s:15:\"Gateway Timeout\";s:9:\"page_type\";i:2;s:5:\"value\";s:27:\"Error 504 - Gateway Timeout\";}i:505;a:4:{s:2:\"id\";i:505;s:11:\"description\";s:26:\"HTTP Version Not Supported\";s:9:\"page_type\";i:2;s:5:\"value\";s:38:\"Error 505 - HTTP Version Not Supported\";}i:600;a:4:{s:2:\"id\";i:600;s:11:\"description\";s:23:\"Check if DNS is enabled\";s:9:\"page_type\";i:2;s:5:\"value\";s:35:\"Error 600 - Check if DNS is enabled\";}}',NULL,0,''),('google_analytics','<script type=\"text/javascript\">\r\nvar gaJsHost = ((\"https:\" == document.location.protocol) ? \"https://ssl.\" : \"http://www.\");\r\ndocument.write(unescape(\"%3Cscript src=\'\" + gaJsHost + \"google-analytics.com/ga.js\' type=\'text/javascript\'%3E%3C/script%3E\"));\r\n</script>\r\n<script type=\"text/javascript\">\r\ntry {\r\nvar pageTracker = _gat._getTracker(\"UA-12923004-1\");\r\npageTracker._trackPageview();\r\n} catch(err) {}</script>','Google Analytics Code',30,''),('language_autoforwarding','','',0,''),('live','180002','Activity Timeout',1,''),('logfile_maxsize','2097152','Maximal size of log file in bytes',51,''),('logfile_stop_reset','0','What to do if log file size reache logfile_maxsize (Stop loging/Reset file)',52,''),('login_expiration_period','60','',0,''),('mail_character_set','iso-8859-1','mail_character_set',0,''),('MAX_CHARS','200','Max chars in short description',3,''),('MAX_ROWS_IN_ADMIN','20','Max rows in admin',4,''),('object_alias_rule','<%:language%>/<%:object_folder%>/<%:object_name%>/<%:object_view%>/<%:object_id%>.html','object alias rule',0,''),('object_alias_rule_example','<%:language%>/<%:object_folder%>/<%:object_name%>/<%:object_view%>/<%:object_id%>.html','object alias rule',0,''),('object_folder','object','object identificator',0,''),('pass_contain_letters','1','password must contain letters from a-zA-Z',0,''),('pass_contain_letters_with_diff_case','1','password must contains letters with different case',0,''),('pass_contain_numbers','','password must contain numbers from 0-9',0,''),('pass_min_8_symbol','1','password must be minimal 8 characters',0,''),('pass_not_have_login_inside','1','password must not have login inside password (even if typed in different case)',0,''),('search_enable_search_for_website','1','',0,''),('search_exclude_html_tags','1','',0,''),('search_max_chars_page_content','100','',0,''),('search_max_chars_page_keywords','100','',0,''),('search_max_chars_page_name','100','',0,''),('search_max_chars_page_url','100','',0,''),('search_media_library','1','',0,''),('search_minimal_characters_to_search','3','',0,''),('search_page_content','1','',0,''),('search_page_keywords','1','',0,''),('search_page_name','1','',0,''),('search_page_title','1','',0,''),('search_rate_media_library','1','',0,''),('search_rate_page_content','1','',0,''),('search_rate_page_keywords','5','',0,''),('search_rate_page_name','15','',0,''),('search_rate_page_title','10','',0,''),('search_rate_user_content','0','',0,''),('search_show_page_content','1','',0,''),('search_show_page_keywords','1','',0,''),('search_show_page_name','1','',0,''),('search_show_page_url','1','',0,''),('search_user_content','0','',0,''),('SMTP_host','localhost','SMTP_host',0,''),('s_copyright','... n.v.','Site Copyright',10,''),('use_draft_content','','Use draft/publish content mode',20,''),('warnings_notices_max_count','5','Limit number of warnings/notices to be sent',41,''),('warnings_notices_max_period','10','Number of time periods',42,''),('warnings_notices_max_period_type','minute','Type of time period (second/minute/quarter/hour/day)',43,'');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `page_id` int(11) NOT NULL default '0',
  `var` varchar(50) NOT NULL default '',
  `var_id` int(11) unsigned NOT NULL default '0',
  `val` text,
  `short_desc` varchar(100) default NULL,
  `full_desc` varchar(255) default NULL,
  `language` char(2) NOT NULL default '',
  `edit_date` timestamp NOT NULL default '0000-00-00 00:00:00',
  `val_draft` text,
  `edit_date_draft` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`page_id`,`var`,`var_id`,`language`),
  KEY `page_id_idx` (`page_id`),
  KEY `content_var_idx` (`var`),
  KEY `content_var_id_idx` (`var_id`),
  KEY `content_language_idx` (`language`),
  KEY `content_edit_date_idx` (`edit_date`),
  KEY `content_edit_date_draft_idx` (`edit_date_draft`),
  CONSTRAINT `content_ibfk_1` FOREIGN KEY (`language`) REFERENCES `language` (`language_code`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (0,'ADDRESS',0,'Адреса проживання','ADDRESS',NULL,'UA','2010-04-02 08:25:12','Адреса проживання','2010-04-02 08:25:12'),(0,'at_least_one_group',0,'At least one group should be selected','at_least_one_group',NULL,'EN','2009-11-14 21:07:33','At least one group should be selected','2009-11-14 21:07:33'),(0,'AUTHORIZATION',0,'Авторизація','AUTHORIZATION',NULL,'UA','2010-04-02 08:35:30','Авторизація','2010-04-02 08:35:30'),(0,'AUTHORIZATION_FORM',0,'Форма авторизації','AUTHORIZATION_FORM',NULL,'UA','2010-04-02 08:35:29','Форма авторизації','2010-04-02 08:35:29'),(0,'BIRTHDAY',0,'Дата<br/>народження','BIRTHDAY',NULL,'UA','2010-04-02 08:25:12','Дата<br/>народження','2010-04-02 08:25:12'),(0,'CELLULAR_PHONE',0,'Мобільний<br/>телефон','CELLULAR_PHONE',NULL,'UA','2010-04-02 08:25:12','Мобільний<br/>телефон','2010-04-02 08:25:12'),(0,'CITY',0,'Місто','CITY',NULL,'UA','2010-04-02 08:25:12','Місто','2010-04-02 08:25:12'),(0,'CITY_PHONE',0,'Міський<br/>телефон','CITY_PHONE',NULL,'UA','2010-04-02 08:25:12','Міський<br/>телефон','2010-04-02 08:25:12'),(0,'COMPLETE_TYPE',0,'Complete type','COMPLETE_TYPE',NULL,'UA','2010-04-02 08:23:55','Complete type','2010-04-02 08:23:55'),(0,'CONFIRM_PASSWORD',0,'Пiдтвердити пароль','CONFIRM_PASSWORD',NULL,'UA','2010-04-03 08:32:08','Пiдтвердити пароль','2010-04-03 08:32:08'),(0,'contact_block_content',0,NULL,'contact_block_content',NULL,'EN','2010-01-29 17:43:06',NULL,'2010-01-29 17:43:06'),(0,'contact_block_content',0,'<p><img width=\"50\" vspace=\"4\" height=\"50\" align=\"left\" alt=\"\" src=\"/usersimage/Image/face.png\" /></p>\r\n<p class=\"pink_15_lm\">ПІБ</p>\r\n<p class=\"content_simple_text_lm\">адреса</p>\r\n<p class=\"content_simple_text_lm\">телефон</p>\r\n<p><a href=\"mailto:viktor.bozhko@tns-ua.com?subject=Question\" class=\"system_button2\">Надіслати повідомлення</a></p>','contact_block_content','','UA','2010-01-29 17:45:54','<p><img width=\"50\" vspace=\"4\" height=\"50\" align=\"left\" alt=\"\" src=\"/usersimage/Image/face.png\" /></p>\r\n<p class=\"pink_15_lm\">ПІБ</p>\r\n<p class=\"content_simple_text_lm\">адреса</p>\r\n<p class=\"content_simple_text_lm\">телефон</p>\r\n<p><a href=\"mailto:viktor.bozhko@tns-ua.com?subject=Question\" class=\"system_button2\">Надіслати повідомлення</a></p>','2010-01-29 17:45:54'),(0,'content_no_template',0,'content_no_template',NULL,NULL,'EN','2010-03-20 06:30:00','content_no_template','2009-11-14 21:07:33'),(0,'current_projects_block_content',0,'<p><img height=\"50\" alt=\"\" width=\"50\" align=\"left\" vspace=\"4\" src=\"/usersimage/Image/face.png\" /></p>\r\n<p class=\"content_simple_text_lm\">У розділі розміщено список поточних досліджень. Ви можете взяти участь у будь-якому з них.</p>\r\n<p><a class=\"system_button2\" href=\"/index.php?t=45&amp;language=UA\">Перейти до розділу</a></p>','current_projects_block_content','','UA','2010-01-14 10:22:21','<p><img height=\"50\" alt=\"\" width=\"50\" align=\"left\" vspace=\"4\" src=\"/usersimage/Image/face.png\" /></p>\r\n<p class=\"content_simple_text_lm\">У розділі розміщено список поточних досліджень. Ви можете взяти участь у будь-якому з них.</p>\r\n<p><a class=\"system_button2\" href=\"/index.php?t=45&amp;language=UA\">Перейти до розділу</a></p>','2010-01-14 10:22:21'),(0,'DATE',0,'Дата','DATE',NULL,'UA','2010-04-02 08:23:57','Дата','2010-04-02 08:23:57'),(0,'default_meta_commentary',0,'',NULL,NULL,'EN','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'default_meta_commentary',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'default_meta_commentary',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'default_meta_description',0,'',NULL,NULL,'EN','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'default_meta_description',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'default_meta_description',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'default_meta_keywords',0,'',NULL,NULL,'EN','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'default_meta_keywords',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'default_meta_keywords',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'default_meta_title',0,'',NULL,NULL,'EN','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'default_meta_title',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'default_meta_title',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'default_obj_meta_commentary',0,'',NULL,NULL,'EN','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'default_obj_meta_commentary',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'default_obj_meta_commentary',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'default_obj_meta_description',0,'',NULL,NULL,'EN','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'default_obj_meta_description',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'default_obj_meta_description',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'default_obj_meta_keywords',0,'',NULL,NULL,'EN','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'default_obj_meta_keywords',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'default_obj_meta_keywords',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'default_obj_meta_title',0,'',NULL,NULL,'EN','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'default_obj_meta_title',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'default_obj_meta_title',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'dest_email',0,'your_email@address.com','dest_email',NULL,'EN','2009-11-14 21:07:33','your_email@address.com','2009-11-14 21:07:33'),(0,'dest_email_subject',0,'News Letters system','dest_email_subject',NULL,'EN','2009-11-14 21:07:33','News Letters system','2009-11-14 21:07:33'),(0,'DISTRICT',0,'Область','DISTRICT',NULL,'UA','2010-04-02 08:25:12','Область','2010-04-02 08:25:12'),(0,'dns_disabled',0,'dns_disabled',NULL,NULL,'EN','2009-11-14 21:07:33','dns_disabled','2009-11-14 21:07:33'),(0,'E-MAIL',0,'E-mail','E-MAIL',NULL,'UA','2010-04-02 08:25:12','E-mail','2010-04-02 08:25:12'),(0,'ENTER',0,'Вхід','ENTER',NULL,'UA','2010-04-02 08:23:33','Вхід','2010-04-02 08:23:33'),(0,'ENTER_E-MAIL_IN_STANDART_FORMAT',0,'Введiть e-mail у загальноприйнятому форматi (з \'@\'-собачкою та \'.\'-крапочкою).','ENTER_E-MAIL_IN_STANDART_FORMAT',NULL,'UA','2010-04-02 08:25:12','Введiть e-mail у загальноприйнятому форматi (з \'@\'-собачкою та \'.\'-крапочкою).','2010-04-02 08:25:12'),(0,'ENTER_PHONE_NUMBER_WITH_CODE_(10_DIGITS)',0,'Введите номер телефона с кодом (10 цифр).','ENTER_PHONE_NUMBER_WITH_CODE_(10_DIGITS)','','RU','2010-04-02 09:12:05','Введите номер телефона с кодом (10 цифр).','2010-04-02 09:12:05'),(0,'ENTER_PHONE_NUMBER_WITH_CODE_(10_DIGITS)',0,'Введiть номер телефону з кодом (10 цифр).','ENTER_PHONE_NUMBER_WITH_CODE_(10_DIGITS)','','UA','2010-04-02 09:11:35','Введiть номер телефону з кодом (10 цифр).','2010-04-02 09:11:35'),(0,'ENTER_POINTS_NUMBER_YOU_WISH_TO_CONVERT',0,'Enter points number you wish to convert','ENTER_POINTS_NUMBER_YOU_WISH_TO_CONVERT',NULL,'UA','2010-04-06 18:29:12','Enter points number you wish to convert','2010-04-06 18:29:12'),(0,'ENTER_YOUR_E-MAIL',0,'Введіть e-maіl, який вводили при реєстрації','ENTER_YOUR_E-MAIL',NULL,'UA','2010-04-03 08:29:59','Введіть e-maіl, який вводили при реєстрації','2010-04-03 08:29:59'),(0,'ERROR_',404,'Помилка 404','ERROR_404',NULL,'UA','2010-04-02 08:27:05','Помилка 404','2010-04-02 08:27:05'),(0,'EXIT',0,'Вихід','EXIT',NULL,'UA','2010-04-02 08:23:55','Вихід','2010-04-02 08:23:55'),(0,'FAMILY',0,'Прізвище','FAMILY',NULL,'UA','2010-04-02 08:25:12','Прізвище','2010-04-02 08:25:12'),(0,'faq_block_content',0,'<p><img height=\"49\" align=\"left\" width=\"49\" vspace=\"4\" src=\"/usersimage/Image/faq.png\" alt=\"\" /></p>\r\n<p style=\"margin-left: 60px;\" class=\"content_simple_text\">Відповіді на найпоширеніші питання у розділі Frequently Asked Questions.</p>\r\n<p style=\"margin-left: 60px;\" class=\"content_simple_text\">&nbsp;</p>\r\n<p><a href=\"/index.php?t=86&amp;language=UA\" class=\"system_button2\">Перейти до розділу</a></p>','faq_block_content','','UA','2010-01-19 11:19:32','<p><img height=\"49\" align=\"left\" width=\"49\" vspace=\"4\" src=\"/usersimage/Image/faq.png\" alt=\"\" /></p>\r\n<p style=\"margin-left: 60px;\" class=\"content_simple_text\">Відповіді на найпоширеніші питання у розділі Frequently Asked Questions.</p>\r\n<p style=\"margin-left: 60px;\" class=\"content_simple_text\">&nbsp;</p>\r\n<p><a href=\"/index.php?t=86&amp;language=UA\" class=\"system_button2\">Перейти до розділу</a></p>','2010-01-19 11:19:32'),(0,'faq_block_title',0,'33333 33 33333','faq_block_title','','UA','2010-01-13 18:24:46','33333 33 33333','2010-01-13 18:24:46'),(0,'FEMALE',0,'Жіноча','FEMALE',NULL,'UA','2010-04-02 08:25:12','Жіноча','2010-04-02 08:25:12'),(0,'FLAT',0,'Квартира','FLAT',NULL,'UA','2010-04-02 08:25:12','Квартира','2010-04-02 08:25:12'),(0,'footer_copy',0,'<p>&copy;1998-2010 Тейлор Нельсон Софрез Україна. Усі права захищено.</p>\r\n<p>Юридична адреса: вул. Ігорівська 1/8 літера &quot;В&quot;, Київ, 04070, Україна</p>','footer_copy','','UA','2010-02-01 14:48:58','<p>&copy;1998-2010 Тейлор Нельсон Софрез Україна. Усі права захищено.</p>\r\n<p>Юридична адреса: вул. Ігорівська 1/8 літера &quot;В&quot;, Київ, 04070, Україна</p>','2010-02-01 14:48:58'),(0,'footer_siteby',0,'Developed by <a href=\"http://www.2kgroup.com\" target=\"_blank\" title=\"2K-Group: Web Development, IT outsourcing\">2K-Group</a>','footer_siteby','','UA','2010-02-09 14:27:18','Developed by <a href=\"http://www.2kgroup.com\" target=\"_blank\" title=\"2K-Group: Web Development, IT outsourcing\">2K-Group</a>','2010-02-09 14:27:18'),(0,'FORGOT_PASSWORD',0,'Забули пароль','FORGOT_PASSWORD',NULL,'UA','2010-04-02 08:23:33','Забули пароль','2010-04-02 08:23:33'),(0,'GO_TO_HOME_PAGE',0,'Перейти на главную страницу','GO_TO_HOME_PAGE','','RU','2010-04-02 08:29:05','Перейти на главную страницу','2010-04-02 08:29:05'),(0,'GO_TO_HOME_PAGE',0,'Перейти до головної сторiнки','GO_TO_HOME_PAGE',NULL,'UA','2010-04-02 08:23:33','Перейти до головної сторiнки','2010-04-02 08:23:33'),(0,'HOME',0,'Головна','HOME',NULL,'UA','2010-04-02 08:23:33','Головна','2010-04-02 08:23:33'),(0,'HOUSE',0,'Будинок','HOUSE',NULL,'UA','2010-04-02 08:25:12','Будинок','2010-04-02 08:25:12'),(0,'html_comments_between_page_head_and_title',0,NULL,'html_comments_between_page_head_and_title',NULL,'UA','2010-01-19 10:17:54',NULL,'2010-01-19 10:17:54'),(0,'ID',0,'Id','ID',NULL,'UA','2010-04-02 08:25:12','Id','2010-04-02 08:25:12'),(0,'incorrect_sid',0,'<p><span style=\"color: #ff0000\">Не правильний код активації!</span></p>','incorrect_sid','','UA','2009-12-11 10:38:30','<p><span style=\"color: #ff0000\">Не правильний код активації!</span></p>','2009-12-11 10:38:30'),(0,'index_block_',4,NULL,'index_block_4',NULL,'EN','2010-01-19 10:36:57',NULL,'2010-01-19 10:36:57'),(0,'index_block_',4,'<p class=\"content_simple_text\">TNS &ndash; світовий лідер у галузі проведення маркетингових досліджень &laquo;на замовлення&raquo;.</p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\">Місія TNS:&nbsp; <br />\r\n<em>&laquo;Бути найбільш успішною і шанованою компанією у сфері маркетингових досліджень, яка б мала міцну репутацію компанії, <br />\r\nщо надає незмінно якісні послуги; але, також, яка була би відомою тим, що надає можливість клієнтам ставити перед собою <br />\r\nвсе більш високі цілі, які вона допомагає реалізувати, і пропонує їм все більш інноваційні рішення, задовольняючи потреби <br />\r\nклієнта, що постійно розширюються&raquo;.</em></p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p><a class=\"system_button\" href=\"http://www.tns-ua.com\">Перейти до сайту TNS</a></p>','index_block_4','','UA','2010-01-19 10:37:26','<p class=\"content_simple_text\">TNS &ndash; світовий лідер у галузі проведення маркетингових досліджень &laquo;на замовлення&raquo;.</p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\">Місія TNS:&nbsp; <br />\r\n<em>&laquo;Бути найбільш успішною і шанованою компанією у сфері маркетингових досліджень, яка б мала міцну репутацію компанії, <br />\r\nщо надає незмінно якісні послуги; але, також, яка була би відомою тим, що надає можливість клієнтам ставити перед собою <br />\r\nвсе більш високі цілі, які вона допомагає реалізувати, і пропонує їм все більш інноваційні рішення, задовольняючи потреби <br />\r\nклієнта, що постійно розширюються&raquo;.</em></p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p><a class=\"system_button\" href=\"http://www.tns-ua.com\">Перейти до сайту TNS</a></p>','2010-01-19 10:37:26'),(0,'index_block_1_bottom',0,NULL,'index_block_1_bottom','','EN','2010-03-29 17:00:59',NULL,'2010-03-29 17:00:59'),(0,'index_block_1_bottom',0,'<p class=\"content_simple_text\"><a class=\"small_pink_down_arrow_at_left\">О TNS Opros</a></p>\r\n<p><a class=\"pink_microbox_at_left\" href=\"/index.php?t=35&amp;language=UA\">Мы TNS Opros</a><br />\r\n<a class=\"pink_microbox_at_left\" href=\"/index.php?t=42&amp;language=UA\">Преимущества TNS Opros</a><br />\r\n<a class=\"pink_microbox_at_left\" href=\"/index.php?t=55&amp;language=UA\">Миссия TNS Opros</a><br />\r\n&nbsp;</p>\r\n<p class=\"content_simple_text\">TNS разработала сообщество для того, чтобы дать Вам в руки реальный инструмент для благоустройства вашей жизни - лидеры ринка прислушаются к вашому мнению уже сегодня.</p>','index_block_1_bottom','','RU','2010-03-29 17:00:17','<p class=\"content_simple_text\"><a class=\"small_pink_down_arrow_at_left\">О TNS Opros</a></p>\r\n<p><a class=\"pink_microbox_at_left\" href=\"/index.php?t=35&amp;language=UA\">Мы TNS Opros</a><br />\r\n<a class=\"pink_microbox_at_left\" href=\"/index.php?t=42&amp;language=UA\">Преимущества TNS Opros</a><br />\r\n<a class=\"pink_microbox_at_left\" href=\"/index.php?t=55&amp;language=UA\">Миссия TNS Opros</a><br />\r\n&nbsp;</p>\r\n<p class=\"content_simple_text\">TNS разработала сообщество для того, чтобы дать Вам в руки реальный инструмент для благоустройства вашей жизни - лидеры ринка прислушаются к вашому мнению уже сегодня.</p>','2010-03-29 17:00:17'),(0,'index_block_1_bottom',0,'<p class=\"content_simple_text\"><a class=\"small_pink_down_arrow_at_left\">Про TNS Opros</a></p>\r\n<p><a class=\"pink_microbox_at_left\" href=\"/index.php?t=35&amp;language=UA\">Ми TNS Opros</a><br />\r\n<a class=\"pink_microbox_at_left\" href=\"/index.php?t=42&amp;language=UA\">Переваги TNS Opros</a><br />\r\n<a class=\"pink_microbox_at_left\" href=\"/index.php?t=55&amp;language=UA\">Місія TNS Opros</a><br />\r\n&nbsp;</p>\r\n<p class=\"content_simple_text\">TNS створила співтовариство для того, щоб дати Вам у руки реальний інструмент для благоустрою вашого життя - лідери ринку прислухаюся до вашої думки вже сьогодні.</p>','index_block_1_bottom','','UA','2010-03-29 17:01:42','<p class=\"content_simple_text\"><a class=\"small_pink_down_arrow_at_left\">Про TNS Opros</a></p>\r\n<p><a class=\"pink_microbox_at_left\" href=\"/index.php?t=35&amp;language=UA\">Ми TNS Opros</a><br />\r\n<a class=\"pink_microbox_at_left\" href=\"/index.php?t=42&amp;language=UA\">Переваги TNS Opros</a><br />\r\n<a class=\"pink_microbox_at_left\" href=\"/index.php?t=55&amp;language=UA\">Місія TNS Opros</a><br />\r\n&nbsp;</p>\r\n<p class=\"content_simple_text\">TNS створила співтовариство для того, щоб дати Вам у руки реальний інструмент для благоустрою вашого життя - лідери ринку прислухаюся до вашої думки вже сьогодні.</p>','2010-03-29 17:01:42'),(0,'index_block_1_bottom_for_authorized',0,'<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\">Ми будемо зберігати для Вас історію опитувань,&nbsp;в яких Ви брали участь,&nbsp;весь час, поки Ви будете з нами.</p>\r\n<p><a class=\"system_button\" href=\"/index.php?t=30&amp;language=UA\">Історія опитувань</a></p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\">Накопичили достатню кількість балів? Скористайтесь одним із способів їх конвертації для задоволення своїх потреб.</p>\r\n<p><a class=\"system_button\" href=\"/index.php?t=31&amp;language=UA\">Конвертація балів</a></p>','index_block_1_bottom_for_authorized','','UA','2010-01-21 12:02:21','<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\">Ми будемо зберігати для Вас історію опитувань,&nbsp;в яких Ви брали участь,&nbsp;весь час, поки Ви будете з нами.</p>\r\n<p><a class=\"system_button\" href=\"/index.php?t=30&amp;language=UA\">Історія опитувань</a></p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\">Накопичили достатню кількість балів? Скористайтесь одним із способів їх конвертації для задоволення своїх потреб.</p>\r\n<p><a class=\"system_button\" href=\"/index.php?t=31&amp;language=UA\">Конвертація балів</a></p>','2010-01-21 12:02:21'),(0,'index_block_1_top',0,NULL,'index_block_1_top',NULL,'EN','2010-03-25 13:22:33',NULL,'2010-03-25 13:22:33'),(0,'index_block_1_top',0,'Узнайте больше об онлайн сообществе TNS Opros','index_block_1_top','','RU','2010-03-29 16:53:25','Узнайте больше об онлайн сообществе TNS Opros','2010-03-29 16:53:25'),(0,'index_block_1_top',0,'Дізнайтесь більше про онлайн співтовариство TNS Opros','index_block_1_top','','UA','2010-03-29 16:53:45','Дізнайтесь більше про онлайн співтовариство TNS Opros','2010-03-29 16:53:45'),(0,'index_block_1_top_for_authorized',0,'Відчуйте себе частиною прогресивної еліти суспільства.','index_block_1_top_for_authorized','','UA','2010-01-11 08:24:46','Відчуйте себе частиною прогресивної еліти суспільства.','2010-01-11 08:24:46'),(0,'index_block_2_top',0,NULL,'index_block_2_top','','RU','2010-03-01 16:51:33',NULL,'2010-03-01 16:51:33'),(0,'index_block_2_top',0,'З нами Ви завжди в курсі останніх новин та розробок.','index_block_2_top','','UA','2010-03-01 16:53:12','З нами Ви завжди в курсі останніх новин та розробок.','2010-03-01 16:53:12'),(0,'index_block_3_bottom',0,'<p class=\"content_simple_text\">Дізнайтеся більше про нашу систему<br />\r\nзаохочення та відчуйте реальну<br />\r\nтурботу, яку TNS дарує кожному <br />\r\nреспонденту.</p>\r\n<p><a href=\"/index.php?t=52&amp;language=UA\" class=\"system_button\">Система заохочення</a></p>\r\n<p>&nbsp;</p>\r\n<p class=\"content_simple_text\">Для того, щоб брати участь у наших<br />\r\nдослідженнях потрібно заповнити<br />\r\nформу реєстрації.</p>\r\n<p><a href=\"/index.php?t=47&amp;language=UA\" class=\"system_button\">Форма реєстрації</a></p>','index_block_3_bottom','','UA','2010-01-26 15:38:11','<p class=\"content_simple_text\">Дізнайтеся більше про нашу систему<br />\r\nзаохочення та відчуйте реальну<br />\r\nтурботу, яку TNS дарує кожному <br />\r\nреспонденту.</p>\r\n<p><a href=\"/index.php?t=52&amp;language=UA\" class=\"system_button\">Система заохочення</a></p>\r\n<p>&nbsp;</p>\r\n<p class=\"content_simple_text\">Для того, щоб брати участь у наших<br />\r\nдослідженнях потрібно заповнити<br />\r\nформу реєстрації.</p>\r\n<p><a href=\"/index.php?t=47&amp;language=UA\" class=\"system_button\">Форма реєстрації</a></p>','2010-01-26 15:38:11'),(0,'index_block_3_bottom_for_authorized',0,'<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\">Будь-ласка, оберіть цікаву для Вас тематику дослідження та перейдіть за посиланням для того, щоб почати опитування. <br />\r\nВи можете продовжити опитування, якщо за якихось причин Ви не завершили його з першого разу.</p>','index_block_3_bottom_for_authorized','','UA','2010-01-19 10:04:39','<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\">Будь-ласка, оберіть цікаву для Вас тематику дослідження та перейдіть за посиланням для того, щоб почати опитування. <br />\r\nВи можете продовжити опитування, якщо за якихось причин Ви не завершили його з першого разу.</p>','2010-01-19 10:04:39'),(0,'index_block_3_top',0,'Ми зробимо вашу участь у  дослідженнях розвагою','index_block_3_top','','UA','2010-01-08 14:33:47','Ми зробимо вашу участь у  дослідженнях розвагою','2010-01-08 14:33:47'),(0,'index_block_3_top_for_authorized',0,'Беріть участь у дослідженнях та заробляйте бали!','index_block_3_top_for_authorized','','UA','2010-01-11 08:32:55','Беріть участь у дослідженнях та заробляйте бали!','2010-01-11 08:32:55'),(0,'int_b_3_class',0,'CDE8F3','int_b_3_class','','UA','2010-01-12 21:53:25','CDE8F3','2010-01-12 21:53:25'),(0,'invalid_email_format',0,'Invalid email format','invalid_email_format',NULL,'EN','2009-11-14 21:07:33','Invalid email format','2009-11-14 21:07:33'),(0,'INVESTIGATION_POINTS',0,'Нагорода за дослідження','INVESTIGATION_POINTS',NULL,'UA','2010-04-02 08:35:35','Нагорода за дослідження','2010-04-02 08:35:35'),(0,'KYIV_&_SEVASTOPOL',0,'Мiста республiканського пiдпорядкування, Київ та Севастополь, вибирайте на рiвнi областi','KYIV_&_SEVASTOPOL',NULL,'UA','2010-04-02 08:25:12','Мiста республiканського пiдпорядкування, Київ та Севастополь, вибирайте на рiвнi областi','2010-04-02 08:25:12'),(0,'LAST_NEWS_36.',6,'Last news 36.6','LAST_NEWS_36.6',NULL,'UA','2010-04-02 08:23:33','Last news 36.6','2010-04-02 08:23:33'),(0,'LOGIN',0,'E-mail','LOGIN',NULL,'UA','2010-04-02 08:35:29','E-mail','2010-04-02 08:35:29'),(0,'MALE',0,'Чоловіча','MALE',NULL,'UA','2010-04-02 08:25:12','Чоловіча','2010-04-02 08:25:12'),(0,'media_',69,'a:5:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:22:\"tns_new_year_69_UA.png\";}s:4:\"alts\";a:1:{s:2:\"UA\";s:1:\" \";}}','media_69','','','2010-03-04 16:25:51','a:5:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:22:\"tns_new_year_69_UA.png\";}s:4:\"alts\";a:1:{s:2:\"UA\";s:1:\" \";}}','2010-03-04 16:25:51'),(0,'media_',70,'a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";b:0;s:6:\"images\";a:1:{s:2:\"UA\";s:36:\"__replace_after_insert___1_70_UA.png\";}}','media_70',NULL,'','2010-01-08 13:54:20','a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";b:0;s:6:\"images\";a:1:{s:2:\"UA\";s:36:\"__replace_after_insert___1_70_UA.png\";}}','2010-01-08 13:54:20'),(0,'media_',71,'a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:31:\"main_block_about_36_6_71_UA.png\";}}','media_71','','','2010-01-29 12:11:41','a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:31:\"main_block_about_36_6_71_UA.png\";}}','2010-01-29 12:11:41'),(0,'media_',72,'a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:32:\"main_block_news_header_72_UA.png\";}}','media_72','','','2010-01-08 15:22:43','a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:32:\"main_block_news_header_72_UA.png\";}}','2010-01-08 15:22:43'),(0,'media_',73,'a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:25:\"main_block_news_73_UA.png\";}}','media_73','','','2010-01-29 12:11:59','a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:25:\"main_block_news_73_UA.png\";}}','2010-01-29 12:11:59'),(0,'media_',74,'a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";b:0;s:6:\"images\";a:1:{s:2:\"UA\";s:36:\"__replace_after_insert___5_74_UA.png\";}}','media_74',NULL,'','2010-01-08 13:54:21','a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";b:0;s:6:\"images\";a:1:{s:2:\"UA\";s:36:\"__replace_after_insert___5_74_UA.png\";}}','2010-01-08 13:54:21'),(0,'media_',75,'a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:32:\"main_block_pryednajtes_75_UA.png\";}}','media_75','','','2010-01-29 12:12:24','a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:32:\"main_block_pryednajtes_75_UA.png\";}}','2010-01-29 12:12:24'),(0,'media_',76,'a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:37:\"main_block_about_tns_header_76_UA.png\";}}','media_76','','','2010-01-08 15:29:20','a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:37:\"main_block_about_tns_header_76_UA.png\";}}','2010-01-08 15:29:20'),(0,'media_',77,'a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:24:\"my_36_6_header_77_UA.png\";}}','media_77','','','2010-01-11 08:16:29','a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:24:\"my_36_6_header_77_UA.png\";}}','2010-01-11 08:16:29'),(0,'media_',78,'a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:33:\"current_projects_header_78_UA.png\";}}','media_78','','','2010-01-11 08:18:07','a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:33:\"current_projects_header_78_UA.png\";}}','2010-01-11 08:18:07'),(0,'media_',79,'a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:21:\"darts_arrow_79_UA.png\";}}','media_79','','','2010-01-29 12:02:42','a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:21:\"darts_arrow_79_UA.png\";}}','2010-01-29 12:02:42'),(0,'media_',80,'a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:18:\"uah_sign_80_UA.png\";}}','media_80','','','2010-01-29 12:03:49','a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:18:\"uah_sign_80_UA.png\";}}','2010-01-29 12:03:49'),(0,'media_',81,'a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:19:\"handshake_81_UA.png\";}}','media_81','','','2010-01-29 12:04:07','a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:19:\"handshake_81_UA.png\";}}','2010-01-29 12:04:07'),(0,'media_',84,'a:7:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";b:0;s:6:\"images\";a:1:{s:2:\"UA\";s:16:\"quotes_84_UA.swf\";}s:9:\"show_menu\";s:3:\"yes\";s:7:\"quality\";s:4:\"high\";s:7:\"bgcolor\";b:0;}','media_84','','','2010-01-30 13:32:40','a:7:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";b:0;s:6:\"images\";a:1:{s:2:\"UA\";s:16:\"quotes_84_UA.swf\";}s:9:\"show_menu\";s:3:\"yes\";s:7:\"quality\";s:4:\"high\";s:7:\"bgcolor\";b:0;}','2010-01-30 13:32:40'),(0,'media_',85,'a:7:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";b:0;s:6:\"images\";a:1:{s:2:\"UA\";s:26:\"quotes_with_text_85_UA.png\";}s:9:\"show_menu\";s:3:\"yes\";s:7:\"quality\";s:4:\"high\";s:7:\"bgcolor\";b:0;}','media_85','','','2010-01-12 18:52:00','a:7:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";b:0;s:6:\"images\";a:1:{s:2:\"UA\";s:26:\"quotes_with_text_85_UA.png\";}s:9:\"show_menu\";s:3:\"yes\";s:7:\"quality\";s:4:\"high\";s:7:\"bgcolor\";b:0;}','2010-01-12 18:52:00'),(0,'media_',91,'a:7:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";b:0;s:6:\"images\";a:2:{s:2:\"EN\";s:12:\"91_91_EN.swf\";s:2:\"UA\";s:12:\"91_91_UA.swf\";}s:9:\"show_menu\";s:3:\"yes\";s:7:\"quality\";s:4:\"high\";s:7:\"bgcolor\";b:0;}','media_91','','','2010-01-30 13:31:34','a:7:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";b:0;s:6:\"images\";a:2:{s:2:\"EN\";s:12:\"91_91_EN.swf\";s:2:\"UA\";s:12:\"91_91_UA.swf\";}s:9:\"show_menu\";s:3:\"yes\";s:7:\"quality\";s:4:\"high\";s:7:\"bgcolor\";b:0;}','2010-01-30 13:31:34'),(0,'media_',92,'a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:21:\"tns_March_8_92_UA.png\";}}','media_92','','','2010-03-04 15:16:56','a:4:{s:6:\"size_x\";i:0;s:6:\"size_y\";i:0;s:14:\"size_unit_type\";s:2:\"px\";s:6:\"images\";a:1:{s:2:\"UA\";s:21:\"tns_March_8_92_UA.png\";}}','2010-03-04 15:16:56'),(0,'menu',0,'','menu','','UA','2010-03-30 12:28:07','','2010-03-30 12:28:07'),(0,'menu',22,'','menu22',NULL,'UA','2010-01-21 16:20:19','','2010-01-21 16:20:19'),(0,'menu',24,'','menu24',NULL,'UA','2010-01-22 14:02:49','','2010-01-22 14:02:49'),(0,'menu_100_',1,' ','menu_100_1',NULL,'EN','2009-11-14 21:10:09',' ','2009-11-14 21:10:09'),(0,'menu_100_',2,'О TNS Opros','menu_100_2','','RU','2010-03-29 17:15:18','О TNS Opros','2010-03-29 17:15:18'),(0,'menu_100_',2,'Про TNS Opros','menu_100_2','','UA','2010-03-29 17:15:08','Про TNS Opros','2010-03-29 17:15:08'),(0,'menu_100_',3,'Присоединяйтесь','menu_100_3',NULL,'RU','2010-03-01 13:18:17','Присоединяйтесь','2010-03-01 13:18:17'),(0,'menu_100_',3,'Приєднайтесь','menu_100_3','','UA','2010-03-29 17:33:01','Приєднайтесь','2010-03-29 17:33:01'),(0,'menu_100_',4,'Підсумки досліджень','menu_100_4','','UA','2010-01-13 12:02:58','Підсумки досліджень','2010-01-13 12:02:58'),(0,'menu_100_',5,'Новини','menu_100_5','','UA','2010-01-13 12:02:31','Новини','2010-01-13 12:02:31'),(0,'menu_100_',6,'Поточні проекти','menu_100_6',NULL,'UA','2009-12-11 13:22:58','Поточні проекти','2009-12-11 13:22:58'),(0,'menu_100_',7,'Текущие исследования','menu_100_7',NULL,'RU','2010-03-29 18:00:03','Текущие исследования','2010-03-29 18:00:03'),(0,'menu_100_',7,'Поточні дослідження','menu_100_7','','UA','2010-03-29 17:59:53','Поточні дослідження','2010-03-29 17:59:53'),(0,'menu_100_',8,'Мой Opros','menu_100_8',NULL,'RU','2010-03-29 17:57:26','Мой Opros','2010-03-29 17:57:26'),(0,'menu_100_',8,'Мій Opros','menu_100_8','','UA','2010-03-29 17:57:18','Мій Opros','2010-03-29 17:57:18'),(0,'menu_100_',9,'Back-office menu item','menu_100_9','','UA','2009-12-11 13:57:36','Back-office menu item','2009-12-11 13:57:36'),(0,'menu_100_',10,'Форма регистрации','menu_100_10',NULL,'RU','2010-03-29 17:33:23','Форма регистрации','2010-03-29 17:33:23'),(0,'menu_100_',10,'Форма реєстрації','menu_100_10','','UA','2010-03-29 17:33:13','Форма реєстрації','2010-03-29 17:33:13'),(0,'menu_100_',11,'Зачем регистрироваться','menu_100_11',NULL,'RU','2010-03-29 17:33:39','Зачем регистрироваться','2010-03-29 17:33:39'),(0,'menu_100_',11,'Навіщо реєструватись','menu_100_11','','UA','2010-03-29 17:33:29','Навіщо реєструватись','2010-03-29 17:33:29'),(0,'menu_100_',12,'Система поощрений','menu_100_12',NULL,'RU','2010-03-29 17:34:33','Система поощрений','2010-03-29 17:34:33'),(0,'menu_100_',12,'Система заохочення','menu_100_12','','UA','2010-03-29 17:34:29','Система заохочення','2010-03-29 17:34:29'),(0,'menu_100_',13,'Главная','menu_100_13',NULL,'RU','2010-03-01 13:17:43','Главная','2010-03-01 13:17:43'),(0,'menu_100_',13,'Головна','menu_100_13','','UA','2010-03-25 13:27:43','Головна','2010-03-25 13:27:43'),(0,'menu_100_',14,'Исследования','menu_100_14',NULL,'RU','2010-03-29 18:00:27','Исследования','2010-03-29 18:00:27'),(0,'menu_100_',14,'Дослідження','menu_100_14','','UA','2010-03-29 18:00:15','Дослідження','2010-03-29 18:00:15'),(0,'menu_100_',15,'История опросов','menu_100_15',NULL,'RU','2010-03-29 17:57:47','История опросов','2010-03-29 17:57:47'),(0,'menu_100_',15,'Історія опитувань','menu_100_15','','UA','2010-03-29 17:57:34','Історія опитувань','2010-03-29 17:57:34'),(0,'menu_100_',16,'Мои личные данные','menu_100_16',NULL,'RU','2010-03-29 17:58:05','Мои личные данные','2010-03-29 17:58:05'),(0,'menu_100_',16,'Мої особисті дані','menu_100_16','','UA','2010-03-29 17:57:54','Мої особисті дані','2010-03-29 17:57:54'),(0,'menu_100_',17,'Конвертация баллов','menu_100_17',NULL,'RU','2010-03-29 17:58:20','Конвертация баллов','2010-03-29 17:58:20'),(0,'menu_100_',17,'Конвертація балів','menu_100_17','','UA','2010-04-06 18:30:29','Конвертація балів','2010-04-06 18:30:29'),(0,'menu_100_',18,'Тестовий пункт меню з довгою назвою в декілька рядків','menu_100_18','','UA','2009-12-30 14:39:25','Тестовий пункт меню з довгою назвою в декілька рядків','2009-12-30 14:39:25'),(0,'menu_100_',19,'Мы TNS Opros','menu_100_19','','RU','2010-03-29 17:30:28','Мы TNS Opros','2010-03-29 17:30:28'),(0,'menu_100_',19,'Ми TNS Opros','menu_100_19','','UA','2010-03-29 17:30:25','Ми TNS Opros','2010-03-29 17:30:25'),(0,'menu_100_',20,'Преимущества TNS Opros','menu_100_20',NULL,'RU','2010-03-29 17:31:04','Преимущества TNS Opros','2010-03-29 17:31:04'),(0,'menu_100_',20,'Переваги TNS Opros','menu_100_20','','UA','2010-03-29 17:31:00','Переваги TNS Opros','2010-03-29 17:31:00'),(0,'menu_100_',21,'Миссия TNS Opros','menu_100_21',NULL,'RU','2010-03-29 17:31:25','Миссия TNS Opros','2010-03-29 17:31:25'),(0,'menu_100_',21,'Місія TNS Opros','menu_100_21','','UA','2010-03-29 17:31:14','Місія TNS Opros','2010-03-29 17:31:14'),(0,'menu_100_',22,'Останні новини','menu_100_22',NULL,'UA','2010-01-12 08:32:05','Останні новини','2010-01-12 08:32:05'),(0,'menu_100_',23,'Головна','menu_100_23',NULL,'UA','2010-01-12 08:32:55','Головна','2010-01-12 08:32:55'),(0,'menu_100_',24,'Результати досліджень','menu_100_24',NULL,'UA','2010-01-12 08:33:57','Результати досліджень','2010-01-12 08:33:57'),(0,'menu_100_',25,'Пожива для роздумів','menu_100_25',NULL,'UA','2010-01-12 08:34:46','Пожива для роздумів','2010-01-12 08:34:46'),(0,'menu_100_',26,'Статистика відвідувань','menu_100_26',NULL,'UA','2010-01-12 08:35:39','Статистика відвідувань','2010-01-12 08:35:39'),(0,'menu_100_',27,'Полезная информация','menu_100_27',NULL,'RU','2010-03-01 13:20:34','Полезная информация','2010-03-01 13:20:34'),(0,'menu_100_',27,'Корисна інформація','menu_100_27','','UA','2010-03-29 17:34:42','Корисна інформація','2010-03-29 17:34:42'),(0,'menu_100_',28,'Новости TNS Opros','menu_100_28',NULL,'RU','2010-03-29 17:35:15','Новости TNS Opros','2010-03-29 17:35:15'),(0,'menu_100_',28,'Новини TNS Opros','menu_100_28','','UA','2010-03-29 17:35:04','Новини TNS Opros','2010-03-29 17:35:04'),(0,'menu_100_',29,'Результаты исследований','menu_100_29',NULL,'RU','2010-03-29 17:35:42','Результаты исследований','2010-03-29 17:35:42'),(0,'menu_100_',29,'Результати досліджень','menu_100_29','','UA','2010-03-29 17:35:22','Результати досліджень','2010-03-29 17:35:22'),(0,'menu_100_',30,'FAQ','menu_100_30','','UA','2010-03-29 17:35:47','FAQ','2010-03-29 17:35:47'),(0,'menu_100_',31,'Система поощрений','menu_100_31',NULL,'RU','2010-03-29 17:58:37','Система поощрений','2010-03-29 17:58:37'),(0,'menu_100_',31,'Система заохочення','menu_100_31','','UA','2010-04-06 18:25:47','Система заохочення','2010-04-06 18:25:47'),(0,'menu_100_picture_active_',2,'/usersimage/menu_100_UA_active_2.png','menu_100_picture_active_2','','UA','2009-12-02 15:05:41','/usersimage/menu_100_UA_active_2.png','2009-12-02 15:05:41'),(0,'menu_100_picture_active_',3,'/usersimage/menu_100_UA_active_3.png','menu_100_picture_active_3','','UA','2009-12-02 16:22:06','/usersimage/menu_100_UA_active_3.png','2009-12-02 16:22:06'),(0,'menu_100_picture_active_',4,'/usersimage/menu_100_UA_active_4.png','menu_100_picture_active_4','','UA','2009-12-03 17:17:10','/usersimage/menu_100_UA_active_4.png','2009-12-03 17:17:10'),(0,'menu_100_picture_active_',5,'/usersimage/menu_100_UA_active_5.png','menu_100_picture_active_5','','UA','2009-12-03 17:16:18','/usersimage/menu_100_UA_active_5.png','2009-12-03 17:16:18'),(0,'menu_100_picture_active_',6,'/usersimage/menu_100_UA_active_6.png','menu_100_picture_active_6',NULL,'UA','2009-12-11 13:24:28','/usersimage/menu_100_UA_active_6.png','2009-12-11 13:24:28'),(0,'menu_100_picture_active_',7,'/usersimage/menu_100_UA_active_7.png','menu_100_picture_active_7',NULL,'UA','2009-12-11 13:26:01','/usersimage/menu_100_UA_active_7.png','2009-12-11 13:26:01'),(0,'menu_100_picture_active_',8,'/usersimage/menu_100_UA_active_8.png','menu_100_picture_active_8',NULL,'UA','2009-12-11 13:30:07','/usersimage/menu_100_UA_active_8.png','2009-12-11 13:30:07'),(0,'menu_100_picture_active_',13,'/usersimage/menu_100_UA_active_13.png','menu_100_picture_active_13','','UA','2010-01-08 18:02:58','/usersimage/menu_100_UA_active_13.png','2010-01-08 18:02:58'),(0,'menu_100_picture_active_',27,'/usersimage/menu_100_UA_active_27.png','menu_100_picture_active_27',NULL,'UA','2010-01-13 11:59:56','/usersimage/menu_100_UA_active_27.png','2010-01-13 11:59:56'),(0,'menu_100_picture_inactive_',2,'/usersimage/menu_100_UA_inactive_2.png','menu_100_picture_inactive_2','','UA','2009-12-02 15:05:42','/usersimage/menu_100_UA_inactive_2.png','2009-12-02 15:05:42'),(0,'menu_100_picture_inactive_',3,'/usersimage/menu_100_UA_inactive_3.png','menu_100_picture_inactive_3','','UA','2009-12-02 16:22:07','/usersimage/menu_100_UA_inactive_3.png','2009-12-02 16:22:07'),(0,'menu_100_picture_inactive_',4,'/usersimage/menu_100_UA_inactive_4.png','menu_100_picture_inactive_4',NULL,'UA','2009-12-02 16:14:32','/usersimage/menu_100_UA_inactive_4.png','2009-12-02 16:14:32'),(0,'menu_100_picture_inactive_',5,'/usersimage/menu_100_UA_inactive_5.png','menu_100_picture_inactive_5',NULL,'UA','2009-12-02 15:32:52','/usersimage/menu_100_UA_inactive_5.png','2009-12-02 15:32:52'),(0,'menu_100_picture_inactive_',6,'/usersimage/menu_100_UA_inactive_6.png','menu_100_picture_inactive_6',NULL,'UA','2009-12-11 13:25:58','/usersimage/menu_100_UA_inactive_6.png','2009-12-11 13:25:58'),(0,'menu_100_picture_inactive_',7,'/usersimage/menu_100_UA_inactive_7.png','menu_100_picture_inactive_7',NULL,'UA','2009-12-11 13:26:02','/usersimage/menu_100_UA_inactive_7.png','2009-12-11 13:26:02'),(0,'menu_100_picture_inactive_',8,'/usersimage/menu_100_UA_inactive_8.png','menu_100_picture_inactive_8',NULL,'UA','2009-12-11 13:30:08','/usersimage/menu_100_UA_inactive_8.png','2009-12-11 13:30:08'),(0,'menu_100_picture_inactive_',13,'/usersimage/menu_100_UA_inactive_13.png','menu_100_picture_inactive_13','','UA','2010-01-08 18:02:59','/usersimage/menu_100_UA_inactive_13.png','2010-01-08 18:02:59'),(0,'menu_100_picture_inactive_',27,'/usersimage/menu_100_UA_inactive_27.png','menu_100_picture_inactive_27','','UA','2010-01-13 14:54:04','/usersimage/menu_100_UA_inactive_27.png','2010-01-13 14:54:04'),(0,'menu_101_',1,' ','menu_101_1',NULL,'UA','2009-11-26 13:28:18',' ','2009-11-26 13:28:18'),(0,'menu_101_',2,'Про 36.6','menu_101_2',NULL,'UA','2009-11-26 13:37:04','Про 36.6','2009-11-26 13:37:04'),(0,'menu_101_',3,'Поточні проекти','menu_101_3',NULL,'UA','2009-11-26 14:02:47','Поточні проекти','2009-11-26 14:02:47'),(0,'menu_101_',4,'Моя 36.6','menu_101_4',NULL,'UA','2009-11-26 14:03:31','Моя 36.6','2009-11-26 14:03:31'),(0,'menu_101_',5,'Новини','menu_101_5',NULL,'UA','2009-11-26 14:04:15','Новини','2009-11-26 14:04:15'),(0,'menu_101_',6,'Підсумки досліджень','menu_101_6',NULL,'UA','2009-11-26 14:05:14','Підсумки досліджень','2009-11-26 14:05:14'),(0,'menu_10_',1,' ','menu_10_1',NULL,'UA','2009-11-26 13:28:18',' ','2009-11-26 13:28:18'),(0,'menu_10_',2,'TNS в Украине','menu_10_2',NULL,'RU','2010-03-01 13:16:38','TNS в Украине','2010-03-01 13:16:38'),(0,'menu_10_',2,'TNS в Україні','menu_10_2','','UA','2010-03-22 15:20:52','TNS в Україні','2010-03-22 15:20:52'),(0,'menu_10_',3,'Контакты','menu_10_3',NULL,'RU','2010-03-01 13:16:53','Контакты','2010-03-01 13:16:53'),(0,'menu_10_',3,'Контакти','menu_10_3','','UA','2010-03-01 13:16:46','Контакти','2010-03-01 13:16:46'),(0,'menu_10_',4,'Регистрация','menu_10_4',NULL,'RU','2010-03-01 13:17:14','Регистрация','2010-03-01 13:17:14'),(0,'menu_10_',4,'Реєстрація','menu_10_4','','UA','2010-03-22 15:20:58','Реєстрація','2010-03-22 15:20:58'),(0,'menu_10_',5,'Ви зайшли як:','menu_10_5',NULL,'UA','2009-12-15 15:40:19','Ви зайшли як:','2009-12-15 15:40:19'),(0,'menu_10_',6,'Reset password','menu_10_6','','UA','2009-12-25 10:09:26','Reset password','2009-12-25 10:09:26'),(0,'menu_11_',1,' ','menu_11_1',NULL,'UA','2009-11-26 15:09:29',' ','2009-11-26 15:09:29'),(0,'menu_11_',2,'TNS в Україні','menu_11_2',NULL,'UA','2009-11-27 12:27:47','TNS в Україні','2009-11-27 12:27:47'),(0,'menu_11_',3,'Контакти','menu_11_3',NULL,'UA','2009-11-27 12:29:14','Контакти','2009-11-27 12:29:14'),(0,'menu_300_',1,' ','menu_300_1',NULL,'UA','2009-11-26 16:29:31',' ','2009-11-26 16:29:31'),(0,'menu_300_',2,'Мапа сайту','menu_300_2',NULL,'UA','2009-11-26 16:32:59','Мапа сайту','2009-11-26 16:32:59'),(0,'menu_300_',3,'Конфіденційність','menu_300_3','','UA','2010-02-24 11:20:19','Конфіденційність','2010-02-24 11:20:19'),(0,'menu_300_',4,'Відповідальність','menu_300_4',NULL,'UA','2009-11-26 16:45:20','Відповідальність','2009-11-26 16:45:20'),(0,'menu_300_',5,'Правила участі','menu_300_5',NULL,'UA','2009-11-26 16:46:30','Правила участі','2009-11-26 16:46:30'),(0,'menu_300_',6,'extraitem','menu_300_6',NULL,'UA','2010-01-19 10:10:39','extraitem','2010-01-19 10:10:39'),(0,'menu_40028_',1,' TNS в Україні','menu_40028_1','','UA','2010-01-13 14:36:00',' TNS в Україні','2010-01-13 14:36:00'),(0,'menu_40029_',1,' Відповідальність','menu_40029_1','','UA','2010-01-13 14:26:45',' Відповідальність','2010-01-13 14:26:45'),(0,'menu_40030_',1,' Моя 36.6','menu_40030_1','','UA','2009-12-30 11:29:33',' Моя 36.6','2009-12-30 11:29:33'),(0,'menu_40031_',1,' ','menu_40031_1',NULL,'UA','2009-12-25 14:35:28',' ','2009-12-25 14:35:28'),(0,'menu_40032_',1,' Контакти','menu_40032_1','','UA','2010-01-13 14:37:08',' Контакти','2010-01-13 14:37:08'),(0,'menu_40033_',1,' Конфіденційність','menu_40033_1','','UA','2010-02-25 13:59:42',' Конфіденційність','2010-02-25 13:59:42'),(0,'menu_40034_',1,' Мапа сайту','menu_40034_1','','UA','2010-01-12 07:16:23',' Мапа сайту','2010-01-12 07:16:23'),(0,'menu_40035_',1,' ','menu_40035_1',NULL,'UA','2009-12-25 14:42:55',' ','2009-12-25 14:42:55'),(0,'menu_40036_',1,' ','menu_40036_1',NULL,'UA','2010-01-30 08:48:52',' ','2010-01-30 08:48:52'),(0,'menu_40037_',1,' ','menu_40037_1',NULL,'UA','2009-12-30 11:32:46',' ','2009-12-30 11:32:46'),(0,'menu_40038_',1,' ','menu_40038_1',NULL,'UA','2009-12-30 11:24:10',' ','2009-12-30 11:24:10'),(0,'menu_40039_',1,' ','menu_40039_1',NULL,'UA','2009-12-25 15:07:09',' ','2009-12-25 15:07:09'),(0,'menu_40045_',1,' Поточні проекти','menu_40045_1','','UA','2009-12-30 11:23:37',' Поточні проекти','2009-12-30 11:23:37'),(0,'menu_40046_',1,'Правила участі','menu_40046_1','','UA','2010-01-13 14:25:47','Правила участі','2010-01-13 14:25:47'),(0,'menu_40047_',1,' ','menu_40047_1',NULL,'UA','2009-12-25 09:42:14',' ','2009-12-25 09:42:14'),(0,'menu_40048_',1,' ','menu_40048_1',NULL,'UA','2010-01-09 18:51:01',' ','2010-01-09 18:51:01'),(0,'menu_40052_',1,' ','menu_40052_1',NULL,'UA','2009-12-25 15:07:13',' ','2009-12-25 15:07:13'),(0,'menu_40054_',1,' ','menu_40054_1',NULL,'UA','2009-12-25 14:57:21',' ','2009-12-25 14:57:21'),(0,'menu_40057_',1,' Відновлення паролю','menu_40057_1','','UA','2009-12-13 19:49:20',' Відновлення паролю','2009-12-13 19:49:20'),(0,'menu_40059_',1,' Підтвердження реєстрації','menu_40059_1','','UA','2009-12-13 12:08:37',' Підтвердження реєстрації','2009-12-13 12:08:37'),(0,'menu_40060_',1,' Оновлення паролю','menu_40060_1','','UA','2010-01-28 16:55:08',' Оновлення паролю','2010-01-28 16:55:08'),(0,'menu_40061_',1,'Реєстрацію завершено','menu_40061_1','','UA','2010-01-14 18:36:54','Реєстрацію завершено','2010-01-14 18:36:54'),(0,'menu_40062_',1,'Підтвердження реєстрації','menu_40062_1','','UA','2010-01-27 04:52:25','Підтвердження реєстрації','2010-01-27 04:52:25'),(0,'menu_40063_',1,' Сторінка не знайдена','menu_40063_1','','UA','2009-12-13 12:04:32',' Сторінка не знайдена','2009-12-13 12:04:32'),(0,'menu_40064_',1,' Нагадування паролю','menu_40064_1','','UA','2010-02-01 16:39:39',' Нагадування паролю','2010-02-01 16:39:39'),(0,'menu_40066_',1,' Дані оновлено','menu_40066_1','','UA','2010-01-18 15:33:47',' Дані оновлено','2010-01-18 15:33:47'),(0,'menu_40067_',1,' Немає доступу','menu_40067_1','','UA','2009-12-29 21:57:37',' Немає доступу','2009-12-29 21:57:37'),(0,'menu_40068_',1,' Авторизація','menu_40068_1','','UA','2010-01-05 23:47:25',' Авторизація','2010-01-05 23:47:25'),(0,'menu_40088_',1,' Завершення проекту','menu_40088_1','','UA','2010-01-31 15:24:00',' Завершення проекту','2010-01-31 15:24:00'),(0,'menu_40089_',1,' ','menu_40089_1',NULL,'UA','2010-01-19 08:28:55',' ','2010-01-19 08:28:55'),(0,'menu_40090_',1,' Новий пароль збережено','menu_40090_1','','UA','2010-01-19 11:59:30',' Новий пароль збережено','2010-01-19 11:59:30'),(0,'menu_400_',1,' Підтвердження реєстрації','menu_400_1','','UA','2009-12-11 15:32:13',' Підтвердження реєстрації','2009-12-11 15:32:13'),(0,'menu_400_',2,'Підтвердження реєстрації','menu_400_2',NULL,'UA','2009-12-11 15:29:34','Підтвердження реєстрації','2009-12-11 15:29:34'),(0,'menu_90029_',1,'FAQ','menu_90029_1','','UA','2010-01-14 16:07:17','FAQ','2010-01-14 16:07:17'),(0,'menu_90029_',2,'Форма реєстрації','menu_90029_2',NULL,'UA','2010-01-14 16:08:57','Форма реєстрації','2010-01-14 16:08:57'),(0,'menu_90030_',1,'FAQ','menu_90030_1','','UA','2010-01-14 08:23:01','FAQ','2010-01-14 08:23:01'),(0,'menu_90030_',2,'TNS Opros Новости','menu_90030_2',NULL,'RU','2010-03-29 18:10:21','TNS Opros Новости','2010-03-29 18:10:21'),(0,'menu_90030_',2,'TNS Opros Новини','menu_90030_2','','UA','2010-03-29 18:10:14','TNS Opros Новини','2010-03-29 18:10:14'),(0,'menu_90031_',1,'FAQ','menu_90031_1','','UA','2010-01-14 08:55:23','FAQ','2010-01-14 08:55:23'),(0,'menu_90031_',2,'Система заохочення','menu_90031_2',NULL,'UA','2010-01-14 08:56:05','Система заохочення','2010-01-14 08:56:05'),(0,'menu_90032_',1,' ','menu_90032_1',NULL,'UA','2010-01-19 10:32:16',' ','2010-01-19 10:32:16'),(0,'menu_90033_',1,'FAQ','menu_90033_1','','UA','2010-01-14 16:07:48','FAQ','2010-01-14 16:07:48'),(0,'menu_90033_',2,'Форма реєстрації','menu_90033_2',NULL,'UA','2010-01-14 16:10:06','Форма реєстрації','2010-01-14 16:10:06'),(0,'menu_90034_',1,'FAQ','menu_90034_1','','UA','2010-01-22 14:03:35','FAQ','2010-01-22 14:03:35'),(0,'menu_90035_',1,'FAQ','menu_90035_1','','UA','2010-01-13 21:51:20','FAQ','2010-01-13 21:51:20'),(0,'menu_90035_',2,'Мої бали','menu_90035_2',NULL,'UA','2010-01-14 06:40:35','Мої бали','2010-01-14 06:40:35'),(0,'menu_90035_',3,'Результати досліджень','menu_90035_3',NULL,'UA','2010-01-14 06:52:43','Результати досліджень','2010-01-14 06:52:43'),(0,'menu_90036_',1,' ','menu_90036_1',NULL,'UA','2010-01-30 08:48:52',' ','2010-01-30 08:48:52'),(0,'menu_90037_',1,'FAQ','menu_90037_1','','UA','2010-01-14 08:29:14','FAQ','2010-01-14 08:29:14'),(0,'menu_90037_',2,'Корисний контакт','menu_90037_2',NULL,'UA','2010-01-14 08:28:53','Корисний контакт','2010-01-14 08:28:53'),(0,'menu_90037_',3,'TNS 36.6 Новини','menu_90037_3',NULL,'UA','2010-01-14 08:30:06','TNS 36.6 Новини','2010-01-14 08:30:06'),(0,'menu_90038_',1,' ','menu_90038_1',NULL,'UA','2010-03-29 17:53:44',' ','2010-03-29 17:53:44'),(0,'menu_90039_',1,'Корисний контакт','menu_90039_1','','UA','2010-01-14 10:16:17','Корисний контакт','2010-01-14 10:16:17'),(0,'menu_90039_',2,'Результати досліджень','menu_90039_2',NULL,'UA','2010-01-14 10:17:25','Результати досліджень','2010-01-14 10:17:25'),(0,'menu_90039_',3,'Поточні проекти','menu_90039_3',NULL,'UA','2010-01-14 10:18:25','Поточні проекти','2010-01-14 10:18:25'),(0,'menu_90040_',1,'FAQ','menu_90040_1','','UA','2010-01-14 09:59:18','FAQ','2010-01-14 09:59:18'),(0,'menu_90040_',2,'Форма реєстрації','menu_90040_2',NULL,'UA','2010-01-14 10:00:16','Форма реєстрації','2010-01-14 10:00:16'),(0,'menu_90040_',3,'Результати досліджень','menu_90040_3',NULL,'UA','2010-01-14 10:04:05','Результати досліджень','2010-01-14 10:04:05'),(0,'menu_90042_',1,'FAQ','menu_90042_1','','UA','2010-01-14 07:34:20','FAQ','2010-01-14 07:34:20'),(0,'menu_90042_',2,'Мої бали','menu_90042_2',NULL,'UA','2010-01-14 07:35:11','Мої бали','2010-01-14 07:35:11'),(0,'menu_90042_',3,'Результати досліджень','menu_90042_3',NULL,'UA','2010-01-14 07:36:13','Результати досліджень','2010-01-14 07:36:13'),(0,'menu_90043_',1,' ','menu_90043_1',NULL,'UA','2010-01-19 11:23:21',' ','2010-01-19 11:23:21'),(0,'menu_90045_',1,'FAQ','menu_90045_1','','UA','2010-01-14 07:56:50','FAQ','2010-01-14 07:56:50'),(0,'menu_90045_',2,'Мої бали','menu_90045_2',NULL,'UA','2010-01-14 07:57:43','Мої бали','2010-01-14 07:57:43'),(0,'menu_90045_',3,'TNS 36.6 Новини','menu_90045_3',NULL,'UA','2010-01-14 08:07:49','TNS 36.6 Новини','2010-01-14 08:07:49'),(0,'menu_90046_',1,'FAQ','menu_90046_1','','UA','2010-01-14 16:05:50','FAQ','2010-01-14 16:05:50'),(0,'menu_90046_',2,'Форма реєстрації','menu_90046_2',NULL,'UA','2010-01-14 16:11:01','Форма реєстрації','2010-01-14 16:11:01'),(0,'menu_90047_',1,'Корисний контакт','menu_90047_1','','UA','2010-01-14 10:12:37','Корисний контакт','2010-01-14 10:12:37'),(0,'menu_90047_',2,'TNS Opros Новини','menu_90047_2','','UA','2010-03-30 12:36:53','TNS Opros Новини','2010-03-30 12:36:53'),(0,'menu_90051_',1,'FAQ','menu_90051_1','','UA','2010-01-14 10:05:11','FAQ','2010-01-14 10:05:11'),(0,'menu_90051_',2,'Форма реєстрації','menu_90051_2',NULL,'UA','2010-01-14 10:06:16','Форма реєстрації','2010-01-14 10:06:16'),(0,'menu_90051_',3,'Результати досліджень','menu_90051_3',NULL,'UA','2010-01-14 10:07:38','Результати досліджень','2010-01-14 10:07:38'),(0,'menu_90052_',1,'Мої бали','menu_90052_1','','UA','2010-01-14 10:24:29','Мої бали','2010-01-14 10:24:29'),(0,'menu_90052_',2,'Корисний контакт','menu_90052_2','','UA','2010-01-29 17:47:31','Корисний контакт','2010-01-29 17:47:31'),(0,'menu_90052_',3,'Конвертація балів','menu_90052_3',NULL,'UA','2010-01-14 10:27:13','Конвертація балів','2010-01-14 10:27:13'),(0,'menu_90053_',1,' ','menu_90053_1',NULL,'UA','2010-01-19 11:23:35',' ','2010-01-19 11:23:35'),(0,'menu_90055_',1,'FAQ','menu_90055_1','','UA','2010-01-14 07:39:21','FAQ','2010-01-14 07:39:21'),(0,'menu_90055_',2,'Поточні проекти','menu_90055_2',NULL,'UA','2010-01-14 07:40:56','Поточні проекти','2010-01-14 07:40:56'),(0,'menu_90055_',3,'Результати досліджень','menu_90055_3',NULL,'UA','2010-01-14 07:51:18','Результати досліджень','2010-01-14 07:51:18'),(0,'menu_90057_',1,'FAQ','menu_90057_1','','UA','2010-01-14 10:45:36','FAQ','2010-01-14 10:45:36'),(0,'menu_90057_',2,'Корисний контакт','menu_90057_2','','UA','2010-01-14 11:50:32','Корисний контакт','2010-01-14 11:50:32'),(0,'menu_90059_',1,'Корисний контакт','menu_90059_1','','UA','2010-01-14 10:49:42','Корисний контакт','2010-01-14 10:49:42'),(0,'menu_90059_',2,'TNS 36.6 Новини','menu_90059_2',NULL,'UA','2010-01-14 10:50:44','TNS 36.6 Новини','2010-01-14 10:50:44'),(0,'menu_90060_',1,'FAQ','menu_90060_1','','UA','2010-01-28 16:55:34','FAQ','2010-01-28 16:55:34'),(0,'menu_90061_',1,'FAQ','menu_90061_1','','UA','2010-01-14 18:05:22','FAQ','2010-01-14 18:05:22'),(0,'menu_90062_',1,'FAQ','menu_90062_1','','UA','2010-01-27 04:52:53','FAQ','2010-01-27 04:52:53'),(0,'menu_90063_',1,'FAQ','menu_90063_1','','UA','2010-01-14 11:00:18','FAQ','2010-01-14 11:00:18'),(0,'menu_90064_',1,'FAQ','menu_90064_1','','UA','2010-02-01 16:40:19','FAQ','2010-02-01 16:40:19'),(0,'menu_90066_',1,'FAQ','menu_90066_1','','UA','2010-01-18 15:38:54','FAQ','2010-01-18 15:38:54'),(0,'menu_90067_',1,' ','menu_90067_1',NULL,'UA','2010-01-19 11:19:32',' ','2010-01-19 11:19:32'),(0,'menu_90068_',1,' FAQ','menu_90068_1','','UA','2010-01-14 06:37:42',' FAQ','2010-01-14 06:37:42'),(0,'menu_90068_',2,'Форма реєстрації','menu_90068_2',NULL,'UA','2010-01-14 06:35:16','Форма реєстрації','2010-01-14 06:35:16'),(0,'menu_90086_',1,'Форма реєстрації','menu_90086_1','','UA','2010-01-14 10:09:31','Форма реєстрації','2010-01-14 10:09:31'),(0,'menu_90086_',2,'Результати досліджень','menu_90086_2',NULL,'UA','2010-01-14 10:10:27','Результати досліджень','2010-01-14 10:10:27'),(0,'menu_90086_',3,'Корисний контакт','menu_90086_3','','UA','2010-01-29 17:48:15','Корисний контакт','2010-01-29 17:48:15'),(0,'menu_90088_',1,'FAQ','menu_90088_1','','UA','2010-01-31 15:25:03','FAQ','2010-01-31 15:25:03'),(0,'menu_90089_',1,' ','menu_90089_1',NULL,'UA','2010-01-19 08:28:55',' ','2010-01-19 08:28:55'),(0,'menu_90090_',1,'FAQ','menu_90090_1','','UA','2010-01-19 11:59:55','FAQ','2010-01-19 11:59:55'),(0,'menu_lang_dependent_url_100_',1,'','menu_lang_dependent_url_100_1',NULL,'EN','2009-11-14 21:10:09','','2009-11-14 21:10:09'),(0,'menu_lang_dependent_url_100_',6,'','menu_lang_dependent_url_100_6',NULL,'UA','2009-12-11 13:22:58','','2009-12-11 13:22:58'),(0,'menu_lang_dependent_url_100_',9,'http://2kgroup.com/','menu_lang_dependent_url_100_9','','UA','2009-12-11 13:57:36','http://2kgroup.com/','2009-12-11 13:57:36'),(0,'menu_lang_dependent_url_100_',22,'','menu_lang_dependent_url_100_22',NULL,'UA','2010-01-12 08:32:05','','2010-01-12 08:32:05'),(0,'menu_lang_dependent_url_100_',23,'','menu_lang_dependent_url_100_23',NULL,'UA','2010-01-12 08:32:55','','2010-01-12 08:32:55'),(0,'menu_lang_dependent_url_100_',24,'','menu_lang_dependent_url_100_24',NULL,'UA','2010-01-12 08:33:57','','2010-01-12 08:33:57'),(0,'menu_lang_dependent_url_100_',25,'','menu_lang_dependent_url_100_25',NULL,'UA','2010-01-12 08:34:46','','2010-01-12 08:34:46'),(0,'menu_lang_dependent_url_100_',26,'','menu_lang_dependent_url_100_26',NULL,'UA','2010-01-12 08:35:39','','2010-01-12 08:35:39'),(0,'menu_lang_dependent_url_101_',1,'','menu_lang_dependent_url_101_1',NULL,'UA','2009-11-26 13:28:18','','2009-11-26 13:28:18'),(0,'menu_lang_dependent_url_101_',2,'','menu_lang_dependent_url_101_2',NULL,'UA','2009-11-26 13:37:04','','2009-11-26 13:37:04'),(0,'menu_lang_dependent_url_101_',3,'','menu_lang_dependent_url_101_3',NULL,'UA','2009-11-26 14:02:47','','2009-11-26 14:02:47'),(0,'menu_lang_dependent_url_101_',4,'','menu_lang_dependent_url_101_4',NULL,'UA','2009-11-26 14:03:31','','2009-11-26 14:03:31'),(0,'menu_lang_dependent_url_101_',5,'','menu_lang_dependent_url_101_5',NULL,'UA','2009-11-26 14:04:15','','2009-11-26 14:04:15'),(0,'menu_lang_dependent_url_101_',6,'','menu_lang_dependent_url_101_6',NULL,'UA','2009-11-26 14:05:14','','2009-11-26 14:05:14'),(0,'menu_lang_dependent_url_10_',1,'','menu_lang_dependent_url_10_1',NULL,'UA','2009-11-26 13:28:18','','2009-11-26 13:28:18'),(0,'menu_lang_dependent_url_10_',2,'http://www.tns-ua.com','menu_lang_dependent_url_10_2',NULL,'RU','2010-03-01 13:16:38','http://www.tns-ua.com','2010-03-01 13:16:38'),(0,'menu_lang_dependent_url_10_',2,'http://www.tns-ua.com','menu_lang_dependent_url_10_2','','UA','2010-03-22 15:20:52','http://www.tns-ua.com','2010-03-22 15:20:52'),(0,'menu_lang_dependent_url_10_',5,'#','menu_lang_dependent_url_10_5',NULL,'UA','2009-12-15 15:40:19','#','2009-12-15 15:40:19'),(0,'menu_lang_dependent_url_11_',1,'','menu_lang_dependent_url_11_1',NULL,'UA','2009-11-26 15:09:29','','2009-11-26 15:09:29'),(0,'menu_lang_dependent_url_11_',2,'','menu_lang_dependent_url_11_2',NULL,'UA','2009-11-27 12:27:48','','2009-11-27 12:27:48'),(0,'menu_lang_dependent_url_11_',3,'','menu_lang_dependent_url_11_3',NULL,'UA','2009-11-27 12:29:14','','2009-11-27 12:29:14'),(0,'menu_lang_dependent_url_300_',1,'','menu_lang_dependent_url_300_1',NULL,'UA','2009-11-26 16:29:31','','2009-11-26 16:29:31'),(0,'menu_lang_dependent_url_300_',2,'','menu_lang_dependent_url_300_2',NULL,'UA','2009-11-26 16:32:59','','2009-11-26 16:32:59'),(0,'menu_lang_dependent_url_300_',4,'','menu_lang_dependent_url_300_4',NULL,'UA','2009-11-26 16:45:20','','2009-11-26 16:45:20'),(0,'menu_lang_dependent_url_300_',5,'','menu_lang_dependent_url_300_5',NULL,'UA','2009-11-26 16:46:30','','2009-11-26 16:46:30'),(0,'menu_lang_dependent_url_300_',6,'www.tns-ua.com','menu_lang_dependent_url_300_6',NULL,'UA','2010-01-19 10:10:39','www.tns-ua.com','2010-01-19 10:10:39'),(0,'menu_lang_dependent_url_40031_',1,'','menu_lang_dependent_url_40031_1',NULL,'UA','2009-12-25 14:35:28','','2009-12-25 14:35:28'),(0,'menu_lang_dependent_url_40035_',1,'','menu_lang_dependent_url_40035_1',NULL,'UA','2009-12-25 14:42:55','','2009-12-25 14:42:55'),(0,'menu_lang_dependent_url_40036_',1,'','menu_lang_dependent_url_40036_1',NULL,'UA','2010-01-30 08:48:52','','2010-01-30 08:48:52'),(0,'menu_lang_dependent_url_40037_',1,'','menu_lang_dependent_url_40037_1',NULL,'UA','2009-12-30 11:32:46','','2009-12-30 11:32:46'),(0,'menu_lang_dependent_url_40038_',1,'','menu_lang_dependent_url_40038_1',NULL,'UA','2009-12-30 11:24:10','','2009-12-30 11:24:10'),(0,'menu_lang_dependent_url_40039_',1,'','menu_lang_dependent_url_40039_1',NULL,'UA','2009-12-25 15:07:09','','2009-12-25 15:07:09'),(0,'menu_lang_dependent_url_40047_',1,'','menu_lang_dependent_url_40047_1',NULL,'UA','2009-12-25 09:42:14','','2009-12-25 09:42:14'),(0,'menu_lang_dependent_url_40048_',1,'','menu_lang_dependent_url_40048_1',NULL,'UA','2010-01-09 18:51:01','','2010-01-09 18:51:01'),(0,'menu_lang_dependent_url_40052_',1,'','menu_lang_dependent_url_40052_1',NULL,'UA','2009-12-25 15:07:13','','2009-12-25 15:07:13'),(0,'menu_lang_dependent_url_40054_',1,'','menu_lang_dependent_url_40054_1',NULL,'UA','2009-12-25 14:57:21','','2009-12-25 14:57:21'),(0,'menu_lang_dependent_url_40089_',1,'','menu_lang_dependent_url_40089_1',NULL,'UA','2010-01-19 08:28:55','','2010-01-19 08:28:55'),(0,'menu_lang_dependent_url_400_',2,'','menu_lang_dependent_url_400_2',NULL,'UA','2009-12-11 15:29:34','','2009-12-11 15:29:34'),(0,'menu_lang_dependent_url_90029_',1,'#','menu_lang_dependent_url_90029_1','','UA','2010-01-14 16:07:17','#','2010-01-14 16:07:17'),(0,'menu_lang_dependent_url_90029_',2,'#','menu_lang_dependent_url_90029_2',NULL,'UA','2010-01-14 16:08:57','#','2010-01-14 16:08:57'),(0,'menu_lang_dependent_url_90030_',1,'#','menu_lang_dependent_url_90030_1','','UA','2010-01-14 08:23:01','#','2010-01-14 08:23:01'),(0,'menu_lang_dependent_url_90030_',2,'#','menu_lang_dependent_url_90030_2',NULL,'RU','2010-03-29 18:10:21','#','2010-03-29 18:10:21'),(0,'menu_lang_dependent_url_90030_',2,'#','menu_lang_dependent_url_90030_2','','UA','2010-03-29 18:10:14','#','2010-03-29 18:10:14'),(0,'menu_lang_dependent_url_90031_',1,'#','menu_lang_dependent_url_90031_1','','UA','2010-01-14 08:55:23','#','2010-01-14 08:55:23'),(0,'menu_lang_dependent_url_90031_',2,'#','menu_lang_dependent_url_90031_2',NULL,'UA','2010-01-14 08:56:05','#','2010-01-14 08:56:05'),(0,'menu_lang_dependent_url_90032_',1,'','menu_lang_dependent_url_90032_1',NULL,'UA','2010-01-19 10:32:16','','2010-01-19 10:32:16'),(0,'menu_lang_dependent_url_90033_',1,'#','menu_lang_dependent_url_90033_1','','UA','2010-01-14 16:07:48','#','2010-01-14 16:07:48'),(0,'menu_lang_dependent_url_90033_',2,'#','menu_lang_dependent_url_90033_2',NULL,'UA','2010-01-14 16:10:06','#','2010-01-14 16:10:06'),(0,'menu_lang_dependent_url_90034_',1,'#','menu_lang_dependent_url_90034_1','','UA','2010-01-22 14:03:35','#','2010-01-22 14:03:35'),(0,'menu_lang_dependent_url_90035_',1,'#','menu_lang_dependent_url_90035_1','','UA','2010-01-13 21:51:20','#','2010-01-13 21:51:20'),(0,'menu_lang_dependent_url_90035_',2,'№','menu_lang_dependent_url_90035_2',NULL,'UA','2010-01-14 06:40:35','№','2010-01-14 06:40:35'),(0,'menu_lang_dependent_url_90035_',3,'#','menu_lang_dependent_url_90035_3',NULL,'UA','2010-01-14 06:52:43','#','2010-01-14 06:52:43'),(0,'menu_lang_dependent_url_90036_',1,'','menu_lang_dependent_url_90036_1',NULL,'UA','2010-01-30 08:48:52','','2010-01-30 08:48:52'),(0,'menu_lang_dependent_url_90037_',1,'#','menu_lang_dependent_url_90037_1','','UA','2010-01-14 08:29:14','#','2010-01-14 08:29:14'),(0,'menu_lang_dependent_url_90037_',2,'#','menu_lang_dependent_url_90037_2',NULL,'UA','2010-01-14 08:28:53','#','2010-01-14 08:28:53'),(0,'menu_lang_dependent_url_90037_',3,'#','menu_lang_dependent_url_90037_3',NULL,'UA','2010-01-14 08:30:06','#','2010-01-14 08:30:06'),(0,'menu_lang_dependent_url_90038_',1,'','menu_lang_dependent_url_90038_1',NULL,'UA','2010-03-29 17:53:44','','2010-03-29 17:53:44'),(0,'menu_lang_dependent_url_90039_',1,'#','menu_lang_dependent_url_90039_1','','UA','2010-01-14 10:16:17','#','2010-01-14 10:16:17'),(0,'menu_lang_dependent_url_90039_',2,'#','menu_lang_dependent_url_90039_2',NULL,'UA','2010-01-14 10:17:25','#','2010-01-14 10:17:25'),(0,'menu_lang_dependent_url_90039_',3,'#','menu_lang_dependent_url_90039_3',NULL,'UA','2010-01-14 10:18:25','#','2010-01-14 10:18:25'),(0,'menu_lang_dependent_url_90040_',1,'#','menu_lang_dependent_url_90040_1','','UA','2010-01-14 09:59:18','#','2010-01-14 09:59:18'),(0,'menu_lang_dependent_url_90040_',2,'#','menu_lang_dependent_url_90040_2',NULL,'UA','2010-01-14 10:00:16','#','2010-01-14 10:00:16'),(0,'menu_lang_dependent_url_90040_',3,'#','menu_lang_dependent_url_90040_3',NULL,'UA','2010-01-14 10:04:05','#','2010-01-14 10:04:05'),(0,'menu_lang_dependent_url_90042_',1,'#','menu_lang_dependent_url_90042_1','','UA','2010-01-14 07:34:20','#','2010-01-14 07:34:20'),(0,'menu_lang_dependent_url_90042_',2,'#','menu_lang_dependent_url_90042_2',NULL,'UA','2010-01-14 07:35:11','#','2010-01-14 07:35:11'),(0,'menu_lang_dependent_url_90042_',3,'#','menu_lang_dependent_url_90042_3',NULL,'UA','2010-01-14 07:36:13','#','2010-01-14 07:36:13'),(0,'menu_lang_dependent_url_90043_',1,'','menu_lang_dependent_url_90043_1',NULL,'UA','2010-01-19 11:23:21','','2010-01-19 11:23:21'),(0,'menu_lang_dependent_url_90045_',1,'#','menu_lang_dependent_url_90045_1','','UA','2010-01-14 07:56:50','#','2010-01-14 07:56:50'),(0,'menu_lang_dependent_url_90045_',2,'#','menu_lang_dependent_url_90045_2',NULL,'UA','2010-01-14 07:57:43','#','2010-01-14 07:57:43'),(0,'menu_lang_dependent_url_90045_',3,'#','menu_lang_dependent_url_90045_3',NULL,'UA','2010-01-14 08:07:49','#','2010-01-14 08:07:49'),(0,'menu_lang_dependent_url_90046_',1,'#','menu_lang_dependent_url_90046_1','','UA','2010-01-14 16:05:50','#','2010-01-14 16:05:50'),(0,'menu_lang_dependent_url_90046_',2,'#','menu_lang_dependent_url_90046_2',NULL,'UA','2010-01-14 16:11:01','#','2010-01-14 16:11:01'),(0,'menu_lang_dependent_url_90047_',1,'#','menu_lang_dependent_url_90047_1','','UA','2010-01-14 10:12:37','#','2010-01-14 10:12:37'),(0,'menu_lang_dependent_url_90047_',2,'#','menu_lang_dependent_url_90047_2','','UA','2010-03-30 12:36:53','#','2010-03-30 12:36:53'),(0,'menu_lang_dependent_url_90051_',1,'#','menu_lang_dependent_url_90051_1','','UA','2010-01-14 10:05:11','#','2010-01-14 10:05:11'),(0,'menu_lang_dependent_url_90051_',2,'#','menu_lang_dependent_url_90051_2',NULL,'UA','2010-01-14 10:06:16','#','2010-01-14 10:06:16'),(0,'menu_lang_dependent_url_90051_',3,'#','menu_lang_dependent_url_90051_3',NULL,'UA','2010-01-14 10:07:39','#','2010-01-14 10:07:39'),(0,'menu_lang_dependent_url_90052_',1,'#','menu_lang_dependent_url_90052_1','','UA','2010-01-14 10:24:29','#','2010-01-14 10:24:29'),(0,'menu_lang_dependent_url_90052_',2,'#','menu_lang_dependent_url_90052_2','','UA','2010-01-29 17:47:31','#','2010-01-29 17:47:31'),(0,'menu_lang_dependent_url_90052_',3,'#','menu_lang_dependent_url_90052_3',NULL,'UA','2010-01-14 10:27:13','#','2010-01-14 10:27:13'),(0,'menu_lang_dependent_url_90053_',1,'','menu_lang_dependent_url_90053_1',NULL,'UA','2010-01-19 11:23:35','','2010-01-19 11:23:35'),(0,'menu_lang_dependent_url_90055_',1,'#','menu_lang_dependent_url_90055_1','','UA','2010-01-14 07:39:21','#','2010-01-14 07:39:21'),(0,'menu_lang_dependent_url_90055_',2,'#','menu_lang_dependent_url_90055_2',NULL,'UA','2010-01-14 07:40:56','#','2010-01-14 07:40:56'),(0,'menu_lang_dependent_url_90055_',3,'#','menu_lang_dependent_url_90055_3',NULL,'UA','2010-01-14 07:51:18','#','2010-01-14 07:51:18'),(0,'menu_lang_dependent_url_90057_',1,'#','menu_lang_dependent_url_90057_1','','UA','2010-01-14 10:45:36','#','2010-01-14 10:45:36'),(0,'menu_lang_dependent_url_90057_',2,'#','menu_lang_dependent_url_90057_2','','UA','2010-01-14 11:50:32','#','2010-01-14 11:50:32'),(0,'menu_lang_dependent_url_90059_',1,'#','menu_lang_dependent_url_90059_1','','UA','2010-01-14 10:49:42','#','2010-01-14 10:49:42'),(0,'menu_lang_dependent_url_90059_',2,'#','menu_lang_dependent_url_90059_2',NULL,'UA','2010-01-14 10:50:44','#','2010-01-14 10:50:44'),(0,'menu_lang_dependent_url_90060_',1,'#','menu_lang_dependent_url_90060_1','','UA','2010-01-28 16:55:34','#','2010-01-28 16:55:34'),(0,'menu_lang_dependent_url_90061_',1,'#','menu_lang_dependent_url_90061_1','','UA','2010-01-14 18:05:22','#','2010-01-14 18:05:22'),(0,'menu_lang_dependent_url_90062_',1,'#','menu_lang_dependent_url_90062_1','','UA','2010-01-27 04:52:53','#','2010-01-27 04:52:53'),(0,'menu_lang_dependent_url_90063_',1,'#','menu_lang_dependent_url_90063_1','','UA','2010-01-14 11:00:18','#','2010-01-14 11:00:18'),(0,'menu_lang_dependent_url_90064_',1,'#','menu_lang_dependent_url_90064_1','','UA','2010-02-01 16:40:19','#','2010-02-01 16:40:19'),(0,'menu_lang_dependent_url_90066_',1,'#','menu_lang_dependent_url_90066_1','','UA','2010-01-18 15:38:54','#','2010-01-18 15:38:54'),(0,'menu_lang_dependent_url_90067_',1,'','menu_lang_dependent_url_90067_1',NULL,'UA','2010-01-19 11:19:32','','2010-01-19 11:19:32'),(0,'menu_lang_dependent_url_90068_',1,'#','menu_lang_dependent_url_90068_1','','UA','2010-01-14 06:37:42','#','2010-01-14 06:37:42'),(0,'menu_lang_dependent_url_90068_',2,'#','menu_lang_dependent_url_90068_2',NULL,'UA','2010-01-14 06:35:16','#','2010-01-14 06:35:16'),(0,'menu_lang_dependent_url_90086_',1,'#','menu_lang_dependent_url_90086_1','','UA','2010-01-14 10:09:31','#','2010-01-14 10:09:31'),(0,'menu_lang_dependent_url_90086_',2,'#','menu_lang_dependent_url_90086_2',NULL,'UA','2010-01-14 10:10:27','#','2010-01-14 10:10:27'),(0,'menu_lang_dependent_url_90086_',3,'#','menu_lang_dependent_url_90086_3','','UA','2010-01-29 17:48:15','#','2010-01-29 17:48:15'),(0,'menu_lang_dependent_url_90088_',1,'#','menu_lang_dependent_url_90088_1','','UA','2010-01-31 15:25:03','#','2010-01-31 15:25:03'),(0,'menu_lang_dependent_url_90089_',1,'','menu_lang_dependent_url_90089_1',NULL,'UA','2010-01-19 08:28:55','','2010-01-19 08:28:55'),(0,'menu_lang_dependent_url_90090_',1,'#','menu_lang_dependent_url_90090_1','','UA','2010-01-19 11:59:55','#','2010-01-19 11:59:55'),(0,'menu_structure_',10,'a:4:{i:2;a:9:{s:3:\"url\";s:21:\"http://www.tns-ua.com\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"32\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:4;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"47\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:5;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"you_are_logged_as\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:4;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_10','','','2010-03-22 15:20:58','a:4:{i:2;a:9:{s:3:\"url\";s:21:\"http://www.tns-ua.com\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"32\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:4;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"47\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:5;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"you_are_logged_as\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:4;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-03-22 15:20:58'),(0,'menu_structure_',11,'a:2:{i:2;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"28\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}i:3;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"32\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}}','menu_structure_11','','','2009-12-11 14:08:20','a:2:{i:2;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"28\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}i:3;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"32\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}}','2009-12-11 14:08:20'),(0,'menu_structure_',100,'a:23:{i:2;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:6:\"999999\";s:3:\"sat\";s:2:\"35\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:6:\"FF0093\";s:3:\"sat\";s:2:\"47\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:7;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:6:\"FF0093\";s:3:\"sat\";s:2:\"45\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:8;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:6:\"47B3B8\";s:3:\"sat\";s:2:\"30\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:10;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"47\";s:6:\"parent\";s:1:\"3\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:11;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"39\";s:6:\"parent\";s:1:\"3\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:12;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"52\";s:6:\"parent\";s:1:\"3\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:13;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:6:\"0086D4\";s:3:\"sat\";s:1:\"1\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:14;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"45\";s:6:\"parent\";s:1:\"7\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:15;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"30\";s:6:\"parent\";s:1:\"8\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:16;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"37\";s:6:\"parent\";s:1:\"8\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:17;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"31\";s:6:\"parent\";s:1:\"8\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";s:5:\"admin\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:19;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"35\";s:6:\"parent\";s:1:\"2\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:20;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"42\";s:6:\"parent\";s:1:\"2\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:21;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"55\";s:6:\"parent\";s:1:\"2\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:23;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:1:\"1\";s:6:\"parent\";s:2:\"13\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:25;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"44\";s:6:\"parent\";s:1:\"4\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:26;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"53\";s:6:\"parent\";s:1:\"4\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:27;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:6:\"8A81BA\";s:3:\"sat\";s:2:\"40\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:31;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:28;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"40\";s:6:\"parent\";s:2:\"27\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:29;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"51\";s:6:\"parent\";s:2:\"27\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:30;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"86\";s:6:\"parent\";s:2:\"27\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:31;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"52\";s:6:\"parent\";s:1:\"8\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:4;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_100','','','2010-04-06 18:30:29','a:23:{i:2;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:6:\"999999\";s:3:\"sat\";s:2:\"35\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:6:\"FF0093\";s:3:\"sat\";s:2:\"47\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:7;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:6:\"FF0093\";s:3:\"sat\";s:2:\"45\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:8;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:6:\"47B3B8\";s:3:\"sat\";s:2:\"30\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:10;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"47\";s:6:\"parent\";s:1:\"3\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:11;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"39\";s:6:\"parent\";s:1:\"3\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:12;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"52\";s:6:\"parent\";s:1:\"3\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:13;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:6:\"0086D4\";s:3:\"sat\";s:1:\"1\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:14;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"45\";s:6:\"parent\";s:1:\"7\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:15;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"30\";s:6:\"parent\";s:1:\"8\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:16;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"37\";s:6:\"parent\";s:1:\"8\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:17;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"31\";s:6:\"parent\";s:1:\"8\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";s:5:\"admin\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:19;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"35\";s:6:\"parent\";s:1:\"2\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:20;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"42\";s:6:\"parent\";s:1:\"2\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:21;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"55\";s:6:\"parent\";s:1:\"2\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:23;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:1:\"1\";s:6:\"parent\";s:2:\"13\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:25;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"44\";s:6:\"parent\";s:1:\"4\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:26;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"53\";s:6:\"parent\";s:1:\"4\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:27;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:6:\"8A81BA\";s:3:\"sat\";s:2:\"40\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:31;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:28;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"40\";s:6:\"parent\";s:2:\"27\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:29;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"51\";s:6:\"parent\";s:2:\"27\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:30;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"86\";s:6:\"parent\";s:2:\"27\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:31;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"52\";s:6:\"parent\";s:1:\"8\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:4;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-04-06 18:30:29'),(0,'menu_structure_',101,'a:6:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}i:2;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"48\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}i:3;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"45\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}i:4;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"38\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}i:5;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"40\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:4;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}i:6;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"43\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:5;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}}','menu_structure_101','','','2009-11-26 14:05:14','a:6:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}i:2;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"48\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}i:3;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"45\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}i:4;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"38\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}i:5;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"40\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:4;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}i:6;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"43\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:5;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}}','2009-11-26 14:05:14'),(0,'menu_structure_',300,'a:4:{i:2;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"34\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}i:3;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"33\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:4;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"29\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}i:5;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"46\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:4;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}}','menu_structure_300','','','2010-02-24 11:20:19','a:4:{i:2;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"34\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}i:3;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"33\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:4;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"29\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:3;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}i:5;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"46\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:4;s:6:\"shadow\";b:0;s:4:\"type\";s:0:\"\";}}','2010-02-24 11:20:19'),(0,'menu_structure_',400,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"59\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";}}','menu_structure_400','','','2009-12-11 15:32:13','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"59\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";}}','2009-12-11 15:32:13'),(0,'menu_structure_',40028,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"28\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_40028','','','2010-01-13 14:36:00','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"28\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-13 14:36:00'),(0,'menu_structure_',40029,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"29\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_40029','','','2010-01-13 14:26:45','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"29\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-13 14:26:45'),(0,'menu_structure_',40030,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"38\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";}}','menu_structure_40030','','','2009-12-30 11:29:33','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"38\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";}}','2009-12-30 11:29:33'),(0,'menu_structure_',40031,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','menu_structure_40031','','','2009-12-25 14:35:28','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','2009-12-25 14:35:28'),(0,'menu_structure_',40032,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"32\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_40032','','','2010-01-13 14:37:08','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"32\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-13 14:37:08'),(0,'menu_structure_',40033,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"33\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_40033','','','2010-02-25 13:59:42','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"33\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-02-25 13:59:42'),(0,'menu_structure_',40034,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"34\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_40034','','','2010-01-12 07:16:23','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"34\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-12 07:16:23'),(0,'menu_structure_',40035,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','menu_structure_40035','','','2009-12-25 14:42:55','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','2009-12-25 14:42:55'),(0,'menu_structure_',40036,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','menu_structure_40036','','','2010-01-30 08:48:52','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','2010-01-30 08:48:52'),(0,'menu_structure_',40037,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','menu_structure_40037','','','2009-12-30 11:32:46','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','2009-12-30 11:32:46'),(0,'menu_structure_',40038,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','menu_structure_40038','','','2009-12-30 11:24:10','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','2009-12-30 11:24:10'),(0,'menu_structure_',40039,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','menu_structure_40039','','','2009-12-25 15:07:09','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','2009-12-25 15:07:09'),(0,'menu_structure_',40040,'a:0:{}','',NULL,'','2009-12-17 14:59:07','a:0:{}','2009-12-17 14:59:07'),(0,'menu_structure_',40041,'a:0:{}','',NULL,'','2010-01-19 13:56:20','a:0:{}','2010-01-19 13:56:20'),(0,'menu_structure_',40042,'a:0:{}','',NULL,'','2010-01-09 18:59:55','a:0:{}','2010-01-09 18:59:55'),(0,'menu_structure_',40043,'a:0:{}','',NULL,'','2009-12-25 14:25:34','a:0:{}','2009-12-25 14:25:34'),(0,'menu_structure_',40044,'a:0:{}','',NULL,'','2010-02-17 22:07:41','a:0:{}','2010-02-17 22:07:41'),(0,'menu_structure_',40045,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"45\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";}}','menu_structure_40045','','','2009-12-30 11:23:37','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"45\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";}}','2009-12-30 11:23:37'),(0,'menu_structure_',40046,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"46\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_40046','','','2010-01-13 14:25:47','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"46\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-13 14:25:47'),(0,'menu_structure_',40047,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','menu_structure_40047','','','2009-12-25 09:42:14','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','2009-12-25 09:42:14'),(0,'menu_structure_',40048,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','menu_structure_40048','','','2010-01-09 18:51:01','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','2010-01-09 18:51:01'),(0,'menu_structure_',40049,'a:0:{}','',NULL,'','2010-01-13 13:59:50','a:0:{}','2010-01-13 13:59:50'),(0,'menu_structure_',40050,'a:0:{}','',NULL,'','2010-02-17 22:07:59','a:0:{}','2010-02-17 22:07:59'),(0,'menu_structure_',40051,'a:0:{}','',NULL,'','2010-01-14 10:04:30','a:0:{}','2010-01-14 10:04:30'),(0,'menu_structure_',40052,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','menu_structure_40052','','','2009-12-25 15:07:13','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','2009-12-25 15:07:13'),(0,'menu_structure_',40053,'a:0:{}','',NULL,'','2010-01-19 11:23:35','a:0:{}','2010-01-19 11:23:35'),(0,'menu_structure_',40054,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','menu_structure_40054','','','2009-12-25 14:57:21','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;}}','2009-12-25 14:57:21'),(0,'menu_structure_',40055,'a:0:{}','',NULL,'','2010-01-09 19:00:10','a:0:{}','2010-01-09 19:00:10'),(0,'menu_structure_',40057,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"57\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";}}','menu_structure_40057','','','2009-12-13 19:49:21','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"57\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";}}','2009-12-13 19:49:21'),(0,'menu_structure_',40059,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"59\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";}}','menu_structure_40059','','','2009-12-13 12:08:37','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"59\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";}}','2009-12-13 12:08:37'),(0,'menu_structure_',40060,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"60\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_40060','','','2010-01-28 16:55:08','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"60\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-28 16:55:08'),(0,'menu_structure_',40061,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"61\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_40061','','','2010-01-14 18:36:54','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"61\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 18:36:54'),(0,'menu_structure_',40062,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"62\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_40062','','','2010-01-27 04:52:25','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"62\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-27 04:52:25'),(0,'menu_structure_',40063,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"63\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";}}','menu_structure_40063','','','2009-12-13 12:04:32','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"63\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";}}','2009-12-13 12:04:32'),(0,'menu_structure_',40064,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"64\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_40064','','','2010-02-01 16:39:39','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"64\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-02-01 16:39:39'),(0,'menu_structure_',40065,'a:0:{}','',NULL,'','2009-12-25 12:06:59','a:0:{}','2009-12-25 12:06:59'),(0,'menu_structure_',40066,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"66\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_40066','','','2010-01-18 15:33:47','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"66\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-18 15:33:47'),(0,'menu_structure_',40067,'a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"67\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";}}','menu_structure_40067','','','2009-12-29 21:57:38','a:1:{i:1;a:8:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"67\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";}}','2009-12-29 21:57:38'),(0,'menu_structure_',40068,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"68\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_40068','','','2010-01-05 23:47:25','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"68\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-05 23:47:25'),(0,'menu_structure_',40086,'a:0:{}','',NULL,'','2010-01-13 11:54:49','a:0:{}','2010-01-13 11:54:49'),(0,'menu_structure_',40088,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"88\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_40088','','','2010-01-31 15:24:00','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"88\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:2:\"-1\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-31 15:24:00'),(0,'menu_structure_',40089,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','menu_structure_40089','','','2010-01-19 08:28:55','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','2010-01-19 08:28:55'),(0,'menu_structure_',40090,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"90\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_40090','','','2010-01-19 11:59:30','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";s:0:\"\";s:3:\"sat\";s:2:\"90\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-19 11:59:30'),(0,'menu_structure_',90028,'a:0:{}','',NULL,'','2010-01-16 23:46:08','a:0:{}','2010-01-16 23:46:08'),(0,'menu_structure_',90029,'a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"registration_form\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90029','','','2010-01-14 16:08:57','a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"registration_form\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 16:08:57'),(0,'menu_structure_',90030,'a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:4:\"news\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90030','','','2010-03-29 18:10:21','a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:4:\"news\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-03-29 18:10:21'),(0,'menu_structure_',90031,'a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:6:\"system\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90031','','','2010-01-14 08:56:05','a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:6:\"system\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 08:56:05'),(0,'menu_structure_',90032,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','menu_structure_90032','','','2010-01-19 10:32:16','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','2010-01-19 10:32:16'),(0,'menu_structure_',90033,'a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"registration_form\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90033','','','2010-01-14 16:10:06','a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"registration_form\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 16:10:06'),(0,'menu_structure_',90034,'a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90034','','','2010-01-22 14:03:35','a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-22 14:03:35'),(0,'menu_structure_',90035,'a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:3:\"№\";s:4:\"code\";s:9:\"my_points\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"results\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90035','','','2010-01-14 06:52:43','a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:3:\"№\";s:4:\"code\";s:9:\"my_points\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"results\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 06:52:43'),(0,'menu_structure_',90036,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','menu_structure_90036','','','2010-01-30 08:48:52','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','2010-01-30 08:48:52'),(0,'menu_structure_',90037,'a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"contact\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:-1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:4:\"news\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:5;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90037','','','2010-01-14 08:30:06','a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"contact\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:-1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:4:\"news\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:5;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 08:30:06'),(0,'menu_structure_',90038,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','menu_structure_90038','','','2010-03-29 17:53:44','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','2010-03-29 17:53:44'),(0,'menu_structure_',90039,'a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"contact\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"results\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:16:\"current_projects\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:30;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90039','','','2010-01-14 10:18:25','a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"contact\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"results\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:16:\"current_projects\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:30;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 10:18:25'),(0,'menu_structure_',90040,'a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"registration_form\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"results\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90040','','','2010-01-14 10:04:05','a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"registration_form\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"results\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 10:04:05'),(0,'menu_structure_',90041,'a:0:{}','',NULL,'','2010-01-19 13:56:20','a:0:{}','2010-01-19 13:56:20'),(0,'menu_structure_',90042,'a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:9:\"my_points\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"results\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90042','','','2010-01-14 07:36:13','a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:9:\"my_points\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"results\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 07:36:13'),(0,'menu_structure_',90043,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','menu_structure_90043','','','2010-01-19 11:23:21','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','2010-01-19 11:23:21'),(0,'menu_structure_',90044,'a:0:{}','',NULL,'','2010-02-17 22:07:41','a:0:{}','2010-02-17 22:07:41'),(0,'menu_structure_',90045,'a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:9:\"my_points\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:4:\"news\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90045','','','2010-01-14 08:07:49','a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:9:\"my_points\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:4:\"news\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 08:07:49'),(0,'menu_structure_',90046,'a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"registration_form\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90046','','','2010-01-14 16:11:01','a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"registration_form\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 16:11:01'),(0,'menu_structure_',90047,'a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"contact\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:4:\"news\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90047','','','2010-03-30 12:36:53','a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"contact\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:4:\"news\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-03-30 12:36:53'),(0,'menu_structure_',90048,'a:0:{}','',NULL,'','2010-01-19 13:55:51','a:0:{}','2010-01-19 13:55:51'),(0,'menu_structure_',90049,'a:0:{}','',NULL,'','2010-01-20 09:38:04','a:0:{}','2010-01-20 09:38:04'),(0,'menu_structure_',90050,'a:0:{}','',NULL,'','2010-02-17 22:07:59','a:0:{}','2010-02-17 22:07:59'),(0,'menu_structure_',90051,'a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"registration_form\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90051','','','2010-01-29 15:54:25','a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"registration_form\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-29 15:54:25'),(0,'menu_structure_',90052,'a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:9:\"my_points\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"contact\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"points_convertion\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:30;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90052','','','2010-01-29 17:47:31','a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:9:\"my_points\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"contact\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"points_convertion\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:30;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-29 17:47:31'),(0,'menu_structure_',90053,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','menu_structure_90053','','','2010-01-19 11:23:35','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','2010-01-19 11:23:35'),(0,'menu_structure_',90055,'a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:16:\"current_projects\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"results\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90055','','','2010-01-14 07:51:18','a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:16:\"current_projects\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:4:\"auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"results\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:2;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 07:51:18'),(0,'menu_structure_',90057,'a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"contact\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90057','','','2010-01-14 11:50:32','a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"contact\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 11:50:32'),(0,'menu_structure_',90059,'a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"contact\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:4:\"news\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90059','','','2010-01-14 10:50:44','a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"contact\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:4:\"news\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 10:50:44'),(0,'menu_structure_',90060,'a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90060','','','2010-01-28 16:55:34','a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-28 16:55:34'),(0,'menu_structure_',90061,'a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90061','','','2010-01-14 18:05:22','a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 18:05:22'),(0,'menu_structure_',90062,'a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90062','','','2010-01-27 04:52:53','a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-27 04:52:53'),(0,'menu_structure_',90063,'a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90063','','','2010-01-14 11:00:18','a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 11:00:18'),(0,'menu_structure_',90064,'a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90064','','','2010-02-01 16:40:19','a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-02-01 16:40:19'),(0,'menu_structure_',90065,'a:0:{}','',NULL,'','2010-01-18 19:00:18','a:0:{}','2010-01-18 19:00:18'),(0,'menu_structure_',90066,'a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90066','','','2010-01-18 15:38:54','a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-18 15:38:54'),(0,'menu_structure_',90067,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','menu_structure_90067','','','2010-01-19 11:19:32','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','2010-01-19 11:19:32'),(0,'menu_structure_',90068,'a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"registration_form\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90068','','','2010-01-14 06:37:42','a:2:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:6:\"_blank\";s:5:\"order\";i:10;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"registration_form\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:1;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-14 06:37:42'),(0,'menu_structure_',90086,'a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"registration_form\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"results\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"contact\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:-1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90086','','','2010-01-29 17:48:15','a:3:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:17:\"registration_form\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:10;s:6:\"shadow\";s:8:\"not_auth\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:2;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"results\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:20;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}i:3;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:7:\"contact\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:-1;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-29 17:48:15'),(0,'menu_structure_',90088,'a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90088','','','2010-01-31 15:25:03','a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-31 15:25:03'),(0,'menu_structure_',90089,'a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','menu_structure_90089','','','2010-01-19 08:28:55','a:1:{i:1;a:9:{s:3:\"url\";s:0:\"\";s:4:\"code\";N;s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:0:\"\";s:5:\"order\";i:0;s:6:\"shadow\";i:0;s:4:\"type\";N;s:8:\"selected\";N;}}','2010-01-19 08:28:55'),(0,'menu_structure_',90090,'a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','menu_structure_90090','','','2010-01-19 11:59:55','a:1:{i:1;a:9:{s:3:\"url\";s:1:\"#\";s:4:\"code\";s:3:\"faq\";s:3:\"sat\";s:0:\"\";s:6:\"parent\";i:0;s:9:\"open_type\";s:4:\"self\";s:5:\"order\";i:0;s:6:\"shadow\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"selected\";N;}}','2010-01-19 11:59:55'),(0,'menu_title_100_',1,NULL,'menu_title_100_1',NULL,'EN','2009-11-14 21:10:09',NULL,'2009-11-14 21:10:09'),(0,'menu_title_100_',2,'','menu_title_100_2','','RU','2010-03-29 17:15:18','','2010-03-29 17:15:18'),(0,'menu_title_100_',2,'','menu_title_100_2','','UA','2010-03-29 17:15:08','','2010-03-29 17:15:08'),(0,'menu_title_100_',3,'','menu_title_100_3',NULL,'RU','2010-03-01 13:18:17','','2010-03-01 13:18:17'),(0,'menu_title_100_',3,'','menu_title_100_3','','UA','2010-03-29 17:33:01','','2010-03-29 17:33:01'),(0,'menu_title_100_',4,'','menu_title_100_4','','UA','2010-01-13 12:02:58','','2010-01-13 12:02:58'),(0,'menu_title_100_',5,'','menu_title_100_5','','UA','2010-01-13 12:02:31','','2010-01-13 12:02:31'),(0,'menu_title_100_',6,'','menu_title_100_6',NULL,'UA','2009-12-11 13:22:58','','2009-12-11 13:22:58'),(0,'menu_title_100_',7,'','menu_title_100_7',NULL,'RU','2010-03-29 18:00:03','','2010-03-29 18:00:03'),(0,'menu_title_100_',7,'','menu_title_100_7','','UA','2010-03-29 17:59:53','','2010-03-29 17:59:53'),(0,'menu_title_100_',8,'','menu_title_100_8',NULL,'RU','2010-03-29 17:57:26','','2010-03-29 17:57:26'),(0,'menu_title_100_',8,'','menu_title_100_8','','UA','2010-03-29 17:57:18','','2010-03-29 17:57:18'),(0,'menu_title_100_',9,'','menu_title_100_9','','UA','2009-12-11 13:57:36','','2009-12-11 13:57:36'),(0,'menu_title_100_',10,'','menu_title_100_10',NULL,'RU','2010-03-29 17:33:23','','2010-03-29 17:33:23'),(0,'menu_title_100_',10,'','menu_title_100_10','','UA','2010-03-29 17:33:13','','2010-03-29 17:33:13'),(0,'menu_title_100_',11,'','menu_title_100_11',NULL,'RU','2010-03-29 17:33:40','','2010-03-29 17:33:40'),(0,'menu_title_100_',11,'','menu_title_100_11','','UA','2010-03-29 17:33:29','','2010-03-29 17:33:29'),(0,'menu_title_100_',12,'','menu_title_100_12',NULL,'RU','2010-03-29 17:34:33','','2010-03-29 17:34:33'),(0,'menu_title_100_',12,'','menu_title_100_12','','UA','2010-03-29 17:34:29','','2010-03-29 17:34:29'),(0,'menu_title_100_',13,'','menu_title_100_13',NULL,'RU','2010-03-01 13:17:43','','2010-03-01 13:17:43'),(0,'menu_title_100_',13,'','menu_title_100_13','','UA','2010-03-25 13:27:43','','2010-03-25 13:27:43'),(0,'menu_title_100_',14,'','menu_title_100_14',NULL,'RU','2010-03-29 18:00:27','','2010-03-29 18:00:27'),(0,'menu_title_100_',14,'','menu_title_100_14','','UA','2010-03-29 18:00:15','','2010-03-29 18:00:15'),(0,'menu_title_100_',15,'','menu_title_100_15',NULL,'RU','2010-03-29 17:57:47','','2010-03-29 17:57:47'),(0,'menu_title_100_',15,'','menu_title_100_15','','UA','2010-03-29 17:57:34','','2010-03-29 17:57:34'),(0,'menu_title_100_',16,'','menu_title_100_16',NULL,'RU','2010-03-29 17:58:05','','2010-03-29 17:58:05'),(0,'menu_title_100_',16,'','menu_title_100_16','','UA','2010-03-29 17:57:54','','2010-03-29 17:57:54'),(0,'menu_title_100_',17,'','menu_title_100_17',NULL,'RU','2010-03-29 17:58:20','','2010-03-29 17:58:20'),(0,'menu_title_100_',17,'','menu_title_100_17','','UA','2010-04-06 18:30:29','','2010-04-06 18:30:29'),(0,'menu_title_100_',18,'','menu_title_100_18','','UA','2009-12-30 14:39:25','','2009-12-30 14:39:25'),(0,'menu_title_100_',19,'','menu_title_100_19','','RU','2010-03-29 17:30:28','','2010-03-29 17:30:28'),(0,'menu_title_100_',19,'','menu_title_100_19','','UA','2010-03-29 17:30:25','','2010-03-29 17:30:25'),(0,'menu_title_100_',20,'','menu_title_100_20',NULL,'RU','2010-03-29 17:31:04','','2010-03-29 17:31:04'),(0,'menu_title_100_',20,'','menu_title_100_20','','UA','2010-03-29 17:31:00','','2010-03-29 17:31:00'),(0,'menu_title_100_',21,'','menu_title_100_21',NULL,'RU','2010-03-29 17:31:25','','2010-03-29 17:31:25'),(0,'menu_title_100_',21,'','menu_title_100_21','','UA','2010-03-29 17:31:14','','2010-03-29 17:31:14'),(0,'menu_title_100_',22,'','menu_title_100_22',NULL,'UA','2010-01-12 08:32:05','','2010-01-12 08:32:05'),(0,'menu_title_100_',23,'','menu_title_100_23',NULL,'UA','2010-01-12 08:32:55','','2010-01-12 08:32:55'),(0,'menu_title_100_',24,'','menu_title_100_24',NULL,'UA','2010-01-12 08:33:57','','2010-01-12 08:33:57'),(0,'menu_title_100_',25,'','menu_title_100_25',NULL,'UA','2010-01-12 08:34:46','','2010-01-12 08:34:46'),(0,'menu_title_100_',26,'','menu_title_100_26',NULL,'UA','2010-01-12 08:35:39','','2010-01-12 08:35:39'),(0,'menu_title_100_',27,'','menu_title_100_27',NULL,'RU','2010-03-01 13:20:34','','2010-03-01 13:20:34'),(0,'menu_title_100_',27,'','menu_title_100_27','','UA','2010-03-29 17:34:42','','2010-03-29 17:34:42'),(0,'menu_title_100_',28,'','menu_title_100_28',NULL,'RU','2010-03-29 17:35:15','','2010-03-29 17:35:15'),(0,'menu_title_100_',28,'','menu_title_100_28','','UA','2010-03-29 17:35:04','','2010-03-29 17:35:04'),(0,'menu_title_100_',29,'','menu_title_100_29',NULL,'RU','2010-03-29 17:35:42','','2010-03-29 17:35:42'),(0,'menu_title_100_',29,'','menu_title_100_29','','UA','2010-03-29 17:35:22','','2010-03-29 17:35:22'),(0,'menu_title_100_',30,'','menu_title_100_30','','UA','2010-03-29 17:35:47','','2010-03-29 17:35:47'),(0,'menu_title_100_',31,'','menu_title_100_31',NULL,'RU','2010-03-29 17:58:37','','2010-03-29 17:58:37'),(0,'menu_title_100_',31,'','menu_title_100_31','','UA','2010-04-06 18:25:47','','2010-04-06 18:25:47'),(0,'menu_title_101_',1,NULL,'menu_title_101_1',NULL,'UA','2009-11-26 13:28:18',NULL,'2009-11-26 13:28:18'),(0,'menu_title_101_',2,'','menu_title_101_2',NULL,'UA','2009-11-26 13:37:04','','2009-11-26 13:37:04'),(0,'menu_title_101_',3,'','menu_title_101_3',NULL,'UA','2009-11-26 14:02:47','','2009-11-26 14:02:47'),(0,'menu_title_101_',4,'','menu_title_101_4',NULL,'UA','2009-11-26 14:03:31','','2009-11-26 14:03:31'),(0,'menu_title_101_',5,'','menu_title_101_5',NULL,'UA','2009-11-26 14:04:15','','2009-11-26 14:04:15'),(0,'menu_title_101_',6,'','menu_title_101_6',NULL,'UA','2009-11-26 14:05:14','','2009-11-26 14:05:14'),(0,'menu_title_10_',1,NULL,'menu_title_10_1',NULL,'UA','2009-11-26 13:28:18',NULL,'2009-11-26 13:28:18'),(0,'menu_title_10_',2,'','menu_title_10_2',NULL,'RU','2010-03-01 13:16:38','','2010-03-01 13:16:38'),(0,'menu_title_10_',2,'','menu_title_10_2','','UA','2010-03-22 15:20:52','','2010-03-22 15:20:52'),(0,'menu_title_10_',3,'','menu_title_10_3',NULL,'RU','2010-03-01 13:16:53','','2010-03-01 13:16:53'),(0,'menu_title_10_',3,'','menu_title_10_3','','UA','2010-03-01 13:16:46','','2010-03-01 13:16:46'),(0,'menu_title_10_',4,'','menu_title_10_4',NULL,'RU','2010-03-01 13:17:14','','2010-03-01 13:17:14'),(0,'menu_title_10_',4,'','menu_title_10_4','','UA','2010-03-22 15:20:58','','2010-03-22 15:20:58'),(0,'menu_title_10_',5,'','menu_title_10_5',NULL,'UA','2009-12-15 15:40:19','','2009-12-15 15:40:19'),(0,'menu_title_10_',6,'','menu_title_10_6','','UA','2009-12-25 10:09:26','','2009-12-25 10:09:26'),(0,'menu_title_11_',1,NULL,'menu_title_11_1',NULL,'UA','2009-11-26 15:09:29',NULL,'2009-11-26 15:09:29'),(0,'menu_title_11_',2,'','menu_title_11_2',NULL,'UA','2009-11-27 12:27:47','','2009-11-27 12:27:47'),(0,'menu_title_11_',3,'','menu_title_11_3',NULL,'UA','2009-11-27 12:29:14','','2009-11-27 12:29:14'),(0,'menu_title_300_',1,NULL,'menu_title_300_1',NULL,'UA','2009-11-26 16:29:31',NULL,'2009-11-26 16:29:31'),(0,'menu_title_300_',2,'','menu_title_300_2',NULL,'UA','2009-11-26 16:32:59','','2009-11-26 16:32:59'),(0,'menu_title_300_',3,'','menu_title_300_3','','UA','2010-02-24 11:20:19','','2010-02-24 11:20:19'),(0,'menu_title_300_',4,'','menu_title_300_4',NULL,'UA','2009-11-26 16:45:20','','2009-11-26 16:45:20'),(0,'menu_title_300_',5,'','menu_title_300_5',NULL,'UA','2009-11-26 16:46:30','','2009-11-26 16:46:30'),(0,'menu_title_300_',6,'extraitem','menu_title_300_6',NULL,'UA','2010-01-19 10:10:39','extraitem','2010-01-19 10:10:39'),(0,'menu_title_40028_',1,'','menu_title_40028_1','','UA','2010-01-13 14:36:00','','2010-01-13 14:36:00'),(0,'menu_title_40029_',1,'','menu_title_40029_1','','UA','2010-01-13 14:26:45','','2010-01-13 14:26:45'),(0,'menu_title_40030_',1,'','menu_title_40030_1','','UA','2009-12-30 11:29:33','','2009-12-30 11:29:33'),(0,'menu_title_40031_',1,NULL,'menu_title_40031_1',NULL,'UA','2009-12-25 14:35:28',NULL,'2009-12-25 14:35:28'),(0,'menu_title_40032_',1,'','menu_title_40032_1','','UA','2010-01-13 14:37:08','','2010-01-13 14:37:08'),(0,'menu_title_40033_',1,'','menu_title_40033_1','','UA','2010-02-25 13:59:42','','2010-02-25 13:59:42'),(0,'menu_title_40034_',1,'','menu_title_40034_1','','UA','2010-01-12 07:16:23','','2010-01-12 07:16:23'),(0,'menu_title_40035_',1,NULL,'menu_title_40035_1',NULL,'UA','2009-12-25 14:42:55',NULL,'2009-12-25 14:42:55'),(0,'menu_title_40036_',1,NULL,'menu_title_40036_1',NULL,'UA','2010-01-30 08:48:52',NULL,'2010-01-30 08:48:52'),(0,'menu_title_40037_',1,NULL,'menu_title_40037_1',NULL,'UA','2009-12-30 11:32:46',NULL,'2009-12-30 11:32:46'),(0,'menu_title_40038_',1,NULL,'menu_title_40038_1',NULL,'UA','2009-12-30 11:24:10',NULL,'2009-12-30 11:24:10'),(0,'menu_title_40039_',1,NULL,'menu_title_40039_1',NULL,'UA','2009-12-25 15:07:09',NULL,'2009-12-25 15:07:09'),(0,'menu_title_40045_',1,'','menu_title_40045_1','','UA','2009-12-30 11:23:37','','2009-12-30 11:23:37'),(0,'menu_title_40046_',1,'','menu_title_40046_1','','UA','2010-01-13 14:25:47','','2010-01-13 14:25:47'),(0,'menu_title_40047_',1,NULL,'menu_title_40047_1',NULL,'UA','2009-12-25 09:42:14',NULL,'2009-12-25 09:42:14'),(0,'menu_title_40048_',1,NULL,'menu_title_40048_1',NULL,'UA','2010-01-09 18:51:01',NULL,'2010-01-09 18:51:01'),(0,'menu_title_40052_',1,NULL,'menu_title_40052_1',NULL,'UA','2009-12-25 15:07:13',NULL,'2009-12-25 15:07:13'),(0,'menu_title_40054_',1,NULL,'menu_title_40054_1',NULL,'UA','2009-12-25 14:57:21',NULL,'2009-12-25 14:57:21'),(0,'menu_title_40057_',1,'','menu_title_40057_1','','UA','2009-12-13 19:49:21','','2009-12-13 19:49:21'),(0,'menu_title_40059_',1,'','menu_title_40059_1','','UA','2009-12-13 12:08:37','','2009-12-13 12:08:37'),(0,'menu_title_40060_',1,'','menu_title_40060_1','','UA','2010-01-28 16:55:08','','2010-01-28 16:55:08'),(0,'menu_title_40061_',1,'','menu_title_40061_1','','UA','2010-01-14 18:36:54','','2010-01-14 18:36:54'),(0,'menu_title_40062_',1,'','menu_title_40062_1','','UA','2010-01-27 04:52:25','','2010-01-27 04:52:25'),(0,'menu_title_40063_',1,'','menu_title_40063_1','','UA','2009-12-13 12:04:32','','2009-12-13 12:04:32'),(0,'menu_title_40064_',1,'','menu_title_40064_1','','UA','2010-02-01 16:39:39','','2010-02-01 16:39:39'),(0,'menu_title_40066_',1,'','menu_title_40066_1','','UA','2010-01-18 15:33:47','','2010-01-18 15:33:47'),(0,'menu_title_40067_',1,'','menu_title_40067_1','','UA','2009-12-29 21:57:37','','2009-12-29 21:57:37'),(0,'menu_title_40068_',1,'','menu_title_40068_1','','UA','2010-01-05 23:47:25','','2010-01-05 23:47:25'),(0,'menu_title_40088_',1,'','menu_title_40088_1','','UA','2010-01-31 15:24:00','','2010-01-31 15:24:00'),(0,'menu_title_40089_',1,NULL,'menu_title_40089_1',NULL,'UA','2010-01-19 08:28:55',NULL,'2010-01-19 08:28:55'),(0,'menu_title_40090_',1,'','menu_title_40090_1','','UA','2010-01-19 11:59:30','','2010-01-19 11:59:30'),(0,'menu_title_400_',1,'','menu_title_400_1','','UA','2009-12-11 15:32:13','','2009-12-11 15:32:13'),(0,'menu_title_400_',2,'','menu_title_400_2',NULL,'UA','2009-12-11 15:29:34','','2009-12-11 15:29:34'),(0,'menu_title_90029_',1,'','menu_title_90029_1','','UA','2010-01-14 16:07:17','','2010-01-14 16:07:17'),(0,'menu_title_90029_',2,'','menu_title_90029_2',NULL,'UA','2010-01-14 16:08:57','','2010-01-14 16:08:57'),(0,'menu_title_90030_',1,'','menu_title_90030_1','','UA','2010-01-14 08:23:01','','2010-01-14 08:23:01'),(0,'menu_title_90030_',2,'','menu_title_90030_2',NULL,'RU','2010-03-29 18:10:21','','2010-03-29 18:10:21'),(0,'menu_title_90030_',2,'','menu_title_90030_2','','UA','2010-03-29 18:10:14','','2010-03-29 18:10:14'),(0,'menu_title_90031_',1,'','menu_title_90031_1','','UA','2010-01-14 08:55:23','','2010-01-14 08:55:23'),(0,'menu_title_90031_',2,'','menu_title_90031_2',NULL,'UA','2010-01-14 08:56:05','','2010-01-14 08:56:05'),(0,'menu_title_90032_',1,NULL,'menu_title_90032_1',NULL,'UA','2010-01-19 10:32:16',NULL,'2010-01-19 10:32:16'),(0,'menu_title_90033_',1,'','menu_title_90033_1','','UA','2010-01-14 16:07:48','','2010-01-14 16:07:48'),(0,'menu_title_90033_',2,'','menu_title_90033_2',NULL,'UA','2010-01-14 16:10:06','','2010-01-14 16:10:06'),(0,'menu_title_90034_',1,'','menu_title_90034_1','','UA','2010-01-22 14:03:35','','2010-01-22 14:03:35'),(0,'menu_title_90035_',1,'','menu_title_90035_1','','UA','2010-01-13 21:51:20','','2010-01-13 21:51:20'),(0,'menu_title_90035_',2,'','menu_title_90035_2',NULL,'UA','2010-01-14 06:40:35','','2010-01-14 06:40:35'),(0,'menu_title_90035_',3,'','menu_title_90035_3',NULL,'UA','2010-01-14 06:52:43','','2010-01-14 06:52:43'),(0,'menu_title_90036_',1,NULL,'menu_title_90036_1',NULL,'UA','2010-01-30 08:48:52',NULL,'2010-01-30 08:48:52'),(0,'menu_title_90037_',1,'','menu_title_90037_1','','UA','2010-01-14 08:29:14','','2010-01-14 08:29:14'),(0,'menu_title_90037_',2,'N.B. Is page dependent !!!','menu_title_90037_2',NULL,'UA','2010-01-14 08:28:53','N.B. Is page dependent !!!','2010-01-14 08:28:53'),(0,'menu_title_90037_',3,'','menu_title_90037_3',NULL,'UA','2010-01-14 08:30:06','','2010-01-14 08:30:06'),(0,'menu_title_90038_',1,NULL,'menu_title_90038_1',NULL,'UA','2010-03-29 17:53:44',NULL,'2010-03-29 17:53:44'),(0,'menu_title_90039_',1,'---','menu_title_90039_1','','UA','2010-01-14 10:16:17','---','2010-01-14 10:16:17'),(0,'menu_title_90039_',2,'','menu_title_90039_2',NULL,'UA','2010-01-14 10:17:25','','2010-01-14 10:17:25'),(0,'menu_title_90039_',3,'','menu_title_90039_3',NULL,'UA','2010-01-14 10:18:25','','2010-01-14 10:18:25'),(0,'menu_title_90040_',1,'','menu_title_90040_1','','UA','2010-01-14 09:59:18','','2010-01-14 09:59:18'),(0,'menu_title_90040_',2,'','menu_title_90040_2',NULL,'UA','2010-01-14 10:00:16','','2010-01-14 10:00:16'),(0,'menu_title_90040_',3,'','menu_title_90040_3',NULL,'UA','2010-01-14 10:04:05','','2010-01-14 10:04:05'),(0,'menu_title_90042_',1,'','menu_title_90042_1','','UA','2010-01-14 07:34:20','','2010-01-14 07:34:20'),(0,'menu_title_90042_',2,'','menu_title_90042_2',NULL,'UA','2010-01-14 07:35:11','','2010-01-14 07:35:11'),(0,'menu_title_90042_',3,'','menu_title_90042_3',NULL,'UA','2010-01-14 07:36:13','','2010-01-14 07:36:13'),(0,'menu_title_90043_',1,NULL,'menu_title_90043_1',NULL,'UA','2010-01-19 11:23:21',NULL,'2010-01-19 11:23:21'),(0,'menu_title_90045_',1,'','menu_title_90045_1','','UA','2010-01-14 07:56:50','','2010-01-14 07:56:50'),(0,'menu_title_90045_',2,'','menu_title_90045_2',NULL,'UA','2010-01-14 07:57:43','','2010-01-14 07:57:43'),(0,'menu_title_90045_',3,'','menu_title_90045_3',NULL,'UA','2010-01-14 08:07:49','','2010-01-14 08:07:49'),(0,'menu_title_90046_',1,'','menu_title_90046_1','','UA','2010-01-14 16:05:50','','2010-01-14 16:05:50'),(0,'menu_title_90046_',2,'','menu_title_90046_2',NULL,'UA','2010-01-14 16:11:01','','2010-01-14 16:11:01'),(0,'menu_title_90047_',1,'...','menu_title_90047_1','','UA','2010-01-14 10:12:37','...','2010-01-14 10:12:37'),(0,'menu_title_90047_',2,'','menu_title_90047_2','','UA','2010-03-30 12:36:53','','2010-03-30 12:36:53'),(0,'menu_title_90051_',1,'','menu_title_90051_1','','UA','2010-01-14 10:05:11','','2010-01-14 10:05:11'),(0,'menu_title_90051_',2,'','menu_title_90051_2',NULL,'UA','2010-01-14 10:06:16','','2010-01-14 10:06:16'),(0,'menu_title_90051_',3,'','menu_title_90051_3',NULL,'UA','2010-01-14 10:07:38','','2010-01-14 10:07:38'),(0,'menu_title_90052_',1,'','menu_title_90052_1','','UA','2010-01-14 10:24:29','','2010-01-14 10:24:29'),(0,'menu_title_90052_',2,'---','menu_title_90052_2','','UA','2010-01-29 17:47:31','---','2010-01-29 17:47:31'),(0,'menu_title_90052_',3,'','menu_title_90052_3',NULL,'UA','2010-01-14 10:27:13','','2010-01-14 10:27:13'),(0,'menu_title_90053_',1,NULL,'menu_title_90053_1',NULL,'UA','2010-01-19 11:23:35',NULL,'2010-01-19 11:23:35'),(0,'menu_title_90055_',1,'','menu_title_90055_1','','UA','2010-01-14 07:39:21','','2010-01-14 07:39:21'),(0,'menu_title_90055_',2,'','menu_title_90055_2',NULL,'UA','2010-01-14 07:40:56','','2010-01-14 07:40:56'),(0,'menu_title_90055_',3,'','menu_title_90055_3',NULL,'UA','2010-01-14 07:51:18','','2010-01-14 07:51:18'),(0,'menu_title_90057_',1,'','menu_title_90057_1','','UA','2010-01-14 10:45:36','','2010-01-14 10:45:36'),(0,'menu_title_90057_',2,'N.B. Is page dependent !!!','menu_title_90057_2','','UA','2010-01-14 11:50:32','N.B. Is page dependent !!!','2010-01-14 11:50:32'),(0,'menu_title_90059_',1,'---','menu_title_90059_1','','UA','2010-01-14 10:49:42','---','2010-01-14 10:49:42'),(0,'menu_title_90059_',2,'','menu_title_90059_2',NULL,'UA','2010-01-14 10:50:44','','2010-01-14 10:50:44'),(0,'menu_title_90060_',1,'','menu_title_90060_1','','UA','2010-01-28 16:55:34','','2010-01-28 16:55:34'),(0,'menu_title_90061_',1,'','menu_title_90061_1','','UA','2010-01-14 18:05:22','','2010-01-14 18:05:22'),(0,'menu_title_90062_',1,'','menu_title_90062_1','','UA','2010-01-27 04:52:53','','2010-01-27 04:52:53'),(0,'menu_title_90063_',1,'','menu_title_90063_1','','UA','2010-01-14 11:00:18','','2010-01-14 11:00:18'),(0,'menu_title_90064_',1,'','menu_title_90064_1','','UA','2010-02-01 16:40:19','','2010-02-01 16:40:19'),(0,'menu_title_90066_',1,'','menu_title_90066_1','','UA','2010-01-18 15:38:54','','2010-01-18 15:38:54'),(0,'menu_title_90067_',1,NULL,'menu_title_90067_1',NULL,'UA','2010-01-19 11:19:32',NULL,'2010-01-19 11:19:32'),(0,'menu_title_90068_',1,'','menu_title_90068_1','','UA','2010-01-14 06:37:42','','2010-01-14 06:37:42'),(0,'menu_title_90068_',2,'','menu_title_90068_2',NULL,'UA','2010-01-14 06:35:16','','2010-01-14 06:35:16'),(0,'menu_title_90086_',1,'','menu_title_90086_1','','UA','2010-01-14 10:09:31','','2010-01-14 10:09:31'),(0,'menu_title_90086_',2,'','menu_title_90086_2',NULL,'UA','2010-01-14 10:10:27','','2010-01-14 10:10:27'),(0,'menu_title_90086_',3,'---','menu_title_90086_3','','UA','2010-01-29 17:48:15','---','2010-01-29 17:48:15'),(0,'menu_title_90088_',1,'','menu_title_90088_1','','UA','2010-01-31 15:25:03','','2010-01-31 15:25:03'),(0,'menu_title_90089_',1,NULL,'menu_title_90089_1',NULL,'UA','2010-01-19 08:28:55',NULL,'2010-01-19 08:28:55'),(0,'menu_title_90090_',1,'','menu_title_90090_1','','UA','2010-01-19 11:59:55','','2010-01-19 11:59:55'),(0,'meta_commentary',0,'',NULL,NULL,'EN','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'meta_commentary',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'meta_commentary',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'meta_description',0,'meta_description',NULL,NULL,'EN','2010-03-20 06:30:00','meta_description','2009-11-14 21:07:33'),(0,'meta_description',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'meta_description',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'meta_keywords',0,'meta_keywords',NULL,NULL,'EN','2010-03-20 06:30:00','meta_keywords','2009-11-14 21:07:33'),(0,'meta_keywords',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'meta_keywords',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'meta_title',0,'meta_title',NULL,NULL,'EN','2010-03-20 06:30:00','meta_title','2009-11-14 21:07:33'),(0,'meta_title',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'meta_title',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:38:10'),(0,'my_points_block_content',0,'<p><img height=\"50\" alt=\"\" width=\"50\" align=\"left\" vspace=\"4\" src=\"/usersimage/Image/face.png\" /></p>\r\n<p class=\"content_simple_text\" style=\"margin-left: 60px\">З&rsquo;ясуйте кількість зароблених балів та перегляньте історію досліджень.</p>\r\n<p><a class=\"system_button2\" href=\"/index.php?t=30&amp;language=UA\">Перейти до розділу</a></p>','my_points_block_content','','UA','2010-01-14 06:59:33','<p><img height=\"50\" alt=\"\" width=\"50\" align=\"left\" vspace=\"4\" src=\"/usersimage/Image/face.png\" /></p>\r\n<p class=\"content_simple_text\" style=\"margin-left: 60px\">З&rsquo;ясуйте кількість зароблених балів та перегляньте історію досліджень.</p>\r\n<p><a class=\"system_button2\" href=\"/index.php?t=30&amp;language=UA\">Перейти до розділу</a></p>','2010-01-14 06:59:33'),(0,'NAME',0,'Iм\'я','NAME',NULL,'UA','2010-04-02 08:25:12','Iм\'я','2010-04-02 08:25:12'),(0,'NEW_PASSWORD',0,'Новий пароль','NEW_PASSWORD',NULL,'UA','2010-04-03 08:32:08','Новий пароль','2010-04-03 08:32:08'),(0,'no_default_page',0,'no_default_page',NULL,NULL,'EN','2009-11-14 21:07:33','no_default_page','2009-11-14 21:07:33'),(0,'NO_INFO',0,'Iнформацiя вiдсутня','NO_INFO',NULL,'UA','2010-04-02 08:35:30','Iнформацiя вiдсутня','2010-04-02 08:35:30'),(0,'obj_meta_commentary',0,'',NULL,NULL,'EN','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'obj_meta_commentary',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'obj_meta_commentary',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'obj_meta_description',0,'',NULL,NULL,'EN','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'obj_meta_description',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'obj_meta_description',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'obj_meta_keywords',0,'',NULL,NULL,'EN','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'obj_meta_keywords',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'obj_meta_keywords',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'obj_meta_title',0,'',NULL,NULL,'EN','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'obj_meta_title',0,'',NULL,NULL,'RU','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'obj_meta_title',0,'',NULL,NULL,'UA','0000-00-00 00:00:00',NULL,'2010-03-19 15:45:01'),(0,'OLD_PASSWORD',0,'Старий пароль','OLD_PASSWORD',NULL,'UA','2010-04-03 08:32:08','Старий пароль','2010-04-03 08:32:08'),(0,'page_name_',1,'Home','page_name_1',NULL,'EN','2009-11-14 21:32:04','Home','2009-11-14 21:32:04'),(0,'page_name_',1,'CTAPT','page_name_1',NULL,'UA','2009-11-14 21:32:04','CTAPT','2009-11-14 21:32:04'),(0,'page_name_',11,'news-rss','page_name_11',NULL,'UA','2010-01-21 16:11:06','news-rss','2010-01-21 16:11:06'),(0,'page_name_',28,'TNS-в-Україні','page_name_28',NULL,'UA','2009-12-25 14:41:51','TNS-в-Україні','2009-12-25 14:41:51'),(0,'page_name_',29,'Відповідальність','page_name_29',NULL,'EN','2010-01-14 15:54:20','Відповідальність','2010-01-14 15:54:20'),(0,'page_name_',29,'Відповідальність','page_name_29',NULL,'UA','2010-01-14 15:54:20','Відповідальність','2010-01-14 15:54:20'),(0,'page_name_',30,'survey-history','page_name_30',NULL,'EN','2010-01-18 19:05:40','survey-history','2010-01-18 19:05:40'),(0,'page_name_',30,'survey-history','page_name_30',NULL,'UA','2010-01-18 19:05:40','survey-history','2010-01-18 19:05:40'),(0,'page_name_',31,'Конвертація-балів','page_name_31',NULL,'UA','2010-01-13 14:41:17','Конвертація-балів','2010-01-13 14:41:17'),(0,'page_name_',32,'Контакти','page_name_32',NULL,'EN','2010-01-13 14:34:32','Контакти','2010-01-13 14:34:32'),(0,'page_name_',32,'Контакти','page_name_32',NULL,'UA','2010-01-13 14:34:32','Контакти','2010-01-13 14:34:32'),(0,'page_name_',33,'Конфеденційність','page_name_33',NULL,'EN','2010-01-14 15:53:27','Конфеденційність','2010-01-14 15:53:27'),(0,'page_name_',33,'Конфеденційність','page_name_33',NULL,'UA','2010-01-14 15:53:27','Конфеденційність','2010-01-14 15:53:27'),(0,'page_name_',34,'мапа-сайту','page_name_34',NULL,'EN','2010-01-13 14:42:12','мапа-сайту','2010-01-13 14:42:12'),(0,'page_name_',34,'Мапа-сайту','page_name_34',NULL,'UA','2010-01-13 14:42:12','Мапа-сайту','2010-01-13 14:42:12'),(0,'page_name_',35,'Ми-Opros','page_name_35',NULL,'EN','2010-03-29 17:52:57','Ми-Opros','2010-03-29 17:52:57'),(0,'page_name_',35,'Ми-Opros','page_name_35',NULL,'RU','2010-03-29 17:52:57','Ми-Opros','2010-03-29 17:52:57'),(0,'page_name_',35,'Ми-Opros','page_name_35',NULL,'UA','2010-03-29 17:52:57','Ми-Opros','2010-03-29 17:52:57'),(0,'page_name_',36,'Мої-бали','page_name_36',NULL,'UA','2009-12-25 14:46:53','Мої-бали','2009-12-25 14:46:53'),(0,'page_name_',37,'user-profile','page_name_37',NULL,'EN','2010-01-18 19:07:30','user-profile','2010-01-18 19:07:30'),(0,'page_name_',37,'user-profile','page_name_37',NULL,'UA','2010-01-18 19:07:30','user-profile','2010-01-18 19:07:30'),(0,'page_name_',38,'Мій-Opros','page_name_38',NULL,'EN','2010-03-29 17:40:31','Мій-Opros','2010-03-29 17:40:31'),(0,'page_name_',38,'Мій-Opros','page_name_38',NULL,'RU','2010-03-29 17:40:31','Мій-Opros','2010-03-29 17:40:31'),(0,'page_name_',38,'Мій-Opros','page_name_38',NULL,'UA','2010-03-29 17:40:31','Мій-Opros','2010-03-29 17:40:31'),(0,'page_name_',39,'Навіщо-реєструватись','page_name_39',NULL,'UA','2010-01-13 14:41:45','Навіщо-реєструватись','2010-01-13 14:41:45'),(0,'page_name_',40,'Новини','page_name_40',NULL,'EN','2010-01-21 16:11:37','Новини','2010-01-21 16:11:37'),(0,'page_name_',40,'Новини','page_name_40',NULL,'UA','2010-01-21 16:11:37','Новини','2010-01-21 16:11:37'),(0,'page_name_',41,'Останні-новини','page_name_41',NULL,'UA','2010-01-13 14:42:49','Останні-новини','2010-01-13 14:42:49'),(0,'page_name_',42,'переваги-36.6','page_name_42',NULL,'EN','2010-01-13 14:43:16','переваги-36.6','2010-01-13 14:43:16'),(0,'page_name_',42,'Переваги-36.6','page_name_42',NULL,'UA','2010-01-13 14:43:16','Переваги-36.6','2010-01-13 14:43:16'),(0,'page_name_',43,'Підсумки-досліджень','page_name_43',NULL,'UA','2010-01-13 14:43:46','Підсумки-досліджень','2010-01-13 14:43:46'),(0,'page_name_',44,'пожива-для-роздумів','page_name_44',NULL,'EN','2009-12-25 14:46:09','пожива-для-роздумів','2009-12-25 14:46:09'),(0,'page_name_',44,'Пожива-для-роздумів','page_name_44',NULL,'UA','2009-12-25 14:46:09','Пожива-для-роздумів','2009-12-25 14:46:09'),(0,'page_name_',45,'Current-projects','page_name_45',NULL,'EN','2010-01-27 15:11:21','Current-projects','2010-01-27 15:11:21'),(0,'page_name_',45,'Поточні-проекти','page_name_45',NULL,'UA','2010-01-27 15:11:21','Поточні-проекти','2010-01-27 15:11:21'),(0,'page_name_',46,'Правила-участі','page_name_46',NULL,'EN','2010-01-14 15:55:32','Правила-участі','2010-01-14 15:55:32'),(0,'page_name_',46,'Правила-участі','page_name_46',NULL,'UA','2010-01-14 15:55:32','Правила-участі','2010-01-14 15:55:32'),(0,'page_name_',47,'Форма-реєстрації','page_name_47',NULL,'EN','2010-03-20 06:28:04','Форма-реєстрації','2010-03-20 06:28:04'),(0,'page_name_',47,'Форма-реєстрації','page_name_47',NULL,'RU','2010-03-20 06:28:04','Форма-реєстрації','2010-03-20 06:28:04'),(0,'page_name_',47,'Форма-реєстрації','page_name_47',NULL,'UA','2010-03-20 06:28:04','Форма-реєстрації','2010-03-20 06:28:04'),(0,'page_name_',48,'Про-36.6','page_name_48',NULL,'UA','2009-12-25 14:48:45','Про-36.6','2009-12-25 14:48:45'),(0,'page_name_',49,'Про-TNS-та-36.6','page_name_49',NULL,'UA','2009-12-25 14:49:23','Про-TNS-та-36.6','2009-12-25 14:49:23'),(0,'page_name_',50,'Проекти','page_name_50',NULL,'EN','2009-12-25 14:52:45','Проекти','2009-12-25 14:52:45'),(0,'page_name_',50,'Проекти','page_name_50',NULL,'UA','2009-12-25 14:52:45','Проекти','2009-12-25 14:52:45'),(0,'page_name_',51,'Результати-досліджень','page_name_51',NULL,'EN','2010-01-29 14:37:14','Результати-досліджень','2010-01-29 14:37:14'),(0,'page_name_',51,'Результати-досліджень','page_name_51',NULL,'UA','2010-01-29 14:37:14','Результати-досліджень','2010-01-29 14:37:14'),(0,'page_name_',52,'Система-заохочення','page_name_52',NULL,'UA','2009-12-25 14:51:02','Система-заохочення','2009-12-25 14:51:02'),(0,'page_name_',53,'Статистика-відвідувань','page_name_53',NULL,'UA','2009-12-25 14:51:33','Статистика-відвідувань','2009-12-25 14:51:33'),(0,'page_name_',55,'Місія-36.6','page_name_55',NULL,'UA','2009-12-25 14:53:28','Місія-36.6','2009-12-25 14:53:28'),(0,'page_name_',57,'Password-reminder','page_name_57',NULL,'EN','2010-03-20 05:29:46','Password-reminder','2010-03-20 05:29:46'),(0,'page_name_',57,'Password-reminder','page_name_57',NULL,'RU','2010-03-20 05:29:46','Password-reminder','2010-03-20 05:29:46'),(0,'page_name_',57,'Password-reminder','page_name_57',NULL,'UA','2010-03-20 05:29:46','Password-reminder','2010-03-20 05:29:46'),(0,'page_name_',59,'respondent-registration-approve','page_name_59',NULL,'EN','2010-03-20 06:16:50','respondent-registration-approve','2010-03-20 06:16:50'),(0,'page_name_',59,'respondent-registration-approve','page_name_59',NULL,'RU','2010-03-20 06:16:50','respondent-registration-approve','2010-03-20 06:16:50'),(0,'page_name_',59,'respondent-registration-approve','page_name_59',NULL,'UA','2010-03-20 06:16:50','respondent-registration-approve','2010-03-20 06:16:50'),(0,'page_name_',60,'respondent-password-update','page_name_60',NULL,'EN','2010-03-20 06:10:03','respondent-password-update','2010-03-20 06:10:03'),(0,'page_name_',60,'respondent-password-update','page_name_60',NULL,'RU','2010-03-20 06:10:03','respondent-password-update','2010-03-20 06:10:03'),(0,'page_name_',60,'respondent-password-update','page_name_60',NULL,'UA','2010-03-20 06:10:03','respondent-password-update','2010-03-20 06:10:03'),(0,'page_name_',61,'respondent-registered-success','page_name_61',NULL,'EN','2010-01-18 18:54:51','respondent-registered-success','2010-01-18 18:54:51'),(0,'page_name_',61,'respondent-registered-success','page_name_61',NULL,'UA','2010-01-18 18:54:51','respondent-registered-success','2010-01-18 18:54:51'),(0,'page_name_',62,'registration-approved','page_name_62',NULL,'EN','2010-01-18 18:55:52','registration-approved','2010-01-18 18:55:52'),(0,'page_name_',62,'registration-approved','page_name_62',NULL,'UA','2010-01-18 18:55:52','registration-approved','2010-01-18 18:55:52'),(0,'page_name_',63,'Сторінка-не-знайдена','page_name_63',NULL,'UA','2010-01-13 14:46:52','Сторінка-не-знайдена','2010-01-13 14:46:52'),(0,'page_name_',64,'password-reminde-sended','page_name_64',NULL,'UA','2009-12-25 10:16:13','password-reminde-sended','2009-12-25 10:16:13'),(0,'page_name_',65,'password-update-success','page_name_65',NULL,'UA','2009-12-25 12:06:37','password-update-success','2009-12-25 12:06:37'),(0,'page_name_',66,'respondent-updated','page_name_66',NULL,'UA','2009-12-25 13:38:56','respondent-updated','2009-12-25 13:38:56'),(0,'page_name_',67,'Forbidden','page_name_67',NULL,'UA','2009-12-29 21:55:04','Forbidden','2009-12-29 21:55:04'),(0,'page_name_',68,'Авторизація','page_name_68',NULL,'EN','2010-03-20 06:01:09','Авторизація','2010-03-20 06:01:09'),(0,'page_name_',68,'Авторизація','page_name_68',NULL,'RU','2010-03-20 06:01:09','Авторизація','2010-03-20 06:01:09'),(0,'page_name_',68,'Авторизація','page_name_68',NULL,'UA','2010-03-20 06:01:09','Авторизація','2010-03-20 06:01:09'),(0,'page_name_',69,'tns_z_novym_rokom','page_name_69',NULL,'EN','2010-03-04 15:26:47','tns_z_novym_rokom','2010-03-04 15:26:47'),(0,'page_name_',69,'tns_z_novym_rokom','page_name_69',NULL,'RU','2010-03-04 15:26:47','tns_z_novym_rokom','2010-03-04 15:26:47'),(0,'page_name_',69,'tns_z_novym_rokom','page_name_69',NULL,'UA','2010-03-04 15:26:47','tns_z_novym_rokom','2010-03-04 15:26:47'),(0,'page_name_',70,'shapka_pro_36_6','page_name_70',NULL,'UA','2010-01-08 13:57:10','shapka_pro_36_6','2010-01-08 13:57:10'),(0,'page_name_',71,'pro_36_6','page_name_71',NULL,'UA','2010-01-08 13:58:25','pro_36_6','2010-01-08 13:58:25'),(0,'page_name_',72,'shapka_novyny','page_name_72',NULL,'UA','2010-01-08 13:59:29','shapka_novyny','2010-01-08 13:59:29'),(0,'page_name_',73,'novyny','page_name_73',NULL,'UA','2010-01-08 14:00:03','novyny','2010-01-08 14:00:03'),(0,'page_name_',74,'shapka_pryednajtes','page_name_74',NULL,'UA','2010-01-08 14:00:49','shapka_pryednajtes','2010-01-08 14:00:49'),(0,'page_name_',75,'pryednajtes','page_name_75',NULL,'UA','2010-01-08 14:02:42','pryednajtes','2010-01-08 14:02:42'),(0,'page_name_',76,'shapka_pro_tns','page_name_76',NULL,'UA','2010-01-08 14:03:46','shapka_pro_tns','2010-01-08 14:03:46'),(0,'page_name_',77,'shapka_moja_36_6','page_name_77',NULL,'UA','2010-01-11 08:15:54','shapka_moja_36_6','2010-01-11 08:15:54'),(0,'page_name_',78,'shapka_poto4ni_proekty','page_name_78',NULL,'UA','2010-01-11 08:17:33','shapka_poto4ni_proekty','2010-01-11 08:17:33'),(0,'page_name_',79,'Darts-arrow','page_name_79',NULL,'EN','2010-01-18 17:02:58','Darts-arrow','2010-01-18 17:02:58'),(0,'page_name_',79,'Darts-arrow','page_name_79',NULL,'UA','2010-01-18 17:02:58','Darts-arrow','2010-01-18 17:02:58'),(0,'page_name_',80,'uah-sign','page_name_80',NULL,'UA','2010-01-12 16:46:34','uah-sign','2010-01-12 16:46:34'),(0,'page_name_',81,'handshake','page_name_81',NULL,'UA','2010-01-12 18:24:59','handshake','2010-01-12 18:24:59'),(0,'page_name_',84,'quotes','page_name_84',NULL,'UA','2010-01-12 18:41:00','quotes','2010-01-12 18:41:00'),(0,'page_name_',85,'quotes_with_text','page_name_85',NULL,'UA','2010-01-12 18:51:31','quotes_with_text','2010-01-12 18:51:31'),(0,'page_name_',86,'ЧЗП','page_name_86',NULL,'UA','2010-01-13 11:37:30','ЧЗП','2010-01-13 11:37:30'),(0,'page_name_',87,'media','page_name_87',NULL,'EN','2010-01-18 16:59:50','media','2010-01-18 16:59:50'),(0,'page_name_',87,'media','page_name_87',NULL,'UA','2010-01-18 16:59:50','media','2010-01-18 16:59:50'),(0,'page_name_',88,'project-complete','page_name_88',NULL,'EN','2010-01-18 18:16:37','project-complete','2010-01-18 18:16:37'),(0,'page_name_',88,'project-complete','page_name_88',NULL,'UA','2010-01-18 18:16:37','project-complete','2010-01-18 18:16:37'),(0,'page_name_',89,'new','page_name_89',NULL,'EN','2010-01-19 08:28:41','new','2010-01-19 08:28:41'),(0,'page_name_',89,'new','page_name_89',NULL,'UA','2010-01-19 08:28:41','new','2010-01-19 08:28:41'),(0,'page_name_',90,'password-updated-success','page_name_90',NULL,'UA','2010-01-19 11:56:40','password-updated-success','2010-01-19 11:56:40'),(0,'page_name_',91,'flash_el_advantages','page_name_91',NULL,'EN','2010-01-30 13:30:09','flash_el_advantages','2010-01-30 13:30:09'),(0,'page_name_',91,'flash_el_advantages','page_name_91',NULL,'UA','2010-01-30 13:30:09','flash_el_advantages','2010-01-30 13:30:09'),(0,'page_name_',92,'March-8','page_name_92',NULL,'EN','2010-03-04 15:25:24','March-8','2010-03-04 15:25:24'),(0,'page_name_',92,'March-8','page_name_92',NULL,'RU','2010-03-04 15:25:24','March-8','2010-03-04 15:25:24'),(0,'page_name_',92,'March-8','page_name_92',NULL,'UA','2010-03-04 15:25:24','March-8','2010-03-04 15:25:24'),(0,'PASSWORD',0,'Пароль','PASSWORD',NULL,'UA','2010-04-02 08:35:30','Пароль','2010-04-02 08:35:30'),(0,'PASSWORD_CONFIRM',0,'Підтвердити пароль','PASSWORD_CONFIRM',NULL,'UA','2010-04-03 08:49:31','Підтвердити пароль','2010-04-03 08:49:31'),(0,'PASSWORD_FOR_UPDATE_CONFIRMATION',0,'Пароль для підтвердження змін','PASSWORD_FOR_UPDATE_CONFIRMATION',NULL,'UA','2010-04-03 08:32:08','Пароль для підтвердження змін','2010-04-03 08:32:08'),(0,'PASSWORD_REMINDER_FORM',0,'Форма відновлення паролю','PASSWORD_REMINDER_FORM',NULL,'UA','2010-04-03 08:29:59','Форма відновлення паролю','2010-04-03 08:29:59'),(0,'password_rules_error',0,'Пароль має містити хоча б одну велику літеру, хоча б одну маленьку літеру, хоча б одну цифру та бути завдовжки не менше, ніж 8 символів.','password_rules_error','','UA','2010-02-25 12:38:35','Пароль має містити хоча б одну велику літеру, хоча б одну маленьку літеру, хоча б одну цифру та бути завдовжки не менше, ніж 8 символів.','2010-02-25 12:38:35'),(0,'password_rules_error_header',0,'Будь ласка, перевірте введені дані ще раз.<br/>','password_rules_error_header','','UA','2010-02-25 12:38:47','Будь ласка, перевірте введені дані ще раз.<br/>','2010-02-25 12:38:47'),(0,'PASSWORD_UPDATE_FORM',0,'Форма для змiни паролю','PASSWORD_UPDATE_FORM',NULL,'UA','2010-04-03 08:32:08','Форма для змiни паролю','2010-04-03 08:32:08'),(0,'POINTS_CONVERTION',0,'Використання балів','POINTS_CONVERTION',NULL,'UA','2010-04-02 08:23:57','Використання балів','2010-04-02 08:23:57'),(0,'points_convertion_block_content',0,'<p class=\"content_simple_text\">Використати свої бали можна двома способами:<br />\r\n&nbsp;- поповнити мобільний;<br />\r\n&nbsp;- поштовий переказ.<br />\r\nВідчуйте реальну користь від участі в дослідженнях.</p>\r\n<p><a class=\"system_button2\" href=\"/index.php?t=31&amp;language=UA\">Перейти до розділу</a></p>','points_convertion_block_content','','UA','2010-01-14 10:43:15','<p class=\"content_simple_text\">Використати свої бали можна двома способами:<br />\r\n&nbsp;- поповнити мобільний;<br />\r\n&nbsp;- поштовий переказ.<br />\r\nВідчуйте реальну користь від участі в дослідженнях.</p>\r\n<p><a class=\"system_button2\" href=\"/index.php?t=31&amp;language=UA\">Перейти до розділу</a></p>','2010-01-14 10:43:15'),(0,'POINTS_COUNT',0,'Кількість балів','POINTS_COUNT',NULL,'UA','2010-04-02 08:23:57','Кількість балів','2010-04-02 08:23:57'),(0,'POINTS_USING',0,'Points using','POINTS_USING',NULL,'UA','2010-04-06 18:29:12','Points using','2010-04-06 18:29:12'),(0,'points_using_comment',0,'<p>Нагадуємо, що ви можете використати свої бали двома способами:</p>\r\n<ol>\r\n    <li>Сконвертувати у гроші (поштовий переказ).</li>\r\n    <li>Перевести на рахунок мобільного телефону.</li>\r\n</ol>\r\n<p>&nbsp;</p>\r\n<p>Беріть участь у опитуваннях та накопичуйте більше балів!</p>','points_using_comment','','UA','2010-02-02 09:12:07','<p>Нагадуємо, що ви можете використати свої бали двома способами:</p>\r\n<ol>\r\n    <li>Сконвертувати у гроші (поштовий переказ).</li>\r\n    <li>Перевести на рахунок мобільного телефону.</li>\r\n</ol>\r\n<p>&nbsp;</p>\r\n<p>Беріть участь у опитуваннях та накопичуйте більше балів!</p>','2010-02-02 09:12:07'),(0,'POSTAL_ORDER',0,'Postal order','POSTAL_ORDER',NULL,'UA','2010-04-06 18:29:12','Postal order','2010-04-06 18:29:12'),(0,'PROJECT_CODE',0,'Код проекту','PROJECT_CODE',NULL,'UA','2010-04-02 08:23:55','Код проекту','2010-04-02 08:23:55'),(0,'READ_ALL_LAST_NEWS',0,'Все последние новости','READ_ALL_LAST_NEWS','','RU','2010-04-02 08:27:23','Все последние новости','2010-04-02 08:27:23'),(0,'READ_ALL_LAST_NEWS',0,'Переглянути всі останні новини','READ_ALL_LAST_NEWS','','UA','2010-04-02 08:27:34','Переглянути всі останні новини','2010-04-02 08:27:34'),(0,'REDRAW',0,'Оновити малюнок','REDRAW',NULL,'UA','2010-04-02 08:25:12','Оновити малюнок','2010-04-02 08:25:12'),(0,'REGION',0,'Район','REGION',NULL,'UA','2010-04-02 08:25:12','Район','2010-04-02 08:25:12'),(0,'REGISTRATION_FORM',0,'Реєстраційний бланк','REGISTRATION_FORM',NULL,'UA','2010-04-02 08:25:12','Реєстраційний бланк','2010-04-02 08:25:12'),(0,'registration_form_block_content',0,'<p class=\"content_simple_text\">Ще не встигли зареєструватись? Перейдіть за посиланням та заповніть форму реєстрації.</p>\r\n<p><a class=\"system_button2\" href=\"/index.php?t=47&amp;language=UA\">Зареєструватись</a></p>','registration_form_block_content','','UA','2010-01-14 12:14:46','<p class=\"content_simple_text\">Ще не встигли зареєструватись? Перейдіть за посиланням та заповніть форму реєстрації.</p>\r\n<p><a class=\"system_button2\" href=\"/index.php?t=47&amp;language=UA\">Зареєструватись</a></p>','2010-01-14 12:14:46'),(0,'REPLENISHMENT_MOBILE',0,'Replenishment mobile','REPLENISHMENT_MOBILE',NULL,'UA','2010-04-06 18:29:12','Replenishment mobile','2010-04-06 18:29:12'),(0,'RESPONDENT_CODE',0,'Код респондента','RESPONDENT_CODE',NULL,'UA','2010-04-02 08:23:55','Код респондента','2010-04-02 08:23:55'),(0,'respondent_registered_email_body',0,'<p>Шановний {first_name} {last_name}!</p>\r\n<p>Щоб завершити реєстрацію на сайті {HTTP} - натисніть&nbsp;{approving_form_link}.</p>','respondent_registered_email_body','','UA','2009-12-10 18:13:06','<p>Шановний {first_name} {last_name}!</p>\r\n<p>Щоб завершити реєстрацію на сайті {HTTP} - натисніть&nbsp;{approving_form_link}.</p>','2009-12-10 18:13:06'),(0,'respondent_registered_email_subject',0,'Реєстрація на сайті {HTTP}','respondent_registered_email_subject','{HTTP} - адреса сайту','UA','2009-12-10 17:48:17','Реєстрація на сайті {HTTP}','2009-12-10 17:48:17'),(0,'results_block_content',0,'<p class=\"content_simple_text\">Розділ присвячений результатам проведених компанією TNS досліджень. Ви можете ознайомитись з ними на сайті або завантажити їх на свій компютер.</p>\r\n<p><a class=\"system_button2\" href=\"/index.php?t=51&amp;language=UA\">Перейти до розділу</a></p>','results_block_content','','UA','2010-01-14 06:57:35','<p class=\"content_simple_text\">Розділ присвячений результатам проведених компанією TNS досліджень. Ви можете ознайомитись з ними на сайті або завантажити їх на свій компютер.</p>\r\n<p><a class=\"system_button2\" href=\"/index.php?t=51&amp;language=UA\">Перейти до розділу</a></p>','2010-01-14 06:57:35'),(0,'right_block_b_class_current_projects',0,'CCE4D7','right_block_b_class_current_projects','','UA','2010-01-14 07:49:04','CCE4D7','2010-01-14 07:49:04'),(0,'right_block_b_class_faq',0,'','Цвет footer блока. Может быть одно из значений: CCE8F3 (голубой), CCE4D7 (зеленый), E1DFED (фиолетов','','UA','2010-01-18 16:58:10','','2010-01-18 16:58:10'),(0,'right_block_b_class_my_points',0,'CCE4D7','right_block_b_class_my_points','','UA','2010-01-14 07:30:56','CCE4D7','2010-01-14 07:30:56'),(0,'right_block_b_class_news',0,'E1DFED','right_block_b_class_news','','UA','2010-01-14 08:09:02','E1DFED','2010-01-14 08:09:02'),(0,'right_block_b_class_points_convertion',0,'E1DFED','right_block_b_class_points_convertion','','UA','2010-01-14 10:34:44','E1DFED','2010-01-14 10:34:44'),(0,'right_block_b_class_registration_form',0,'','Цвет footer блока. Может быть одно из значений: CCE4D7, CCE8F3, E1DFED или пустое значение','','UA','2010-01-18 16:30:49','','2010-01-18 16:30:49'),(0,'right_block_b_class_results',0,'E1DFED','Цвет footer блока. Может быть одно из значений: CCE8F3 (голубой), CCE4D7 (зеленый), E1DFED (фиолетов','','UA','2010-01-18 16:57:40','E1DFED','2010-01-18 16:57:40'),(0,'right_block_b_class_system',0,'E1DFED','right_block_b_class_system','','UA','2010-01-14 08:59:02','E1DFED','2010-01-14 08:59:02'),(0,'right_block_b_class_usefull_contact',0,'E1DFED','right_block_b_class_usefull_contact','','UA','2010-01-13 18:34:33','E1DFED','2010-01-13 18:34:33'),(0,'right_block_faq',0,'<p><img height=\"49\" width=\"49\" align=\"left\" vspace=\"4\" alt=\"\" src=\"/usersimage/Image/faq.png\" /></p>\r\n<p class=\"content_simple_text\" style=\"margin-left: 60px\">Відповіді на найпоширеніші питання у розділі Frequently Asked Questions.</p>\r\n<p><a class=\"system_button2\" href=\"/index.php?t=86&amp;language=UA\">Перейти до розділу</a></p>','right_block_faq','','UA','2010-01-13 11:49:37','<p><img height=\"49\" width=\"49\" align=\"left\" vspace=\"4\" alt=\"\" src=\"/usersimage/Image/faq.png\" /></p>\r\n<p class=\"content_simple_text\" style=\"margin-left: 60px\">Відповіді на найпоширеніші питання у розділі Frequently Asked Questions.</p>\r\n<p><a class=\"system_button2\" href=\"/index.php?t=86&amp;language=UA\">Перейти до розділу</a></p>','2010-01-13 11:49:37'),(0,'right_block_h_class_contact',0,NULL,'right_block_h_class_contact',NULL,'UA','2010-01-14 11:45:33',NULL,'2010-01-14 11:45:33'),(0,'right_block_h_class_current_projects',0,'47B3B8','right_block_h_class_current_projects','','UA','2010-01-14 07:48:38','47B3B8','2010-01-14 07:48:38'),(0,'right_block_h_class_faq',0,'','Цвет шапки блока. Может быть 3A5D0 (голубой), 47B3B8 (зеленый), 8A81BA (фиолетовый) или пустым (буде','','UA','2010-01-18 16:55:42','','2010-01-18 16:55:42'),(0,'right_block_h_class_my_points',0,'47B3B8','right_block_h_class_my_points','','UA','2010-01-14 07:17:04','47B3B8','2010-01-14 07:17:04'),(0,'right_block_h_class_news',0,'8A81BA','right_block_h_class_news','','UA','2010-01-14 08:08:36','8A81BA','2010-01-14 08:08:36'),(0,'right_block_h_class_points_convertion',0,'8A81BA','right_block_h_class_points_convertion','','UA','2010-01-14 10:33:50','8A81BA','2010-01-14 10:33:50'),(0,'right_block_h_class_registration_form',0,'','Цвет шапки блока. Может быть 3A5D0, 47B3B8, 8A81BA или пустым','','UA','2010-01-18 16:27:53','','2010-01-18 16:27:53'),(0,'right_block_h_class_results',0,'8A81BA','Цвет шапки блока. Может быть 3A5D0 (голубой), 47B3B8 (зеленый), 8A81BA (фиолетовый) или пустым (буде','','UA','2010-01-18 16:55:51','8A81BA','2010-01-18 16:55:51'),(0,'right_block_h_class_system',0,'8A81BA','right_block_h_class_system','','UA','2010-01-14 08:58:39','8A81BA','2010-01-14 08:58:39'),(0,'right_block_h_class_usefull_contact',0,'8A81BA','right_block_h_class_usefull_contact','','UA','2010-01-13 18:33:53','8A81BA','2010-01-13 18:33:53'),(0,'rows_on_page__tpl_page_',1,'75','rows_on_page__tpl_page_1','','UA','2009-11-20 11:15:55','75','2009-11-20 11:15:55'),(0,'ROW_NUM',0,'Row num','ROW_NUM',NULL,'UA','2010-04-02 08:23:57','Row num','2010-04-02 08:23:57'),(0,'rules_read_confirm',0,'<p>Я підтверджую прочитання <a target=\"_blank\" href=\"/index.php?t=46&amp;language=UA\">Правил участі</a><br />\r\nта не маю заперечень щодо їхнього змісту.</p>','rules_read_confirm','','UA','2010-02-19 09:06:56','<p>Я підтверджую прочитання <a target=\"_blank\" href=\"/index.php?t=46&amp;language=UA\">Правил участі</a><br />\r\nта не маю заперечень щодо їхнього змісту.</p>','2010-02-19 09:06:56'),(0,'SAVE',0,'Зберегти','SAVE',NULL,'UA','2010-04-03 08:32:08','Зберегти','2010-04-03 08:32:08'),(0,'SELECT_POINTS_CONVERTION_TYPE',0,'Select points convertion type','SELECT_POINTS_CONVERTION_TYPE',NULL,'UA','2010-04-06 18:29:12','Select points convertion type','2010-04-06 18:29:12'),(0,'SEND',0,'Надіслати','SEND',NULL,'UA','2010-04-02 08:25:12','Надіслати','2010-04-02 08:25:12'),(0,'SETTLEMENT',0,'Район міста','SETTLEMENT',NULL,'UA','2010-04-02 08:25:12','Район міста','2010-04-02 08:25:12'),(0,'SEX',0,'Стать','SEX',NULL,'UA','2010-04-02 08:25:12','Стать','2010-04-02 08:25:12'),(0,'STREET',0,'Вулиця','STREET',NULL,'UA','2010-04-02 08:25:12','Вулиця','2010-04-02 08:25:12'),(0,'submit_text',0,'Confirm','submit_text',NULL,'EN','2009-11-14 21:07:33','Confirm','2009-11-14 21:07:33'),(0,'subscribe_confirm_thanks_content',0,'Your subscription is confirmed. Thank you.','subscribe_confirm_thanks_content',NULL,'EN','2009-11-14 21:07:33','Your subscription is confirmed. Thank you.','2009-11-14 21:07:33'),(0,'subscribe_error',0,'There are happened some error. Maybe you already confirmed the subscription/unsubscription.','subscribe_error',NULL,'EN','2009-11-14 21:07:33','There are happened some error. Maybe you already confirmed the subscription/unsubscription.','2009-11-14 21:07:33'),(0,'subscribe_error',0,NULL,'subscribe_error',NULL,'UA','2010-03-25 14:16:55',NULL,'2010-03-25 14:16:55'),(0,'subscription_thanks_content',0,'Thank you for subscription!','subscription_thanks_content',NULL,'EN','2009-11-14 21:07:33','Thank you for subscription!','2009-11-14 21:07:33'),(0,'survey_history_no_info',0,'<p class=\"content_simple_text\">Якщо ви ще не брали участь у дослідженнях, то, будь-ласка, перейдіть до розділу &ldquo;<a href=\"/index.php?t=45&amp;language=UA\">Поточні дослідження</a>&rdquo;, де ви зможете ознайомитися з переліком досліджень, що проводятся в даний час та взяти участь у тих, що вас зацікавлять.</p>\r\n<p>&nbsp;</p>\r\n<p class=\"content_simple_text\">Якщо ви брали участь у дослідженнях, але система не зареєструвала цього, то, будь-ласка, повідомте про це в службу підтримки:</p>\r\n<p><a class=\"system_button2\" href=\"mailto:info@2kgroup.com\">Повідомити службу підтримки</a></p>','survey_history_no_info','','UA','2010-01-27 05:18:46','<p class=\"content_simple_text\">Якщо ви ще не брали участь у дослідженнях, то, будь-ласка, перейдіть до розділу &ldquo;<a href=\"/index.php?t=45&amp;language=UA\">Поточні дослідження</a>&rdquo;, де ви зможете ознайомитися з переліком досліджень, що проводятся в даний час та взяти участь у тих, що вас зацікавлять.</p>\r\n<p>&nbsp;</p>\r\n<p class=\"content_simple_text\">Якщо ви брали участь у дослідженнях, але система не зареєструвала цього, то, будь-ласка, повідомте про це в службу підтримки:</p>\r\n<p><a class=\"system_button2\" href=\"mailto:info@2kgroup.com\">Повідомити службу підтримки</a></p>','2010-01-27 05:18:46'),(0,'SURVEY_TITLE',0,'Тема опитування','SURVEY_TITLE',NULL,'UA','2010-04-02 08:23:57','Тема опитування','2010-04-02 08:23:57'),(0,'system_block_content',0,'<p class=\"content_simple_text\">Дізнайтеся більше про те, як можна використати свої бали, а також багато іншої цікавої інформації.</p>\r\n<p><a class=\"system_button2\" href=\"/index.php?t=52&amp;language=UA\">Перейти до розділу</a></p>','system_block_content','','UA','2010-01-28 22:04:00','<p class=\"content_simple_text\">Дізнайтеся більше про те, як можна використати свої бали, а також багато іншої цікавої інформації.</p>\r\n<p><a class=\"system_button2\" href=\"/index.php?t=52&amp;language=UA\">Перейти до розділу</a></p>','2010-01-28 22:04:00'),(0,'TAKE_PART',0,'Взяти участь','TAKE_PART',NULL,'UA','2010-04-02 08:36:47','Взяти участь','2010-04-02 08:36:47'),(0,'TAKE_PART_IN_INVESTIGATION',0,'Взяти участь у дослідженні','TAKE_PART_IN_INVESTIGATION',NULL,'UA','2010-04-02 08:35:35','Взяти участь у дослідженні','2010-04-02 08:35:35'),(0,'text_bottom',0,'text_bottom','text_bottom',NULL,'EN','2010-03-20 06:30:00','text_bottom','2009-11-14 21:07:33'),(0,'title_no_template',0,'title_no_template',NULL,NULL,'EN','2010-03-20 06:30:00','title_no_template','2009-11-14 21:07:33'),(0,'TOTAL',0,'Total','TOTAL',NULL,'UA','2010-04-02 08:23:57','Total','2010-04-02 08:23:57'),(0,'TOTAL_POINTS_AVAILABLE',0,'Всього доступних балів','TOTAL_POINTS_AVAILABLE',NULL,'UA','2010-04-02 08:23:57','Всього доступних балів','2010-04-02 08:23:57'),(0,'TOTAL_POINTS_USED',0,'Всього використано балів','TOTAL_POINTS_USED',NULL,'UA','2010-04-02 08:23:57','Всього використано балів','2010-04-02 08:23:57'),(0,'unsubscribe_confirm_thanks_content',0,'Your unsubscription is confirmed.','unsubscribe_confirm_thanks_content',NULL,'EN','2009-11-14 21:07:33','Your unsubscription is confirmed.','2009-11-14 21:07:33'),(0,'unsubscription_thanks_content',0,'Thank you for unsubscription!','unsubscription_thanks_content',NULL,'EN','2009-11-14 21:07:33','Thank you for unsubscription!','2009-11-14 21:07:33'),(0,'usefull_contact_block_content',0,'<p>1111 111 111111111 1 111111 11 1 111111</p>','usefull_contact_block_content','','UA','2010-01-13 18:22:18','<p>1111 111 111111111 1 111111 11 1 111111</p>','2010-01-13 18:22:18'),(0,'usefull_contact_block_title',0,'11111','usefull_contact_block_title','','UA','2010-01-13 18:21:15','11111','2010-01-13 18:21:15'),(0,'USE_OTHER-OPTION_TO_ENTER_OWN_VALUE',0,'Скористайтесь пунктом \'Iнший варiант\' щоб ввести назву самостiйно','USE_OTHER-OPTION_TO_ENTER_OWN_VALUE',NULL,'UA','2010-04-02 08:25:12','Скористайтесь пунктом \'Iнший варiант\' щоб ввести назву самостiйно','2010-04-02 08:25:12'),(0,'why_register_block_1_description',0,'<p class=\"content_simple_text\"><span class=\"arial12px\">Інформація &ndash; найцінніший ресурс сучасного цивілізованого світу.</span></p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\"><span class=\"arial12px\">Ви завжди будете в курсі останніх тенденцій і розробок на споживчих ринках. Ви приймете участь у розробці нових товарів та послуг. Вам буде відомо про зміни&nbsp;в асортименті, якості та складі товарів заздалегідь.</span></p>','why_register_block_1_description','','UA','2010-01-12 16:30:26','<p class=\"content_simple_text\"><span class=\"arial12px\">Інформація &ndash; найцінніший ресурс сучасного цивілізованого світу.</span></p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\"><span class=\"arial12px\">Ви завжди будете в курсі останніх тенденцій і розробок на споживчих ринках. Ви приймете участь у розробці нових товарів та послуг. Вам буде відомо про зміни&nbsp;в асортименті, якості та складі товарів заздалегідь.</span></p>','2010-01-12 16:30:26'),(0,'why_register_block_1_title',0,'Інформованість','why_register_block_1_title','','UA','2010-01-12 16:36:02','Інформованість','2010-01-12 16:36:02'),(0,'why_register_block_2_description',0,'<p class=\"content_simple_text\"><span class=\"arial12px\">Інформація &ndash; найцінніший ресурс сучасного цивілізованого світу.</span></p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\"><span class=\"arial12px\">Ви завжди будете в курсі останніх тенденцій і розробок на споживчих ринках. Ви приймете участь у розробці нових товарів та послуг. Вам буде відомо про зміни&nbsp;в асортименті, якості та складі товарів заздалегідь.</span></p>','why_register_block_2_description','','UA','2010-01-12 18:30:31','<p class=\"content_simple_text\"><span class=\"arial12px\">Інформація &ndash; найцінніший ресурс сучасного цивілізованого світу.</span></p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\"><span class=\"arial12px\">Ви завжди будете в курсі останніх тенденцій і розробок на споживчих ринках. Ви приймете участь у розробці нових товарів та послуг. Вам буде відомо про зміни&nbsp;в асортименті, якості та складі товарів заздалегідь.</span></p>','2010-01-12 18:30:31'),(0,'why_register_block_2_title',0,'Винагорода','why_register_block_2_title','','UA','2010-01-12 16:44:58','Винагорода','2010-01-12 16:44:58'),(0,'why_register_block_3_description',0,'<p>Визнання &ndash; найкраща подяка.</p>\r\n<p>&nbsp;</p>\r\n<p>Ваша думка визнана дуже важливою. Кожен учасник проекту вносить свою корективу у формування остаточних рішень щодо випуску товарів та послуг, вказує на стратегію виробника для задоволення власних потреб.</p>','why_register_block_3_description','','UA','2010-01-12 18:29:39','<p>Визнання &ndash; найкраща подяка.</p>\r\n<p>&nbsp;</p>\r\n<p>Ваша думка визнана дуже важливою. Кожен учасник проекту вносить свою корективу у формування остаточних рішень щодо випуску товарів та послуг, вказує на стратегію виробника для задоволення власних потреб.</p>','2010-01-12 18:29:39'),(0,'why_register_block_3_title',0,'Важливість вашої думки','why_register_block_3_title','','UA','2010-01-12 16:45:27','Важливість вашої думки','2010-01-12 16:45:27'),(0,'YOUR_ACCOUNT_%S_POINTS',0,'На Вашому рахунку %s балів','YOUR_ACCOUNT_%S_POINTS','','UA','2010-04-07 10:40:14','На Вашому рахунку %s балів','2010-04-07 10:40:14'),(0,'your_email_text',0,'E-mail:','your_email_text',NULL,'EN','2009-11-14 21:07:33','E-mail:','2009-11-14 21:07:33'),(0,'your_lname_text',0,'Surname:','your_lname_text',NULL,'EN','2009-11-14 21:07:33','Surname:','2009-11-14 21:07:33'),(0,'your_name_text',0,'Name:','your_name_text',NULL,'EN','2009-11-14 21:07:33','Name:','2009-11-14 21:07:33'),(0,'YOU_ARE_HERE',0,'Ви знаходитесь тут','YOU_ARE_HERE',NULL,'UA','2010-04-02 08:23:33','Ви знаходитесь тут','2010-04-02 08:23:33'),(1,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-08 13:51:35'),(1,'media_inserted_index_block_',4,'a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"76\";}','Media id for object index_block_4 on page 1',NULL,'','2010-01-08 14:36:45','a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"76\";}','2010-01-08 14:36:45'),(1,'media_inserted_index_block_1_header',0,'a:2:{s:4:\"link\";a:3:{s:4:\"type\";s:13:\"open_sat_page\";s:3:\"sat\";s:2:\"35\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"70\";}','Media id for object index_block_1_header on page 1','','','2010-01-28 18:22:09','a:2:{s:4:\"link\";a:3:{s:4:\"type\";s:13:\"open_sat_page\";s:3:\"sat\";s:2:\"35\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"70\";}','2010-01-28 18:22:09'),(1,'media_inserted_index_block_1_header_for_authorized',0,'a:2:{s:4:\"link\";a:3:{s:4:\"type\";s:13:\"open_sat_page\";s:3:\"sat\";s:2:\"30\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"77\";}','Media id for object index_block_1_header_for_authorized on page 1',NULL,'','2010-01-11 08:23:05','a:2:{s:4:\"link\";a:3:{s:4:\"type\";s:13:\"open_sat_page\";s:3:\"sat\";s:2:\"30\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"77\";}','2010-01-11 08:23:05'),(1,'media_inserted_index_block_1_top',0,'a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"71\";}','Media id for object index_block_1_top on page 1',NULL,'','2010-01-08 14:31:33','a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"71\";}','2010-01-08 14:31:33'),(1,'media_inserted_index_block_2_header',0,'a:2:{s:4:\"link\";a:3:{s:4:\"type\";s:13:\"open_sat_page\";s:3:\"sat\";s:2:\"40\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"72\";}','Media id for object index_block_2_header on page 1','','','2010-01-28 18:22:41','a:2:{s:4:\"link\";a:3:{s:4:\"type\";s:13:\"open_sat_page\";s:3:\"sat\";s:2:\"40\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"72\";}','2010-01-28 18:22:41'),(1,'media_inserted_index_block_2_top',0,'a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"73\";}','Media id for object index_block_2_top on page 1',NULL,'','2010-01-08 14:31:47','a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"73\";}','2010-01-08 14:31:47'),(1,'media_inserted_index_block_3_header',0,'a:2:{s:4:\"link\";a:3:{s:4:\"type\";s:13:\"open_sat_page\";s:3:\"sat\";s:2:\"47\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"74\";}','Media id for object index_block_3_header on page 1',NULL,'','2010-01-08 14:08:57','a:2:{s:4:\"link\";a:3:{s:4:\"type\";s:13:\"open_sat_page\";s:3:\"sat\";s:2:\"47\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"74\";}','2010-01-08 14:08:57'),(1,'media_inserted_index_block_3_header_for_authorized',0,'a:2:{s:4:\"link\";a:3:{s:4:\"type\";s:13:\"open_sat_page\";s:3:\"sat\";s:2:\"45\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"78\";}','Media id for object index_block_3_header_for_authorized on page 1',NULL,'','2010-01-11 08:32:23','a:2:{s:4:\"link\";a:3:{s:4:\"type\";s:13:\"open_sat_page\";s:3:\"sat\";s:2:\"45\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"78\";}','2010-01-11 08:32:23'),(1,'media_inserted_index_block_3_top',0,'a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"75\";}','Media id for object index_block_3_top on page 1',NULL,'','2010-01-08 14:32:01','a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"75\";}','2010-01-08 14:32:01'),(1,'media_inserted_index_splash',0,'a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"92\";}','Media id for object index_splash on page 1','','','2010-03-04 15:23:14','a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"92\";}','2010-03-04 15:23:14'),(1,'media_title_index_block_',4,'','Media id for object index_block_4 on page 1',NULL,'UA','2010-01-08 14:36:45','','2010-01-08 14:36:45'),(1,'media_title_index_block_1_header',0,'','Media id for object index_block_1_header on page 1','','UA','2010-01-28 18:22:09','','2010-01-28 18:22:09'),(1,'media_title_index_block_1_header_for_authorized',0,'','Media id for object index_block_1_header_for_authorized on page 1',NULL,'UA','2010-01-11 08:23:05','','2010-01-11 08:23:05'),(1,'media_title_index_block_1_top',0,'','Media id for object index_block_1_top on page 1',NULL,'UA','2010-01-08 14:31:33','','2010-01-08 14:31:33'),(1,'media_title_index_block_2_header',0,'','Media id for object index_block_2_header on page 1','','UA','2010-01-28 18:22:41','','2010-01-28 18:22:41'),(1,'media_title_index_block_2_top',0,'','Media id for object index_block_2_top on page 1',NULL,'UA','2010-01-08 14:31:47','','2010-01-08 14:31:47'),(1,'media_title_index_block_3_header',0,'','Media id for object index_block_3_header on page 1',NULL,'UA','2010-01-08 14:08:57','','2010-01-08 14:08:57'),(1,'media_title_index_block_3_header_for_authorized',0,'','Media id for object index_block_3_header_for_authorized on page 1',NULL,'UA','2010-01-11 08:32:23','','2010-01-11 08:32:23'),(1,'media_title_index_block_3_top',0,'','Media id for object index_block_3_top on page 1',NULL,'UA','2010-01-08 14:32:01','','2010-01-08 14:32:01'),(1,'media_title_index_splash',0,'','Media id for object index_splash on page 1','','UA','2010-03-04 15:23:14','','2010-03-04 15:23:14'),(19,'nl_notification_from_email',0,'root@2kgroup.com','nl_notification_from_email',NULL,'EN','2009-11-14 21:07:33','root@2kgroup.com','2009-11-14 21:07:33'),(19,'nl_notification_subject',0,'Test Subject','nl_notification_subject',NULL,'EN','2009-11-14 21:07:33','Test Subject','2009-11-14 21:07:33'),(19,'page_content',0,'Hello!\r\n\r\nYou have just subscribed to the Newsletters\r\n\r\nPlease click on the following link to confirm your subscription:\r\n{{CONFIRM_LINK}}\r\nBest Regards\r\nm','page_content',NULL,'EN','2010-03-20 06:30:00','Hello!\r\n\r\nYou have just subscribed to the Newsletters\r\n\r\nPlease click on the following link to confirm your subscription:\r\n{{CONFIRM_LINK}}\r\nBest Regards\r\nm','2009-11-14 21:07:33'),(29,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-14 16:01:17'),(29,'internal_page_content',0,'<h1>Використання інформації на веб-сайті</h1>\r\n<p class=\"content_simple_text\">Будь-яка особа може отримати доступ до даного веб-сайту та використовувати його виключно при виконанні умов, викладених нижче, а також чинного законодавства України. <br />\r\nКористувач має право переглядати інформацію на даному веб-сайті виключно в цілях отримання інформації для особистих потреб. Категорично забороняється розповсюдження інформації, отриманої на даному веб-сайті, зміна та виправлення її будь-яким чином або передача третім особам у комерційних цілях без письмового дозволу ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo;.<br />\r\nТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo; не несе відповідальності за прямі або опосередковані збитки, що можуть виникнути у Користувача в результаті отримання доступу або використання будь-якої інформації, що міститься на даному веб-сайті або на будь-якому з веб-сайтів, що мають інтерактивний зв&rsquo;язок з ним.</p>\r\n<p>&nbsp;</p>\r\n<h1>Авторські права</h1>\r\n<p class=\"content_simple_text\">Будь-які найменування, логотипи та торгові знаки, що зустрічаються на даному сайті, за виключенням окремо вказаних випадків, є торговими знаками котрі належать та використовуються ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo; або афільованими компаніями або особами у тих місцях, де ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo; реалізує продукти, що мають ці торгові знаки. Категорично забороняється використання або неналежне застосування цих торгових знаків або будь-якої іншої інформації, що міститься на даному сайті, крім випадків, передбачених даними умовами або вмістом веб-сайту ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo;.<br />\r\nБудь-яке відтворення матеріалів даного веб-сайту можливе тільки з письмового дозволу ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo;. При публікації будь-якої інформації з сайту ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo; у ЗМІ обов&rsquo;язково потрібно робити посилання на джерело даних.<br />\r\nПри публікації даних в Інтернет посилання на джерело повинне бути активним гіперпосиланням на відповідну сторінку веб-сайту www.tns-ua.com. або www.accesspanel.com.ua</p>','internal_page_content','','UA','2010-01-29 18:01:27','<h1>Використання інформації на веб-сайті</h1>\r\n<p class=\"content_simple_text\">Будь-яка особа може отримати доступ до даного веб-сайту та використовувати його виключно при виконанні умов, викладених нижче, а також чинного законодавства України. <br />\r\nКористувач має право переглядати інформацію на даному веб-сайті виключно в цілях отримання інформації для особистих потреб. Категорично забороняється розповсюдження інформації, отриманої на даному веб-сайті, зміна та виправлення її будь-яким чином або передача третім особам у комерційних цілях без письмового дозволу ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo;.<br />\r\nТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo; не несе відповідальності за прямі або опосередковані збитки, що можуть виникнути у Користувача в результаті отримання доступу або використання будь-якої інформації, що міститься на даному веб-сайті або на будь-якому з веб-сайтів, що мають інтерактивний зв&rsquo;язок з ним.</p>\r\n<p>&nbsp;</p>\r\n<h1>Авторські права</h1>\r\n<p class=\"content_simple_text\">Будь-які найменування, логотипи та торгові знаки, що зустрічаються на даному сайті, за виключенням окремо вказаних випадків, є торговими знаками котрі належать та використовуються ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo; або афільованими компаніями або особами у тих місцях, де ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo; реалізує продукти, що мають ці торгові знаки. Категорично забороняється використання або неналежне застосування цих торгових знаків або будь-якої іншої інформації, що міститься на даному сайті, крім випадків, передбачених даними умовами або вмістом веб-сайту ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo;.<br />\r\nБудь-яке відтворення матеріалів даного веб-сайту можливе тільки з письмового дозволу ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo;. При публікації будь-якої інформації з сайту ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo; у ЗМІ обов&rsquo;язково потрібно робити посилання на джерело даних.<br />\r\nПри публікації даних в Інтернет посилання на джерело повинне бути активним гіперпосиланням на відповідну сторінку веб-сайту www.tns-ua.com. або www.accesspanel.com.ua</p>','2010-01-29 18:01:27'),(29,'page_header',0,NULL,'page_header',NULL,'UA','2010-02-25 13:59:57',NULL,'2010-02-25 13:59:57'),(30,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-04 11:36:57'),(30,'int_b_class',0,'D4EEED','int_b_class','','UA','2010-01-22 16:42:57','D4EEED','2010-01-22 16:42:57'),(30,'int_h_class',0,'47B3B8','int_h_class','','UA','2010-01-22 16:42:34','47B3B8','2010-01-22 16:42:34'),(30,'page_comment',0,'Накопичуйте бали, беручи участь в опитуваннях. Кожне \r\nопитування принесе Вам бали.','page_comment','','UA','2010-01-04 11:37:15','Накопичуйте бали, беручи участь в опитуваннях. Кожне \r\nопитування принесе Вам бали.','2010-01-04 11:37:15'),(30,'page_error',0,'Нажаль в системі поки що немає даних про вашу участь у дослідженнях.','page_error','','UA','2010-01-22 18:42:07','Нажаль в системі поки що немає даних про вашу участь у дослідженнях.','2010-01-22 18:42:07'),(31,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-02-22 11:19:16'),(31,'internal_page_content',0,'<p>Нажаль, ви ще не набрали достатню кількість балів для конвертації.</p>','internal_page_content','','UA','2010-02-22 11:20:18','<p>Нажаль, ви ще не набрали достатню кількість балів для конвертації.</p>','2010-02-22 11:20:18'),(31,'page_comment',0,'','page_comment','','UA','2010-02-22 11:20:10','','2010-02-22 11:20:10'),(33,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-14 15:59:51'),(33,'internal_page_content',0,'<h1>Про захист даних переданих в Інтернет</h1>\r\n<p class=\"content_simple_text\">ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo; проводить дуже кропітку роботу щодо захисту будь-яких даних переданих в Інтернет. Ця політика конфіденційності розповсюджується на респондентів, що завершили або проходять опитування з будь-якої тематики вивчення ринку.</p>\r\n<p class=\"content_simple_text\">Дані, що ми отримуємо в процесі проведення досліджень, можуть бути використані лише&nbsp;в наукових або дослідницьких цілях.</p>\r\n<p>&nbsp;</p>\r\n<h1>Коли та яку саме інформацію ми збираємо?</h1>\r\n<p class=\"content_simple_text\">Ваша персональна інформація збирається коли ви заповнюєте форми зворотного зв&rsquo;язку та відсилаєте ці дані до ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo; або зв&rsquo;язуєтесь з нами по телефону. Зокрема, ми записуємо ваше ім&rsquo;я, прізвище, адресу, адресу електронної пошти, номер телефону(включаючи номер мобільного телефону), будь-яку іншу інформацію, яку ви передаєте нам про сфери вашого інтересу, інформацію, що ви передаєте беручи участь в опитуваннях, що проводить ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo;. Ми впевнені, що збір усієї цієї інформації є дуже важливим та може допомогти нам при подальшій співпраці з вами. Уся інформація, яку ви передаєте нам буде оброблятись та зберігатись з найвищою відповідальністю.</p>\r\n<p class=\"content_simple_text\">Під час проведення досліджень, ми збираємо ваші відповіді у кодованому чисельному вигляді. Ми гарантуємо повну конфіденційність ваших відповідей.</p>\r\n<p>&nbsp;</p>\r\n<h1>Що ми робимо з Вашими персональними даними?</h1>\r\n<p class=\"content_simple_text\">Ваші персональні дані потрібні лише для вашого профайлу у співтоваристві, а також можуть бути використані працівниками&nbsp;ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo; для зв&rsquo;язку з Вами. Прикладом такого зв&rsquo;язку можуть бути запрошення до участі у дослідженні, прес-релізи, запрошення на семінари та виставки, що проводить ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo;, газети, електронні газети, звіти по дослідженню ринків, галузеві аналізи, корпоративні або фінансові оповіщення або будь-які інші загальні відгуки на ваші можливі запити.</p>\r\n<p>&nbsp;</p>\r\n<h1>Кому доступна Ваша інформація?</h1>\r\n<p class=\"content_simple_text\">Інформація, яку Ви надаєте про себе під час реєстрації потрібна лише для вашої авторизації на сайті.</p>\r\n<p class=\"content_simple_text\">Ми не передаємо реєстраційні дані або&nbsp;відповіді на запитання у дослідженнях третім особам.</p>\r\n<p>&nbsp;</p>\r\n<h1>Передача інформації</h1>\r\n<p class=\"content_simple_text\">Передача вашої особистої інформації можлива лише у випадках, передбачених чинним законодавском України.</p>\r\n<p>&nbsp;</p>\r\n<h1>Додатково</h1>\r\n<p class=\"content_simple_text\">Будь-ласка, завершуйте сеанс роботи з сайтом натисканням кнопки &quot;Вихід&quot;. Це дасть можливість бути упевненим, що жодна третя особа не має доступі до ваших особистих даних.</p>\r\n<p class=\"content_simple_text\">Ця політика конфіденційності розроблена у відповідності до чинного законодавства України. У випадку зміни будь-якого пункту цієї політики конфіденційності ми зобов&rsquo;язуємось у 30-денний строк розмістити їх на веб-сайті. Ми ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo;, учасник Taylor Nelson Sofres group, учасник Kantar Group, зареєстровані за адресою м.Київ, вул. Ігорівська 1/8, літера &laquo;В&raquo;.</p>\r\n<p>&nbsp;</p>','internal_page_content','','UA','2010-01-29 18:00:42','<h1>Про захист даних переданих в Інтернет</h1>\r\n<p class=\"content_simple_text\">ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo; проводить дуже кропітку роботу щодо захисту будь-яких даних переданих в Інтернет. Ця політика конфіденційності розповсюджується на респондентів, що завершили або проходять опитування з будь-якої тематики вивчення ринку.</p>\r\n<p class=\"content_simple_text\">Дані, що ми отримуємо в процесі проведення досліджень, можуть бути використані лише&nbsp;в наукових або дослідницьких цілях.</p>\r\n<p>&nbsp;</p>\r\n<h1>Коли та яку саме інформацію ми збираємо?</h1>\r\n<p class=\"content_simple_text\">Ваша персональна інформація збирається коли ви заповнюєте форми зворотного зв&rsquo;язку та відсилаєте ці дані до ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo; або зв&rsquo;язуєтесь з нами по телефону. Зокрема, ми записуємо ваше ім&rsquo;я, прізвище, адресу, адресу електронної пошти, номер телефону(включаючи номер мобільного телефону), будь-яку іншу інформацію, яку ви передаєте нам про сфери вашого інтересу, інформацію, що ви передаєте беручи участь в опитуваннях, що проводить ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo;. Ми впевнені, що збір усієї цієї інформації є дуже важливим та може допомогти нам при подальшій співпраці з вами. Уся інформація, яку ви передаєте нам буде оброблятись та зберігатись з найвищою відповідальністю.</p>\r\n<p class=\"content_simple_text\">Під час проведення досліджень, ми збираємо ваші відповіді у кодованому чисельному вигляді. Ми гарантуємо повну конфіденційність ваших відповідей.</p>\r\n<p>&nbsp;</p>\r\n<h1>Що ми робимо з Вашими персональними даними?</h1>\r\n<p class=\"content_simple_text\">Ваші персональні дані потрібні лише для вашого профайлу у співтоваристві, а також можуть бути використані працівниками&nbsp;ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo; для зв&rsquo;язку з Вами. Прикладом такого зв&rsquo;язку можуть бути запрошення до участі у дослідженні, прес-релізи, запрошення на семінари та виставки, що проводить ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo;, газети, електронні газети, звіти по дослідженню ринків, галузеві аналізи, корпоративні або фінансові оповіщення або будь-які інші загальні відгуки на ваші можливі запити.</p>\r\n<p>&nbsp;</p>\r\n<h1>Кому доступна Ваша інформація?</h1>\r\n<p class=\"content_simple_text\">Інформація, яку Ви надаєте про себе під час реєстрації потрібна лише для вашої авторизації на сайті.</p>\r\n<p class=\"content_simple_text\">Ми не передаємо реєстраційні дані або&nbsp;відповіді на запитання у дослідженнях третім особам.</p>\r\n<p>&nbsp;</p>\r\n<h1>Передача інформації</h1>\r\n<p class=\"content_simple_text\">Передача вашої особистої інформації можлива лише у випадках, передбачених чинним законодавском України.</p>\r\n<p>&nbsp;</p>\r\n<h1>Додатково</h1>\r\n<p class=\"content_simple_text\">Будь-ласка, завершуйте сеанс роботи з сайтом натисканням кнопки &quot;Вихід&quot;. Це дасть можливість бути упевненим, що жодна третя особа не має доступі до ваших особистих даних.</p>\r\n<p class=\"content_simple_text\">Ця політика конфіденційності розроблена у відповідності до чинного законодавства України. У випадку зміни будь-якого пункту цієї політики конфіденційності ми зобов&rsquo;язуємось у 30-денний строк розмістити їх на веб-сайті. Ми ТОВ &laquo;Тейлор Нельсон Софрез Україна&raquo;, учасник Taylor Nelson Sofres group, учасник Kantar Group, зареєстровані за адресою м.Київ, вул. Ігорівська 1/8, літера &laquo;В&raquo;.</p>\r\n<p>&nbsp;</p>','2010-01-29 18:00:42'),(33,'page_comment',0,NULL,'page_comment',NULL,'UA','2010-02-25 13:57:47',NULL,'2010-02-25 13:57:47'),(33,'page_header',0,'Конфіденційність','page_header','','UA','2010-02-25 13:59:27','Конфіденційність','2010-02-25 13:59:27'),(35,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-09 18:51:29'),(35,'faq_block_content',0,'<p>444444 4 4444444 444 444444444444 444444 4444444 444 4444 44444444 4444 4 444</p>','faq_block_content','','UA','2010-01-13 18:27:57','<p>444444 4 4444444 444 444444444444 444444 4444444 444 4444 44444444 4444 4 444</p>','2010-01-13 18:27:57'),(35,'faq_block_title',0,'44444444 44','faq_block_title','','UA','2010-01-13 18:27:21','44444444 44','2010-01-13 18:27:21'),(35,'internal_page_content',0,'<p>TNS Opros &ndash; це нова сходинка у Вашій розмові з виробником.</p>\r\n<p>&nbsp;</p>\r\n<p>TNS Opros &ndash; це новий проект TNS, який має за мету об\'єднати зовсім різних <br />\r\nлюдей для однієї цілі &ndash; зробити навколишній світ більш затишним та <br />\r\nзручним саме для Вас.</p>\r\n<p>&nbsp;</p>\r\n<p>TNS Opros &ndash; це нове співтовариство людей, які можуть у реальному житті <br />\r\nбути знайомими, або незнайомими, жити в одному місці або у різних, <br />\r\nлюбити морозиво або ні &ndash; це хлопчики та дівчата, чоловіки та жінки, <br />\r\nдідусі та бабусі, які бажають бути почутими.</p>\r\n<p>&nbsp;</p>\r\n<p>TNS Opros &ndash; це співтовариство людей, що дають згоду на участь в <br />\r\nопитуваннях компанії TNS за винагороду.</p>','internal_page_content','','UA','2010-03-29 17:32:43','<p>TNS Opros &ndash; це нова сходинка у Вашій розмові з виробником.</p>\r\n<p>&nbsp;</p>\r\n<p>TNS Opros &ndash; це новий проект TNS, який має за мету об\'єднати зовсім різних <br />\r\nлюдей для однієї цілі &ndash; зробити навколишній світ більш затишним та <br />\r\nзручним саме для Вас.</p>\r\n<p>&nbsp;</p>\r\n<p>TNS Opros &ndash; це нове співтовариство людей, які можуть у реальному житті <br />\r\nбути знайомими, або незнайомими, жити в одному місці або у різних, <br />\r\nлюбити морозиво або ні &ndash; це хлопчики та дівчата, чоловіки та жінки, <br />\r\nдідусі та бабусі, які бажають бути почутими.</p>\r\n<p>&nbsp;</p>\r\n<p>TNS Opros &ndash; це співтовариство людей, що дають згоду на участь в <br />\r\nопитуваннях компанії TNS за винагороду.</p>','2010-03-29 17:32:43'),(35,'internal_page_header',0,'Коротко о главном','internal_page_header','','RU','2010-04-02 08:30:20','Коротко о главном','2010-04-02 08:30:20'),(35,'internal_page_header',0,'Коротко про головне','internal_page_header','','UA','2010-01-09 18:57:53','Коротко про головне','2010-01-09 18:57:53'),(35,'int_b_class',0,'CDE8F3','int_b_class','','UA','2010-01-09 18:56:58','CDE8F3','2010-01-09 18:56:58'),(35,'int_h_class',0,'0086D3','int_h_class','','UA','2010-01-09 18:51:44','0086D3','2010-01-09 18:51:44'),(35,'page_comment',0,'TNS в Украине вышла на рынок онлайн исследований. Быть с нами значит получать наилучшее. Проект “Opros” качественно изменит вашу жизнь и отношение к продуктам и услугам.','page_comment','','RU','2010-04-02 08:32:37','TNS в Украине вышла на рынок онлайн исследований. Быть с нами значит получать наилучшее. Проект “Opros” качественно изменит вашу жизнь и отношение к продуктам и услугам.','2010-04-02 08:32:37'),(35,'page_comment',0,'TNS в Україні вийшла на ринок онлайн досліджень. Бути з нами означає отримувати найкраще. Проект “Opros” якісно змінить ваше життя та ставлення до продуктів та послуг.','page_comment','','UA','2010-03-29 18:03:54','TNS в Україні вийшла на ринок онлайн досліджень. Бути з нами означає отримувати найкраще. Проект “Opros” якісно змінить ваше життя та ставлення до продуктів та послуг.','2010-03-29 18:03:54'),(35,'page_header',0,NULL,'page_header',NULL,'UA','2010-03-29 17:31:34',NULL,'2010-03-29 17:31:34'),(35,'usefull_contact_block_content',0,'<p>222222 2 2222 22222 222 22222</p>','usefull_contact_block_content','','UA','2010-01-13 18:23:35','<p>222222 2 2222 22222 222 22222</p>','2010-01-13 18:23:35'),(35,'usefull_contact_block_title',0,'2222222222','usefull_contact_block_title','','UA','2010-01-13 18:23:00','2222222222','2010-01-13 18:23:00'),(37,'contact_block_content',0,'<p class=\"pink_15_lm\">Віктор Божко</p>\r\n<p class=\"content_simple_text_lm\">м. Київ вул. Ігорівська 1/8 літера &ldquo;В&rdquo;</p>\r\n<p class=\"content_simple_text_lm\">045 201 10 15</p>\r\n<p><a href=\"mailto:tortiki@ukr.net?subject=Question\" class=\"system_button2\">Надіслати повідомлення</a></p>','contact_block_content','','UA','2010-01-19 13:49:27','<p class=\"pink_15_lm\">Віктор Божко</p>\r\n<p class=\"content_simple_text_lm\">м. Київ вул. Ігорівська 1/8 літера &ldquo;В&rdquo;</p>\r\n<p class=\"content_simple_text_lm\">045 201 10 15</p>\r\n<p><a href=\"mailto:tortiki@ukr.net?subject=Question\" class=\"system_button2\">Надіслати повідомлення</a></p>','2010-01-19 13:49:27'),(37,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-19 07:12:58'),(37,'page_error',0,'При заповненні форми були допущені помилки. \r\nБудь-ласка, перевірте введені дані ще раз.','page_error','','UA','2010-01-19 07:13:04','При заповненні форми були допущені помилки. \r\nБудь-ласка, перевірте введені дані ще раз.','2010-01-19 07:13:04'),(39,'block_1_description',0,'<p class=\"content_simple_text\"><span class=\"arial12px\">Інформація &ndash; найцінніший ресурс сучасного цивілізованого світу.</span></p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\"><span class=\"arial12px\">Ви завжди будете в курсі останніх тенденцій і розробок на споживчих ринках. Ви приймете участь у розробці нових товарів та послуг. Вам буде відомо про зміни&nbsp;в асортименті, якості та складі товарів заздалегідь.</span></p>','block_1_description','','UA','2010-01-12 20:18:25','<p class=\"content_simple_text\"><span class=\"arial12px\">Інформація &ndash; найцінніший ресурс сучасного цивілізованого світу.</span></p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\"><span class=\"arial12px\">Ви завжди будете в курсі останніх тенденцій і розробок на споживчих ринках. Ви приймете участь у розробці нових товарів та послуг. Вам буде відомо про зміни&nbsp;в асортименті, якості та складі товарів заздалегідь.</span></p>','2010-01-12 20:18:25'),(39,'block_1_title',0,'Інформованість','block_1_title','','UA','2010-01-12 19:02:25','Інформованість','2010-01-12 19:02:25'),(39,'block_2_description',0,'<p class=\"content_simple_text\"><span class=\"arial12px\">Вчасна копійка дорожча за буденну гривню.</span></p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\"><span class=\"arial12px\">За кожне пройдене опитування ви будете отримувати накопичувальні бали, які можна конвертувати у реальні гроші. Таким чином це ще один спосіб підзаробити в Інтернет, але на відміну від інших багатьох &ndash; прозорий.</span></p>','block_2_description','','UA','2010-02-24 11:17:12','<p class=\"content_simple_text\"><span class=\"arial12px\">Вчасна копійка дорожча за буденну гривню.</span></p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\"><span class=\"arial12px\">За кожне пройдене опитування ви будете отримувати накопичувальні бали, які можна конвертувати у реальні гроші. Таким чином це ще один спосіб підзаробити в Інтернет, але на відміну від інших багатьох &ndash; прозорий.</span></p>','2010-02-24 11:17:12'),(39,'block_2_title',0,'Винагорода','block_2_title','','UA','2010-01-12 20:22:33','Винагорода','2010-01-12 20:22:33'),(39,'block_3_description',0,'<p>Визнання &ndash; найкраща подяка.</p>\r\n<p>&nbsp;</p>\r\n<p>Ваша думка визнана дуже важливою. Кожен учасник проекту вносить свою корективу у формування остаточних рішень щодо випуску товарів та послуг, вказує на стратегію виробника для задоволення власних потреб.</p>','block_3_description','','UA','2010-01-12 20:21:11','<p>Визнання &ndash; найкраща подяка.</p>\r\n<p>&nbsp;</p>\r\n<p>Ваша думка визнана дуже важливою. Кожен учасник проекту вносить свою корективу у формування остаточних рішень щодо випуску товарів та послуг, вказує на стратегію виробника для задоволення власних потреб.</p>','2010-01-12 20:21:11'),(39,'block_3_title',0,'Важливість вашої думки','block_3_title','','UA','2010-01-12 20:22:03','Важливість вашої думки','2010-01-12 20:22:03'),(39,'contact_block_content',0,'<p><img height=\"44\" align=\"left\" width=\"45\" vspace=\"4\" alt=\"\" src=\"/usersimage/Image/person.PNG\" /></p>\r\n<p class=\"pink_15_lm\">Віктор Божко</p>\r\n<p class=\"content_simple_text_lm\">м. Київ вул. Ігорівська 1/8 літера &ldquo;В&rdquo;</p>\r\n<p class=\"content_simple_text_lm\">044 201 10 15</p>\r\n<p><a class=\"system_button2\" href=\"mailto:viktor.bozhko@tns-ua.com?subject=Question\">Надіслати повідомлення</a></p>','contact_block_content','','UA','2010-02-01 15:34:07','<p><img height=\"44\" align=\"left\" width=\"45\" vspace=\"4\" alt=\"\" src=\"/usersimage/Image/person.PNG\" /></p>\r\n<p class=\"pink_15_lm\">Віктор Божко</p>\r\n<p class=\"content_simple_text_lm\">м. Київ вул. Ігорівська 1/8 літера &ldquo;В&rdquo;</p>\r\n<p class=\"content_simple_text_lm\">044 201 10 15</p>\r\n<p><a class=\"system_button2\" href=\"mailto:viktor.bozhko@tns-ua.com?subject=Question\">Надіслати повідомлення</a></p>','2010-02-01 15:34:07'),(39,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-12 16:28:43'),(39,'int_h_1_class',0,'','int_h_1_class','','UA','2010-01-12 16:43:07','','2010-01-12 16:43:07'),(39,'media_inserted_why_register',0,'a:2:{s:4:\"link\";a:3:{s:4:\"type\";s:13:\"open_sat_page\";s:3:\"sat\";s:2:\"47\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"85\";}','Media id for object why_register on page 39','','','2010-04-07 15:16:23','a:2:{s:4:\"link\";a:3:{s:4:\"type\";s:13:\"open_sat_page\";s:3:\"sat\";s:2:\"47\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"85\";}','2010-04-07 15:16:23'),(39,'media_inserted_why_register_block_',1,'a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"79\";}','Media id for object why_register_block_1 on page 39',NULL,'','2010-01-12 16:28:43','a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"79\";}','2010-01-12 16:28:43'),(39,'media_inserted_why_register_block_',2,'a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"80\";}','Media id for object why_register_block_2 on page 39',NULL,'','2010-01-12 18:22:36','a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"80\";}','2010-01-12 18:22:36'),(39,'media_inserted_why_register_block_',3,'a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"81\";}','Media id for object why_register_block_3 on page 39',NULL,'','2010-01-12 18:27:48','a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"81\";}','2010-01-12 18:27:48'),(39,'media_title_why_register',0,'','Media id for object why_register on page 39','','UA','2010-04-07 15:16:23','','2010-04-07 15:16:23'),(39,'media_title_why_register_block_',1,'','Media id for object why_register_block_1 on page 39',NULL,'UA','2010-01-12 16:28:43','','2010-01-12 16:28:43'),(39,'media_title_why_register_block_',2,'','Media id for object why_register_block_2 on page 39',NULL,'UA','2010-01-12 18:22:36','','2010-01-12 18:22:36'),(39,'media_title_why_register_block_',3,'','Media id for object why_register_block_3 on page 39',NULL,'UA','2010-01-12 18:27:48','','2010-01-12 18:27:48'),(39,'right_block_h_class_contact',0,NULL,'right_block_h_class_contact',NULL,'UA','2010-01-27 12:40:21',NULL,'2010-01-27 12:40:21'),(40,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-21 16:12:04'),(40,'int_b_class',0,'E3E2EE','int_b_class','','UA','2010-01-21 16:15:21','E3E2EE','2010-01-21 16:15:21'),(40,'int_h_class',0,NULL,'int_h_class',NULL,'RU','2010-03-29 17:36:16',NULL,'2010-03-29 17:36:16'),(40,'int_h_class',0,'8A81BA','int_h_class','','UA','2010-01-21 16:12:37','8A81BA','2010-01-21 16:12:37'),(40,'page_comment',0,'Дбаючи про Вашу інформованість ми публікуємо новини та прес-релізи на сайті, а також розповсюджуємо їх у ЗМІ.','page_comment','','UA','2010-01-21 16:23:33','Дбаючи про Вашу інформованість ми публікуємо новини та прес-релізи на сайті, а також розповсюджуємо їх у ЗМІ.','2010-01-21 16:23:33'),(42,'block_1_description',0,'<p class=\"content_simple_text\">Ви могли собі уявити, що виробник бажає отримати саме ваші <br />\r\nвідповіді на питання яким зробити новий продукт, або як змінити <br />\r\nстарий так, щоб він Вам сподобався?</p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\">Участь у даному співтоваристві не вимагає від вас якимось чином <br />\r\nзмінювати свій спосіб життя. Навпаки &ndash; нам ви цікаві саме такими, як <br />\r\nви звикли.</p>','block_1_description','','UA','2010-01-12 21:50:12','<p class=\"content_simple_text\">Ви могли собі уявити, що виробник бажає отримати саме ваші <br />\r\nвідповіді на питання яким зробити новий продукт, або як змінити <br />\r\nстарий так, щоб він Вам сподобався?</p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\">Участь у даному співтоваристві не вимагає від вас якимось чином <br />\r\nзмінювати свій спосіб життя. Навпаки &ndash; нам ви цікаві саме такими, як <br />\r\nви звикли.</p>','2010-01-12 21:50:12'),(42,'block_1_title',0,'Предпосылки создания 36.6','block_1_title','','RU','2010-03-30 10:34:37','Предпосылки создания 36.6','2010-03-30 10:34:37'),(42,'block_1_title',0,'Передумови створення TNS Opros','block_1_title','','UA','2010-03-30 11:26:21','Передумови створення TNS Opros','2010-03-30 11:26:21'),(42,'block_2_description_',1,'<p>Першою, і найбільш важливою перевагою 36.6 є те, що усі ваші відповіді, які ви зробите у рамках проекту будуть враховані виробниками у своїх стратегіях щодо випуску товарів та послуг у майбутньому. Таким чином, через деякий час після дослідження, ви можете побачити на полиці новий <br />\r\nпродукт, який допомогли створити виробнику.</p>','block_2_description_1','','UA','2010-01-12 21:35:35','<p>Першою, і найбільш важливою перевагою 36.6 є те, що усі ваші відповіді, які ви зробите у рамках проекту будуть враховані виробниками у своїх стратегіях щодо випуску товарів та послуг у майбутньому. Таким чином, через деякий час після дослідження, ви можете побачити на полиці новий <br />\r\nпродукт, який допомогли створити виробнику.</p>','2010-01-12 21:35:35'),(42,'block_2_description_',2,'<p>Другою перевагою є те, що ми готові виплачувати Вам винагороду за ваші відповіді. <br />\r\nОтже, ви відчуєте, що висловлення своєї думки корисне не тільки &laquo;впрок&raquo;, але і на сьогоднішній день.</p>','block_2_description_2','','UA','2010-01-12 21:36:54','<p>Другою перевагою є те, що ми готові виплачувати Вам винагороду за ваші відповіді. <br />\r\nОтже, ви відчуєте, що висловлення своєї думки корисне не тільки &laquo;впрок&raquo;, але і на сьогоднішній день.</p>','2010-01-12 21:36:54'),(42,'block_2_title',0,'Чому саме TNS Opros','block_2_title','','UA','2010-03-30 11:26:31','Чому саме TNS Opros','2010-03-30 11:26:31'),(42,'block_3_description',0,'<p class=\"content_simple_text\">Участь потребує мінімум часу, для відповіді на запитання. Потрібно <br />\r\nлише прочитати формулювання питання та вибрати відповідний <br />\r\nваріант відповіді.</p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\">Ми поважаємо Ваші інтереси, тому вам не знадобиться давати <br />\r\nвідповіді на тематику, що вас не цікавить. Ви самі вибираєте у яких <br />\r\nдослідженнях брати участь.</p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\">І нарешті останнє: відсутність будь-якої реклами. Ми не проводимо <br />\r\nрекламних кампаній на нашому сайті, а отже, Вам ніяким чином не <br />\r\nбудуть нав&rsquo;язувати ніякі продукти. Навпаки &ndash; нам цікаво які продукти ви<br />\r\nобираєте за своїм бажанням і чому.</p>','block_3_description','','UA','2010-01-12 21:51:40','<p class=\"content_simple_text\">Участь потребує мінімум часу, для відповіді на запитання. Потрібно <br />\r\nлише прочитати формулювання питання та вибрати відповідний <br />\r\nваріант відповіді.</p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\">Ми поважаємо Ваші інтереси, тому вам не знадобиться давати <br />\r\nвідповіді на тематику, що вас не цікавить. Ви самі вибираєте у яких <br />\r\nдослідженнях брати участь.</p>\r\n<p class=\"content_simple_text\">&nbsp;</p>\r\n<p class=\"content_simple_text\">І нарешті останнє: відсутність будь-якої реклами. Ми не проводимо <br />\r\nрекламних кампаній на нашому сайті, а отже, Вам ніяким чином не <br />\r\nбудуть нав&rsquo;язувати ніякі продукти. Навпаки &ndash; нам цікаво які продукти ви<br />\r\nобираєте за своїм бажанням і чому.</p>','2010-01-12 21:51:40'),(42,'block_3_title',0,'Ще декілька цікавих фактів про TNS Opros','block_3_title','','UA','2010-03-30 11:27:22','Ще декілька цікавих фактів про TNS Opros','2010-03-30 11:27:22'),(42,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-12 21:26:08'),(42,'int_b_1_class',0,'CDE8F3','int_b_1_class','','UA','2010-01-12 21:27:40','CDE8F3','2010-01-12 21:27:40'),(42,'int_b_2_class',0,'CDE8F3_2','int_b_2_class','','UA','2010-01-12 21:31:24','CDE8F3_2','2010-01-12 21:31:24'),(42,'int_b_3_class',0,'CDE8F3','int_b_3_class','','UA','2010-01-12 21:55:28','CDE8F3','2010-01-12 21:55:28'),(42,'int_h_1_class',0,'0086D3','int_h_1_class','','UA','2010-01-12 21:26:47','0086D3','2010-01-12 21:26:47'),(42,'int_h_2_class',0,'0086D3','int_h_2_class','','UA','2010-01-12 21:30:05','0086D3','2010-01-12 21:30:05'),(42,'int_h_3_class',0,'0086D3','int_h_3_class','','UA','2010-01-12 21:30:38','0086D3','2010-01-12 21:30:38'),(42,'media_inserted_advantages',0,'a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"84\";}','Media id for object advantages on page 42',NULL,'','2010-01-12 21:29:15','a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"84\";}','2010-01-12 21:29:15'),(42,'media_title_advantages',0,'','Media id for object advantages on page 42',NULL,'UA','2010-01-12 21:29:15','','2010-01-12 21:29:15'),(42,'page_comment',0,'TNS в Україні вийшла на ринок онлайн досліджень. Бути з нами означає отримувати найкраще. Проект “36.6” якісно змінить ваше життя та ставлення до продуктів та послуг.','page_comment','','UA','2010-01-12 21:56:28','TNS в Україні вийшла на ринок онлайн досліджень. Бути з нами означає отримувати найкраще. Проект “36.6” якісно змінить ваше життя та ставлення до продуктів та послуг.','2010-01-12 21:56:28'),(45,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-19 06:41:02'),(45,'empty_row',0,'<p>Наразі немає доступних досліджень.</p>','empty_row','','UA','2010-03-29 18:00:52','<p>Наразі немає доступних досліджень.</p>','2010-03-29 18:00:52'),(45,'int_b_class',0,NULL,'int_b_class',NULL,'EN','2010-01-19 11:33:47',NULL,'2010-01-19 11:33:47'),(45,'int_b_class',0,'','int_b_class','','UA','2010-01-19 11:34:39','','2010-01-19 11:34:39'),(45,'page_comment',0,'Нижче наведено перелік досліджень, у яких ви можете взяти \r\nучасть.','page_comment','','UA','2010-03-29 18:00:41','Нижче наведено перелік досліджень, у яких ви можете взяти \r\nучасть.','2010-03-29 18:00:41'),(46,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-14 16:02:00'),(46,'internal_page_content',0,'<h1>Загальні положення</h1>\r\n<p>&nbsp;</p>\r\n<p class=\"content_simple_text\">Ці правила є обов&rsquo;язковими для усіх учасників співтовариства &laquo;36.6&raquo;. До порушників будуть застосовуватись адекватні міри покарань, включаючи припинення участі у співтоваристві.<br />\r\nАдміністрація залишає за собою право заблокувати вам доступ до ресурсу без пояснення причин. Якщо ви будете вважати ці дії неправомірними стосовно себе, то ви маєте право вимагати пояснення цих причин. <br />\r\nНезнання правил не звільняє від відповідальності за їх порушення. Незрозумілі моменти Ви завжди можете уточнити у адміністрації.<br />\r\nЗареєструвавшись, Ви підтверджуєте, що згодні з цими Правилами, берете на себе обов&rsquo;язки їх виконувати та несете повну персональну відповідальність за їх порушення.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<h1>Правила</h1>\r\n<ol class=\"content_simple_text\">\r\n    <li>Кожен громадянин або особа, що постійно проживає на території України має право участі у даному співтоваристві.</li>\r\n    <li>Особа, що реєструється, зобов&rsquo;язується вказувати про себе лише правдиві дані, а також у подальшому редагувати свій профайл при зміні будь-яких особистих даних, що були вказані при реєстрації.</li>\r\n    <li>Учасник співтовариства зобов&rsquo;язується не передавати свої логін та пароль іншим особам.</li>\r\n    <li>Учасник співтовариства зобов&rsquo;язується слідувати інструкціям до питань та чесно відповідати на питання в дослідженнях.</li>\r\n    <li>Учасник співтовариства має право накопичувати та використовувати бали відповідно до системи заохочення співтовариства.</li>\r\n    <li>У разі виявлення фальсифікації дослідження, адміністрація має право заблокувати доступ учасника до ресурсу.</li>\r\n</ol>\r\n<p>&nbsp;</p>','internal_page_content','','UA','2010-01-30 20:33:46','<h1>Загальні положення</h1>\r\n<p>&nbsp;</p>\r\n<p class=\"content_simple_text\">Ці правила є обов&rsquo;язковими для усіх учасників співтовариства &laquo;36.6&raquo;. До порушників будуть застосовуватись адекватні міри покарань, включаючи припинення участі у співтоваристві.<br />\r\nАдміністрація залишає за собою право заблокувати вам доступ до ресурсу без пояснення причин. Якщо ви будете вважати ці дії неправомірними стосовно себе, то ви маєте право вимагати пояснення цих причин. <br />\r\nНезнання правил не звільняє від відповідальності за їх порушення. Незрозумілі моменти Ви завжди можете уточнити у адміністрації.<br />\r\nЗареєструвавшись, Ви підтверджуєте, що згодні з цими Правилами, берете на себе обов&rsquo;язки їх виконувати та несете повну персональну відповідальність за їх порушення.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<h1>Правила</h1>\r\n<ol class=\"content_simple_text\">\r\n    <li>Кожен громадянин або особа, що постійно проживає на території України має право участі у даному співтоваристві.</li>\r\n    <li>Особа, що реєструється, зобов&rsquo;язується вказувати про себе лише правдиві дані, а також у подальшому редагувати свій профайл при зміні будь-яких особистих даних, що були вказані при реєстрації.</li>\r\n    <li>Учасник співтовариства зобов&rsquo;язується не передавати свої логін та пароль іншим особам.</li>\r\n    <li>Учасник співтовариства зобов&rsquo;язується слідувати інструкціям до питань та чесно відповідати на питання в дослідженнях.</li>\r\n    <li>Учасник співтовариства має право накопичувати та використовувати бали відповідно до системи заохочення співтовариства.</li>\r\n    <li>У разі виявлення фальсифікації дослідження, адміністрація має право заблокувати доступ учасника до ресурсу.</li>\r\n</ol>\r\n<p>&nbsp;</p>','2010-01-30 20:33:46'),(47,'contact_block_content',0,'<p><img height=\"44\" align=\"left\" width=\"45\" vspace=\"4\" src=\"/usersimage/Image/person.PNG\" alt=\"\" /></p>\r\n<p class=\"pink_15_lm\">Віктор Божко</p>\r\n<p class=\"content_simple_text_lm\">м. Київ вул. Ігорівська 1/8 літера &ldquo;В&rdquo;</p>\r\n<p class=\"content_simple_text_lm\">044 201 10 15</p>\r\n<p><a href=\"mailto:viktor.bozhko@tns-ua.com?subject=Question\" class=\"system_button2\">Надіслати повідомлення</a></p>','contact_block_content','','UA','2010-02-01 15:32:31','<p><img height=\"44\" align=\"left\" width=\"45\" vspace=\"4\" src=\"/usersimage/Image/person.PNG\" alt=\"\" /></p>\r\n<p class=\"pink_15_lm\">Віктор Божко</p>\r\n<p class=\"content_simple_text_lm\">м. Київ вул. Ігорівська 1/8 літера &ldquo;В&rdquo;</p>\r\n<p class=\"content_simple_text_lm\">044 201 10 15</p>\r\n<p><a href=\"mailto:viktor.bozhko@tns-ua.com?subject=Question\" class=\"system_button2\">Надіслати повідомлення</a></p>','2010-02-01 15:32:31'),(47,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2009-12-04 16:40:13'),(47,'email_body',0,'Шановний {first_name} {last_name}!\r\n\r\nДля завершення реєстрації відкрийте сторінку {link} та введіть свій пароль.\r\nПісля цього Ви отримаєте наступний лист із нагадуванням даних для авторизцаії та відразу ж зможете взяти участь в опитуванні.\r\n\r\nЗ найкращими побажаннями,\r\nАдміністрація TNS Opros.','email_body','','UA','2010-02-25 18:42:09','Шановний {first_name} {last_name}!\r\n\r\nДля завершення реєстрації відкрийте сторінку {link} та введіть свій пароль.\r\nПісля цього Ви отримаєте наступний лист із нагадуванням даних для авторизцаії та відразу ж зможете взяти участь в опитуванні.\r\n\r\nЗ найкращими побажаннями,\r\nАдміністрація TNS Opros.','2010-02-25 18:42:09'),(47,'email_subject',0,'Registration on TNS Opros','email_subject','','UA','2010-02-19 19:25:30','Registration on TNS Opros','2010-02-19 19:25:30'),(47,'int_b_class',0,NULL,'int_b_class',NULL,'UA','2010-02-24 12:00:50',NULL,'2010-02-24 12:00:50'),(47,'int_h_class',0,'','int_h_class','','UA','2010-03-30 11:22:23','','2010-03-30 11:22:23'),(47,'media_inserted_registration_form',0,'a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"84\";}','Media id for object registration_form on page 47',NULL,'','2010-01-14 16:28:36','a:2:{s:4:\"link\";a:2:{s:4:\"type\";s:9:\"open_none\";s:8:\"opentype\";s:4:\"self\";}s:8:\"media_id\";s:2:\"84\";}','2010-01-14 16:28:36'),(47,'media_title_registration_form',0,'','Media id for object registration_form on page 47',NULL,'UA','2010-01-14 16:28:36','','2010-01-14 16:28:36'),(47,'page_comment',0,'Будь-ласка, заповніть реєстраційний бланк. Усі поля є \r\nобов’язковими, окрім телефонів - повинен бути заповнений \r\nодин з них. \r\nВаш <b>e-mail</b> буде використано як логін для авторизації.','page_comment','','UA','2010-03-30 12:37:17','Будь-ласка, заповніть реєстраційний бланк. Усі поля є \r\nобов’язковими, окрім телефонів - повинен бути заповнений \r\nодин з них. \r\nВаш <b>e-mail</b> буде використано як логін для авторизації.','2010-03-30 12:37:17'),(47,'page_error',0,'При заповненні форми були допущені помилки.\r\n<br/>\r\nБудь-ласка, перевірте введені дані ще раз.','page_error','','UA','2009-12-08 08:58:01','При заповненні форми були допущені помилки.\r\n<br/>\r\nБудь-ласка, перевірте введені дані ще раз.','2009-12-08 08:58:01'),(47,'page_header',0,'Форма реєстрації','page_header','','UA','2009-12-08 08:29:35','Форма реєстрації','2009-12-08 08:29:35'),(47,'right_block_b_class_contact',0,NULL,'right_block_b_class_contact',NULL,'UA','2010-01-18 17:05:57',NULL,'2010-01-18 17:05:57'),(47,'right_block_h_class_contact',0,'','right_block_h_class_contact','','UA','2010-01-19 08:26:32','','2010-01-19 08:26:32'),(48,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-09 18:45:43'),(48,'int_h_class',0,NULL,'int_h_class',NULL,'UA','2010-01-09 18:45:43',NULL,'2010-01-09 18:45:43'),(51,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-18 16:15:37'),(51,'internal_page_content',0,'<p>На питання</p>\r\n<strong><em>&laquo;Що Ви хочете отримати в подарунок до Нового року?&raquo;</em></strong>\r\n<p>українці відповіли таким чином:</p>\r\n<table>\r\n    \r\n        <tr>\r\n            <td>\r\n            <p>Щось корисне&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n            </td>\r\n            <td valign=\"bottom\">\r\n            <p align=\"center\">40%</p>\r\n            </td>\r\n        </tr>\r\n        <tr>\r\n            <td>\r\n            <p>Щось корисне</p>\r\n            </td>\r\n            <td valign=\"bottom\">\r\n            <p align=\"center\">40%</p>\r\n            </td>\r\n        </tr>\r\n    \r\n</table>\r\n<p>При цьому трохи менше половини українців (47,6%</p>','internal_page_content','','UA','2010-01-26 17:09:25','<p>На питання</p>\r\n<strong><em>&laquo;Що Ви хочете отримати в подарунок до Нового року?&raquo;</em></strong>\r\n<p>українці відповіли таким чином:</p>\r\n<table>\r\n    \r\n        <tr>\r\n            <td>\r\n            <p>Щось корисне&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n            </td>\r\n            <td valign=\"bottom\">\r\n            <p align=\"center\">40%</p>\r\n            </td>\r\n        </tr>\r\n        <tr>\r\n            <td>\r\n            <p>Щось корисне</p>\r\n            </td>\r\n            <td valign=\"bottom\">\r\n            <p align=\"center\">40%</p>\r\n            </td>\r\n        </tr>\r\n    \r\n</table>\r\n<p>При цьому трохи менше половини українців (47,6%</p>','2010-01-26 17:09:25'),(51,'internal_page_header',0,'Результати останніх досліджень','internal_page_header','','UA','2010-01-18 16:20:07','Результати останніх досліджень','2010-01-18 16:20:07'),(51,'int_b_class',0,'E3E2EE','int_b_class','','UA','2010-01-29 15:53:49','E3E2EE','2010-01-29 15:53:49'),(51,'int_h_class',0,'8A81BA','int_h_class','','UA','2010-01-29 15:53:01','8A81BA','2010-01-29 15:53:01'),(51,'page_comment',0,'Деякі найцікавіші результати наших досліджень ми для зручності користування розміщуємо прямо на сайті.','page_comment','','UA','2010-01-29 15:51:47','Деякі найцікавіші результати наших досліджень ми для зручності користування розміщуємо прямо на сайті.','2010-01-29 15:51:47'),(51,'page_header',0,NULL,'page_header',NULL,'EN','2010-01-18 16:16:08',NULL,'2010-01-18 16:16:08'),(51,'page_header',0,'Результати досліджень','page_header','','UA','2010-01-18 16:16:29','Результати досліджень','2010-01-18 16:16:29'),(52,'contact_block_content',0,'<p><img height=\"44\" align=\"left\" width=\"45\" vspace=\"4\" alt=\"\" src=\"/usersimage/Image/person.PNG\" /></p>\r\n<p class=\"pink_15_lm\">Віктор Божко</p>\r\n<p class=\"content_simple_text_lm\">м. Київ вул. Ігорівська 1/8 літера &ldquo;В&rdquo;</p>\r\n<p class=\"content_simple_text_lm\">044 201 10 15</p>\r\n<p><a class=\"system_button2\" href=\"mailto:viktor.bozhko@tns-ua.com?subject=Question\">Надіслати повідомлення</a></p>','contact_block_content','','UA','2010-02-01 15:34:21','<p><img height=\"44\" align=\"left\" width=\"45\" vspace=\"4\" alt=\"\" src=\"/usersimage/Image/person.PNG\" /></p>\r\n<p class=\"pink_15_lm\">Віктор Божко</p>\r\n<p class=\"content_simple_text_lm\">м. Київ вул. Ігорівська 1/8 літера &ldquo;В&rdquo;</p>\r\n<p class=\"content_simple_text_lm\">044 201 10 15</p>\r\n<p><a class=\"system_button2\" href=\"mailto:viktor.bozhko@tns-ua.com?subject=Question\">Надіслати повідомлення</a></p>','2010-02-01 15:34:21'),(52,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2009-12-25 15:13:48'),(52,'internal_page_content',0,'<p>Основа даної системи &ndash; курс: 100 балів = 1грн.</p>\r\n<p>&nbsp;</p>\r\n<p>В середньому ви будете отримувати від 600 до 1500 балів за опитування, хоча є винятки, що будуть коштувати набагато дорожче.</p>\r\n<p>&nbsp;</p>\r\n<p>Більше того, кожне дослідження буде завершуватися розіграшем <br />\r\nцінних призів.</p>','internal_page_content','','UA','2010-01-19 12:23:11','<p>Основа даної системи &ndash; курс: 100 балів = 1грн.</p>\r\n<p>&nbsp;</p>\r\n<p>В середньому ви будете отримувати від 600 до 1500 балів за опитування, хоча є винятки, що будуть коштувати набагато дорожче.</p>\r\n<p>&nbsp;</p>\r\n<p>Більше того, кожне дослідження буде завершуватися розіграшем <br />\r\nцінних призів.</p>','2010-01-19 12:23:11'),(52,'internal_page_header',0,'Основа','internal_page_header','','UA','2010-01-09 18:38:24','Основа','2010-01-09 18:38:24'),(52,'int_b_class',0,'D0D0D0','int_b_class','','UA','2010-01-09 18:15:03','D0D0D0','2010-01-09 18:15:03'),(52,'int_h_class',0,'8495AE','int_h_class','','UA','2010-01-09 17:57:26','8495AE','2010-01-09 17:57:26'),(52,'page_comment',0,'Беручи участь у наших дослідженнях, Ви накопичуєте бали, що пізніше зможете конвертувати у гроші.','page_comment','','UA','2010-01-09 18:35:40','Беручи участь у наших дослідженнях, Ви накопичуєте бали, що пізніше зможете конвертувати у гроші.','2010-01-09 18:35:40'),(52,'page_header',0,'','page_header','','UA','2009-12-25 15:14:05','','2009-12-25 15:14:05'),(55,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-09 19:00:56'),(55,'internal_page_content',0,'<p>Головна мета і місія 36.6 &ndash; надати споживачам можливість донести <br />\r\nсвою думку до виробника.</p>\r\n<p>&nbsp;</p>\r\n<p>Висловлюючи свою думку засобами 36.6, Ви отримаєте можливість <br />\r\nвпливати на навколишній світ, зробите його більш приємним, зручним <br />\r\nта затишним для себе. Ваша думка може вплинути на глобальні <br />\r\nпринципи світових лідерів &ndash; виробників товарів та послуг.</p>\r\n<p>&nbsp;</p>\r\n<p>Ми прагнемо до досконалості. І Ви &ndash; з нами!</p>','internal_page_content','','UA','2010-01-19 10:08:48','<p>Головна мета і місія 36.6 &ndash; надати споживачам можливість донести <br />\r\nсвою думку до виробника.</p>\r\n<p>&nbsp;</p>\r\n<p>Висловлюючи свою думку засобами 36.6, Ви отримаєте можливість <br />\r\nвпливати на навколишній світ, зробите його більш приємним, зручним <br />\r\nта затишним для себе. Ваша думка може вплинути на глобальні <br />\r\nпринципи світових лідерів &ndash; виробників товарів та послуг.</p>\r\n<p>&nbsp;</p>\r\n<p>Ми прагнемо до досконалості. І Ви &ndash; з нами!</p>','2010-01-19 10:08:48'),(55,'internal_page_header',0,'Що ми робимо','internal_page_header','','UA','2010-01-09 19:02:00','Що ми робимо','2010-01-09 19:02:00'),(55,'int_b_class',0,'CDE8F3','int_b_class','','UA','2010-01-09 19:01:29','CDE8F3','2010-01-09 19:01:29'),(55,'int_h_class',0,'0086D3','int_h_class','','UA','2010-01-09 19:01:02','0086D3','2010-01-09 19:01:02'),(55,'page_comment',0,'TNS в Україні вийшла на ринок онлайн досліджень. Бути з нами означає отримувати найкраще. Проект “36.6” якісно змінить ваше життя та ставлення до продуктів та послуг.','page_comment','','UA','2010-01-09 19:03:39','TNS в Україні вийшла на ринок онлайн досліджень. Бути з нами означає отримувати найкраще. Проект “36.6” якісно змінить ваше життя та ставлення до продуктів та послуг.','2010-01-09 19:03:39'),(57,'contact_block_content',0,'<p><img height=\"50\" width=\"50\" vspace=\"4\" align=\"left\" src=\"/usersimage/Image/face.png\" alt=\"\" /></p>\r\n<p class=\"pink_15_lm\">Віктор Божко</p>\r\n<p class=\"content_simple_text_lm\">м. Київ вул. Ігорівська 1/8 літера &ldquo;В&rdquo;</p>\r\n<p class=\"content_simple_text_lm\">044 201 10 15</p>\r\n<p><a class=\"system_button2\" href=\"mailto:viktor.bozhko@tns-ua.com?subject=Question\">Надіслати повідомлення</a></p>','contact_block_content','','UA','2010-01-29 15:33:22','<p><img height=\"50\" width=\"50\" vspace=\"4\" align=\"left\" src=\"/usersimage/Image/face.png\" alt=\"\" /></p>\r\n<p class=\"pink_15_lm\">Віктор Божко</p>\r\n<p class=\"content_simple_text_lm\">м. Київ вул. Ігорівська 1/8 літера &ldquo;В&rdquo;</p>\r\n<p class=\"content_simple_text_lm\">044 201 10 15</p>\r\n<p><a class=\"system_button2\" href=\"mailto:viktor.bozhko@tns-ua.com?subject=Question\">Надіслати повідомлення</a></p>','2010-01-29 15:33:22'),(57,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2009-12-13 19:51:26'),(57,'email_body',0,'Шановний {first_name} {last_name}!\r\nЩоб ввести новий пароль замість втраченого - скористайтесь формою на сторінці {link}.','email_body','','UA','2010-02-19 19:28:46','Шановний {first_name} {last_name}!\r\nЩоб ввести новий пароль замість втраченого - скористайтесь формою на сторінці {link}.','2010-02-19 19:28:46'),(57,'email_subject',0,'Password reset on TNS Opros','email_subject','','UA','2010-02-19 19:30:14','Password reset on TNS Opros','2010-02-19 19:30:14'),(57,'page_comment',0,'Будь-ласка, введіть e-mail, який ви використовували при \r\nреєстрації. На вашу поштову скриньку буде відправлено\r\nлиста з новим паролем.','page_comment','','UA','2009-12-13 19:52:17','Будь-ласка, введіть e-mail, який ви використовували при \r\nреєстрації. На вашу поштову скриньку буде відправлено\r\nлиста з новим паролем.','2009-12-13 19:52:17'),(57,'page_error',0,'Користувача з таким e-mail не існує або при заповненні форми \r\nбули допущені помилки.\r\nБудь-ласка, перевірте введені дані ще раз.','page_error','','UA','2009-12-13 19:56:09','Користувача з таким e-mail не існує або при заповненні форми \r\nбули допущені помилки.\r\nБудь-ласка, перевірте введені дані ще раз.','2009-12-13 19:56:09'),(57,'page_header',0,'Забули пароль?','page_header','','UA','2009-12-13 19:53:40','Забули пароль?','2009-12-13 19:53:40'),(59,'contact_block_content',0,'<p class=\"pink_15_lm\">Lorem ipsum.</p>\r\n<p class=\"content_simple_text_lm\">Dolor sit amet.</p>','contact_block_content','','UA','2010-01-14 11:57:49','<p class=\"pink_15_lm\">Lorem ipsum.</p>\r\n<p class=\"content_simple_text_lm\">Dolor sit amet.</p>','2010-01-14 11:57:49'),(59,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2009-12-11 10:39:18'),(59,'email_body',0,'Шановний {first_name} {last_name}!\r\nВи завершили реєстрацію на сайті {HTTP}.\r\n\r\nВаш логін: {login}\r\n\r\nДля запобігання втрати паролю, він не висилається Вам у відкритому вигляді. Якщо Ви забули пароль, то, будь ласка, скористайтесь формою відновлення паролю: {link}\r\n\r\nКількість балів на вашому рахунку Ви можете перевірити за адресою: {HTTP}UA/survey-history.html\r\n\r\nБажаємо успішних опитувань!\r\n\r\nЗ найкращими побажаннями,\r\nАдміністрація TNS Opros.','email_body','','UA','2010-03-10 11:41:08','Шановний {first_name} {last_name}!\r\nВи завершили реєстрацію на сайті {HTTP}.\r\n\r\nВаш логін: {login}\r\n\r\nДля запобігання втрати паролю, він не висилається Вам у відкритому вигляді. Якщо Ви забули пароль, то, будь ласка, скористайтесь формою відновлення паролю: {link}\r\n\r\nКількість балів на вашому рахунку Ви можете перевірити за адресою: {HTTP}UA/survey-history.html\r\n\r\nБажаємо успішних опитувань!\r\n\r\nЗ найкращими побажаннями,\r\nАдміністрація TNS Opros.','2010-03-10 11:41:08'),(59,'email_subject',0,'Account on TNS Opros','email_subject','','UA','2010-02-25 19:19:14','Account on TNS Opros','2010-02-25 19:19:14'),(59,'page_comment',0,'Будь-ласка, введіть пароль до вашого профайлу на сайті. \r\nЗверніть увагу, що пароль треба ввести двічі. Використовуйте латинські літери.\r\nПароль має містити хоча б одну велику літеру, хоча б одну маленьку літеру, хоча б одну цифру та бути завдовжки не менше, ніж 8 символів.','page_comment','','UA','2010-02-26 08:43:59','Будь-ласка, введіть пароль до вашого профайлу на сайті. \r\nЗверніть увагу, що пароль треба ввести двічі. Використовуйте латинські літери.\r\nПароль має містити хоча б одну велику літеру, хоча б одну маленьку літеру, хоча б одну цифру та бути завдовжки не менше, ніж 8 символів.','2010-02-26 08:43:59'),(59,'page_error',0,'Під час заповнення форми були допущені помилки.<br/>\r\nБудь ласка, перевірте введені дані ще раз.<br/>','page_error','','UA','2010-01-28 08:46:16','Під час заповнення форми були допущені помилки.<br/>\r\nБудь ласка, перевірте введені дані ще раз.<br/>','2010-01-28 08:46:16'),(59,'page_header',0,'Форма підтвердження реєстрації','page_header','','UA','2009-12-11 11:22:28','Форма підтвердження реєстрації','2009-12-11 11:22:28'),(60,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-28 17:00:36'),(60,'email_body',0,'Ваш пароль було успішно змінено.\r\nДякуємо за користування сервісом!\r\n\r\nЗ повагою, \r\nкоманда TNS Opros!','email_body','','UA','2010-04-01 14:51:10','Ваш пароль було успішно змінено.\r\nДякуємо за користування сервісом!\r\n\r\nЗ повагою, \r\nкоманда TNS Opros!','2010-04-01 14:51:10'),(60,'email_subject',0,'New password on TNS Opros','email_subject','','UA','2010-04-01 14:49:01','New password on TNS Opros','2010-04-01 14:49:01'),(60,'page_comment',0,NULL,'page_comment',NULL,'UA','2010-02-24 16:22:17',NULL,'2010-02-24 16:22:17'),(60,'page_error',0,'При заповненні форми були допущені помилки.<br />\r\nБудь ласка, спробуйте заповнити форму ще раз.','page_error','','UA','2010-01-28 17:01:24','При заповненні форми були допущені помилки.<br />\r\nБудь ласка, спробуйте заповнити форму ще раз.','2010-01-28 17:01:24'),(60,'page_header',0,'Відновлення паролю','page_header','','UA','2010-02-24 16:23:04','Відновлення паролю','2010-02-24 16:23:04'),(61,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2009-12-10 16:06:24'),(61,'internal_page_content',0,'<p>Вітаємо!</p>\r\n<p>Ви зареєстровані.</p>\r\n<p>Перевірте свою електронну пошту щоб отримати подальші інструкції.</p>','internal_page_content','','UA','2009-12-10 16:07:45','<p>Вітаємо!</p>\r\n<p>Ви зареєстровані.</p>\r\n<p>Перевірте свою електронну пошту щоб отримати подальші інструкції.</p>','2009-12-10 16:07:45'),(62,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2009-12-11 10:41:33'),(62,'internal_page_content',0,'<p><span id=\"bread_crumb_page_name\">Вітаємо!</span></p>\r\n<p><span id=\"bread_crumb_page_name\">Реєстрацію завершено остаточно, пароль збережено.</span></p>','internal_page_content','','UA','2009-12-11 10:41:54','<p><span id=\"bread_crumb_page_name\">Вітаємо!</span></p>\r\n<p><span id=\"bread_crumb_page_name\">Реєстрацію завершено остаточно, пароль збережено.</span></p>','2009-12-11 10:41:54'),(62,'page_comment',0,'','page_comment','','UA','2009-12-11 11:19:40','','2009-12-11 11:19:40'),(62,'page_header',0,'Форма підтвердження реєстрації','page_header','','UA','2009-12-11 10:55:34','Форма підтвердження реєстрації','2009-12-11 10:55:34'),(63,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2009-12-11 14:52:29'),(63,'internal_page_content',0,'<p>Нажаль, такої сторінки не існує. Якщо ви скористалися збереженим <br />\r\nраніше посиланням або меню Favourites, то, скоріше за все, сторінка <br />\r\nзмінила адресу і Вам неохідно оновити посилання.</p>\r\n<p>Також перевірте, будь-ласка, написання посилання на наявність <br />\r\nпомилок, описок та зайвих пробілів.</p>\r\n<p>Ви завжди можете скористатись <a href=\"/index.php?t=34&amp;language=UA\">мапою сайту</a>.</p>','internal_page_content','','UA','2009-12-11 14:53:36','<p>Нажаль, такої сторінки не існує. Якщо ви скористалися збереженим <br />\r\nраніше посиланням або меню Favourites, то, скоріше за все, сторінка <br />\r\nзмінила адресу і Вам неохідно оновити посилання.</p>\r\n<p>Також перевірте, будь-ласка, написання посилання на наявність <br />\r\nпомилок, описок та зайвих пробілів.</p>\r\n<p>Ви завжди можете скористатись <a href=\"/index.php?t=34&amp;language=UA\">мапою сайту</a>.</p>','2009-12-11 14:53:36'),(63,'page_header',0,'Такої сторінки не існує','page_header','','UA','2009-12-11 14:54:28','Такої сторінки не існує','2009-12-11 14:54:28'),(67,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2009-12-29 21:57:46'),(67,'internal_page_content',0,'<p>Сторінка, яку ви намагались відкрити, доступна лише для авторизованих користувачив.</p>\r\n<p>Скористайтесь <a href=\"/index.php?t=68&amp;language=UA\">формою авторизації</a> або <a href=\"/index.php?t=47&amp;language=UA\">зареєструйтесь</a>, якщо не зробили цього раніше.</p>','internal_page_content','','UA','2010-01-30 08:50:37','<p>Сторінка, яку ви намагались відкрити, доступна лише для авторизованих користувачив.</p>\r\n<p>Скористайтесь <a href=\"/index.php?t=68&amp;language=UA\">формою авторизації</a> або <a href=\"/index.php?t=47&amp;language=UA\">зареєструйтесь</a>, якщо не зробили цього раніше.</p>','2010-01-30 08:50:37'),(67,'page_comment',0,'','page_comment','','UA','2010-01-30 08:49:35','','2010-01-30 08:49:35'),(68,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-05 23:48:41'),(68,'page_comment',0,'Будь-ласка, введіть свій логін(e-mail) та пароль у форму нижче.','page_comment','','UA','2010-01-29 15:34:14','Будь-ласка, введіть свій логін(e-mail) та пароль у форму нижче.','2010-01-29 15:34:14'),(68,'page_error',0,'Користувача з таким логіном та паролем не існує або при заповненні \r\nформи були допущені помилки.\r\n\r\nБудь-ласка, перевірте введені дані ще раз.','page_error','','UA','2010-01-05 23:50:18','Користувача з таким логіном та паролем не існує або при заповненні \r\nформи були допущені помилки.\r\n\r\nБудь-ласка, перевірте введені дані ще раз.','2010-01-05 23:50:18'),(86,'contact_block_content',0,NULL,'contact_block_content',NULL,'EN','2010-01-29 17:48:18',NULL,'2010-01-29 17:48:18'),(86,'contact_block_content',0,'<p><img height=\"44\" align=\"left\" width=\"45\" vspace=\"4\" alt=\"\" src=\"/usersimage/Image/person.PNG\" /></p>\r\n<p class=\"pink_15_lm\">Служба підтримки</p>\r\n<p class=\"content_simple_text_lm\">&nbsp;</p>\r\n<p class=\"content_simple_text_lm\">&nbsp;</p>\r\n<p><a class=\"system_button2\" href=\"mailto:accesspanel.helpdesk@tns-ua.com?subject=Question\">Надіслати повідомлення</a></p>','contact_block_content','','UA','2010-02-01 15:35:37','<p><img height=\"44\" align=\"left\" width=\"45\" vspace=\"4\" alt=\"\" src=\"/usersimage/Image/person.PNG\" /></p>\r\n<p class=\"pink_15_lm\">Служба підтримки</p>\r\n<p class=\"content_simple_text_lm\">&nbsp;</p>\r\n<p class=\"content_simple_text_lm\">&nbsp;</p>\r\n<p><a class=\"system_button2\" href=\"mailto:accesspanel.helpdesk@tns-ua.com?subject=Question\">Надіслати повідомлення</a></p>','2010-02-01 15:35:37'),(86,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-18 16:25:10'),(86,'internal_page_content',0,NULL,'internal_page_content','','EN','2010-01-26 17:36:43',NULL,'2010-01-26 17:36:43'),(86,'internal_page_content',0,'<p><a class=\"faq_question\" href=\"#part1\">Як взяти участь у дослідженні?</a><br />\r\n<a class=\"faq_question\" href=\"#part2\">Для чого потрібен мій e-mail?</a><br />\r\n<a class=\"faq_question\" href=\"#part3\">Питання конфіденційності особистих даних.</a><br />\r\n<a class=\"faq_question\" href=\"#part4\">Що таке маркетингові дослідження?</a><br />\r\n<a class=\"faq_question\" href=\"#part5\">Що таке аксес-панель?</a><br />\r\n<a class=\"faq_question\" href=\"#part6\">Чому я не можу сконвертувати свої бали?</a><br />\r\n<a class=\"faq_question\" href=\"#part7\">Чому список поточних проектів пустий?</a><br />\r\n<a class=\"faq_question\" href=\"#part8\">Як я можу дізнатися про операції, що проводилися з моїми балами?</a></p>\r\n<p>&nbsp;</p>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part1\">Як взяти участь у дослідженні?</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Для того, щоб взяти участь у дослідженні Вам необхідно спочатку зареєструватися у співтоваристві(при цьому необхідно буде вказати деяку інформацію про Вас та Вашу e-mail адресу). Після цього потрібно перейти на сторінку <a href=\"/index.php?t=45&amp;language=UA\">Поточні проекти</a> та оберіть тематику дослідження за своїм смаком. Після завершення анкетування Ви будете перенаправлені на сторінку <a href=\"/index.php?t=30&amp;language=UA\">Історія опитувань</a>, де буде вказано скільки балів Ви заробили за пройдене дослідження.</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part2\">Для чого потрібен мій e-mail?</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Ваш e-mail(електронна пошта) слугує логіном для авторизації на сайті, а також буде використаний для зв<span lang=\"EN-US\">&rsquo;</span>язку з Вами з будь-яких причин, що можуть виникнути впродовж вашої участі у співтоваристві. Наприклад, підтвердження реєстрації, відновлення паролю, запрошення до участі у дослідженні і т.і..</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part3\">Питання конфіденційності особистих даних.</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Усі ваші особисті дані збираються, передаються та зберігаються з у відповідності до найвищих вимог конфіденційності. Жодна третя особа(у тому числі інші учасники) не може заволодіти будь-якими даними, що Ви передаєте співтовариству. Сервери з даними охороняються у режимі 24*7 протягом усього року. Будь-ласка, не передавайте свої логін та пароль іншим особам, а також користуйтеся кнопкою &quot;Вихід&quot; для завершення роботи на сайті. Це забезпечить додатковий рівень безпеки Ваших особистих даних.</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part4\">Що таке маркетингові дослідження?</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Маркетингові дослідження &mdash; систематичне збирання, опрацьовування й аналіз інформації та можливостей, розроблення рекомендацій на підставі цих даних. Відомо, що добробут компаній виробників та постачальників послуг напряму залежить від задоволеності споживачем продукцією. Завдання маркетингового дослідження - визначити сторони невдоволеності споживача та шляхи подолання цієї невдоволенності. Як правило, вони також передбачають аналіз продажу та маркетингових можливостей, прогнозування продажу, ринкових кривих пропозиції та попиту. Результати маркетингових досліджень фірми використовують при плануванні та контролі діяльності.</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part5\">Що таке аксес-панель?</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Аксес-панель(англ. access panel) - співтовариство людей, що згодились на постійній основі брати участь у маркетингових дослідженнях певної компанії, що їх проводить. Реалізуються загалом у онлайн-секторі. Компанія TNS має великий світовий досвід побудови аксес-панелей по всьому світу.</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part6\">Чому я не можу сконвертувати свої бали?</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Для того, щоб отримати можливість конвертувати свої бали потрібно накопичити їх не менше ніж 1000. Якщо Ви накопичили достатню кількість балів, але все одно не можете їх сконвертувати, будь-ласка, напишіть у нашу Службу Підтримки. Ми якнашвидше дамо відповідь.</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part7\">Чому список поточних проектів пустий?</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Список проектів може бути пустий у декількох випадках:</div>\r\n<ol>\r\n    <li>Ви вже взяли участь у всіх поточних проектах;</li>\r\n    <li>На даний момент немає поточних проектів.</li>\r\n</ol>\r\n<br />\r\n<p>В будь-якому випадку список проектів ніколи не пустує протягом тривалого періоду. Заходьте частіше та переконаєтесь!</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part8\">Як я можу дізнатися про операції, що проводилися з моїми балами?</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Існує спеціальна сторінка&nbsp; <a href=\"/index.php?t=30&amp;language=UA\">Історія опитувань</a>, де у хронологічному порядку відображаються усі дії, що ви робили у співтоваристві. Операція використання балів для конвертації позначається особливим фоном, тому зразу буде помітною серед інших.</div>\r\n</div>\r\n</div>\r\n</div>','internal_page_content','<DIV class=int>\r\n<br/><DIV class=int_h>\r\n<br/><DIV class=int_h_text>Питання №1</DIV>\r\n<br/></DIV>\r\n<br/><DIV class=int_b>\r\n<br/><DIV class=int_b_content>\r\n<br/><DIV>Відповідь на питання №1</DIV>\r\n<br/></DIV>\r\n<br/></DIV>\r\n<br/></DIV>\r\n<br/>','UA','2010-02-24 11:37:46','<p><a class=\"faq_question\" href=\"#part1\">Як взяти участь у дослідженні?</a><br />\r\n<a class=\"faq_question\" href=\"#part2\">Для чого потрібен мій e-mail?</a><br />\r\n<a class=\"faq_question\" href=\"#part3\">Питання конфіденційності особистих даних.</a><br />\r\n<a class=\"faq_question\" href=\"#part4\">Що таке маркетингові дослідження?</a><br />\r\n<a class=\"faq_question\" href=\"#part5\">Що таке аксес-панель?</a><br />\r\n<a class=\"faq_question\" href=\"#part6\">Чому я не можу сконвертувати свої бали?</a><br />\r\n<a class=\"faq_question\" href=\"#part7\">Чому список поточних проектів пустий?</a><br />\r\n<a class=\"faq_question\" href=\"#part8\">Як я можу дізнатися про операції, що проводилися з моїми балами?</a></p>\r\n<p>&nbsp;</p>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part1\">Як взяти участь у дослідженні?</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Для того, щоб взяти участь у дослідженні Вам необхідно спочатку зареєструватися у співтоваристві(при цьому необхідно буде вказати деяку інформацію про Вас та Вашу e-mail адресу). Після цього потрібно перейти на сторінку <a href=\"/index.php?t=45&amp;language=UA\">Поточні проекти</a> та оберіть тематику дослідження за своїм смаком. Після завершення анкетування Ви будете перенаправлені на сторінку <a href=\"/index.php?t=30&amp;language=UA\">Історія опитувань</a>, де буде вказано скільки балів Ви заробили за пройдене дослідження.</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part2\">Для чого потрібен мій e-mail?</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Ваш e-mail(електронна пошта) слугує логіном для авторизації на сайті, а також буде використаний для зв<span lang=\"EN-US\">&rsquo;</span>язку з Вами з будь-яких причин, що можуть виникнути впродовж вашої участі у співтоваристві. Наприклад, підтвердження реєстрації, відновлення паролю, запрошення до участі у дослідженні і т.і..</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part3\">Питання конфіденційності особистих даних.</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Усі ваші особисті дані збираються, передаються та зберігаються з у відповідності до найвищих вимог конфіденційності. Жодна третя особа(у тому числі інші учасники) не може заволодіти будь-якими даними, що Ви передаєте співтовариству. Сервери з даними охороняються у режимі 24*7 протягом усього року. Будь-ласка, не передавайте свої логін та пароль іншим особам, а також користуйтеся кнопкою &quot;Вихід&quot; для завершення роботи на сайті. Це забезпечить додатковий рівень безпеки Ваших особистих даних.</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part4\">Що таке маркетингові дослідження?</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Маркетингові дослідження &mdash; систематичне збирання, опрацьовування й аналіз інформації та можливостей, розроблення рекомендацій на підставі цих даних. Відомо, що добробут компаній виробників та постачальників послуг напряму залежить від задоволеності споживачем продукцією. Завдання маркетингового дослідження - визначити сторони невдоволеності споживача та шляхи подолання цієї невдоволенності. Як правило, вони також передбачають аналіз продажу та маркетингових можливостей, прогнозування продажу, ринкових кривих пропозиції та попиту. Результати маркетингових досліджень фірми використовують при плануванні та контролі діяльності.</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part5\">Що таке аксес-панель?</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Аксес-панель(англ. access panel) - співтовариство людей, що згодились на постійній основі брати участь у маркетингових дослідженнях певної компанії, що їх проводить. Реалізуються загалом у онлайн-секторі. Компанія TNS має великий світовий досвід побудови аксес-панелей по всьому світу.</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part6\">Чому я не можу сконвертувати свої бали?</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Для того, щоб отримати можливість конвертувати свої бали потрібно накопичити їх не менше ніж 1000. Якщо Ви накопичили достатню кількість балів, але все одно не можете їх сконвертувати, будь-ласка, напишіть у нашу Службу Підтримки. Ми якнашвидше дамо відповідь.</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part7\">Чому список поточних проектів пустий?</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Список проектів може бути пустий у декількох випадках:</div>\r\n<ol>\r\n    <li>Ви вже взяли участь у всіх поточних проектах;</li>\r\n    <li>На даний момент немає поточних проектів.</li>\r\n</ol>\r\n<br />\r\n<p>В будь-якому випадку список проектів ніколи не пустує протягом тривалого періоду. Заходьте частіше та переконаєтесь!</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"int\">\r\n<div class=\"int_h\">\r\n<div class=\"int_h_text\"><a name=\"part8\">Як я можу дізнатися про операції, що проводилися з моїми балами?</a></div>\r\n</div>\r\n<div class=\"int_b\">\r\n<div class=\"int_b_content\">\r\n<div>Існує спеціальна сторінка&nbsp; <a href=\"/index.php?t=30&amp;language=UA\">Історія опитувань</a>, де у хронологічному порядку відображаються усі дії, що ви робили у співтоваристві. Операція використання балів для конвертації позначається особливим фоном, тому зразу буде помітною серед інших.</div>\r\n</div>\r\n</div>\r\n</div>','2010-02-24 11:37:46'),(86,'internal_page_header',0,'','Заглавие блока','','UA','2010-01-18 16:29:37','','2010-01-18 16:29:37'),(86,'int_b_class',0,'','Цвет footer блока. Может быть одно из значений: CDE8F3, D0D0D0, D0EAF4 или пустое значение','','UA','2010-01-18 16:29:11','','2010-01-18 16:29:11'),(86,'int_h_class',0,'','Цвет шапки блока. Возможные значения: 0086D3, 8495AE или пустое','','UA','2010-01-18 16:28:48','','2010-01-18 16:28:48'),(86,'page_comment',0,'Відповіді на найпоширеніші запитання ми розміщуємо у даному розділі. Це заощадить Ваш час додасть зручності у користуванні.','page_comment','','UA','2010-01-30 19:17:54','Відповіді на найпоширеніші запитання ми розміщуємо у даному розділі. Це заощадить Ваш час додасть зручності у користуванні.','2010-01-30 19:17:54'),(86,'right_block_h_class_contact',0,NULL,'right_block_h_class_contact',NULL,'UA','2010-01-30 09:40:55',NULL,'2010-01-30 09:40:55'),(89,'edit_user',0,'root',NULL,NULL,'','0000-00-00 00:00:00','root','2010-01-19 08:29:23'),(89,'internal_page_content',0,'<p>От: Access Panel Test2 site Server</p>\r\n<p>1</p>\r\n<p>2</p>\r\n<p>3</p>\r\n<p>4</p>\r\n<p>&nbsp;</p>','internal_page_content','','UA','2010-01-19 08:33:01','<p>От: Access Panel Test2 site Server</p>\r\n<p>1</p>\r\n<p>2</p>\r\n<p>3</p>\r\n<p>4</p>\r\n<p>&nbsp;</p>','2010-01-19 08:33:01'),(89,'internal_page_header',0,'заголовок','internal_page_header','','UA','2010-01-19 08:32:10','заголовок','2010-01-19 08:32:10'),(89,'int_b_class',0,NULL,'int_b_class',NULL,'UA','2010-01-19 08:32:47',NULL,'2010-01-19 08:32:47'),(89,'int_h_class',0,NULL,'int_h_class',NULL,'UA','2010-01-19 08:31:58',NULL,'2010-01-19 08:31:58'),(89,'page_comment',0,NULL,'page_comment',NULL,'EN','2010-01-19 08:31:47',NULL,'2010-01-19 08:31:47'),(89,'page_comment',0,'пояснения','page_comment','','UA','2010-01-19 08:31:55','пояснения','2010-01-19 08:31:55'),(89,'page_header',0,'Новые статьи','page_header','','UA','2010-01-19 08:31:34','Новые статьи','2010-01-19 08:31:34');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_access`
--

DROP TABLE IF EXISTS `content_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_access` (
  `id` int(11) NOT NULL,
  `content_access_name` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_access`
--

LOCK TABLES `content_access` WRITE;
/*!40000 ALTER TABLE `content_access` DISABLE KEYS */;
INSERT INTO `content_access` VALUES (1,'Read only'),(2,'Edit'),(3,'Publish'),(4,'Full');
/*!40000 ALTER TABLE `content_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dns`
--

DROP TABLE IF EXISTS `dns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dns` (
  `id` int(11) NOT NULL auto_increment,
  `dns` varchar(255) NOT NULL default '',
  `comment` text,
  `status` int(11) NOT NULL default '0',
  `language_forwarding` char(2) default NULL,
  `draft_mode` tinyint(1) NOT NULL default '0',
  `cdn_server` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `dns` (`dns`),
  KEY `status_idx` (`status`),
  KEY `dns_language_idx` (`language_forwarding`),
  KEY `dns_cdn_server_idx` (`cdn_server`),
  CONSTRAINT `dns_cdn_server_idx` FOREIGN KEY (`cdn_server`) REFERENCES `dns` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dns_language_idx` FOREIGN KEY (`language_forwarding`) REFERENCES `language` (`language_code`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dns`
--

LOCK TABLES `dns` WRITE;
/*!40000 ALTER TABLE `dns` DISABLE KEYS */;
INSERT INTO `dns` VALUES (1,'test1.tns.2kgroup.com','',1,'UA',0,NULL),(2,'2kgroup-bmw','',1,'UA',0,NULL),(3,'109.68.45.2',NULL,1,'UA',0,NULL),(4,'opros.tns-global.com.ua','',1,'UA',0,NULL),(5,'opros.tns-ua.com','',1,'UA',0,NULL);
/*!40000 ALTER TABLE `dns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder_group`
--

DROP TABLE IF EXISTS `folder_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `folder_group` (
  `folder_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  KEY `folder_id` (`folder_id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder_group`
--

LOCK TABLES `folder_group` WRITE;
/*!40000 ALTER TABLE `folder_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `folder_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language` (
  `language_code` char(2) NOT NULL default '',
  `language_url` char(10) NOT NULL,
  `language_name` varchar(30) default NULL,
  `l_encode` varchar(50) default NULL,
  `paypal_lang` char(2) NOT NULL default 'US',
  `language_of_browser` char(50) NOT NULL,
  `status` int(11) NOT NULL default '0',
  `default_language` int(11) NOT NULL default '0',
  PRIMARY KEY  (`language_code`),
  UNIQUE KEY `language_of_browser` (`language_of_browser`),
  UNIQUE KEY `language_url` (`language_url`),
  UNIQUE KEY `language_name` (`language_name`),
  KEY `status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
INSERT INTO `language` VALUES ('','','','','','',1,0),('EN','EN','EN','UTF-8','US','%[EN]%',0,0),('RU','RU','Russian','windows-1251','RU','%[RU]%',0,0),('UA','UA','Ukrainian','windows-1251','EN','%[UA]%',1,1);
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail_inbox`
--

DROP TABLE IF EXISTS `mail_inbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail_inbox` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(50) NOT NULL default '',
  `name` varchar(100) NOT NULL default '',
  `add_info` text NOT NULL,
  `send_date` datetime NOT NULL,
  `viewed` int(10) unsigned NOT NULL default '0',
  `message` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `viewed_idx` (`viewed`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail_inbox`
--

LOCK TABLES `mail_inbox` WRITE;
/*!40000 ALTER TABLE `mail_inbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `mail_inbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ms_mail`
--

DROP TABLE IF EXISTS `ms_mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ms_mail` (
  `id` int(11) NOT NULL auto_increment,
  `original_name` varchar(255) NOT NULL default 'news_letters',
  `original_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` longtext,
  `from_name` varchar(255) NOT NULL,
  `from_email` varchar(255) NOT NULL,
  `header` longtext,
  `ms_status_id` int(11) NOT NULL default '2',
  `date_reg` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `original_id_idx` (`original_id`),
  KEY `ms_status_id_idx` (`ms_status_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ms_mail`
--

LOCK TABLES `ms_mail` WRITE;
/*!40000 ALTER TABLE `ms_mail` DISABLE KEYS */;
/*!40000 ALTER TABLE `ms_mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ms_recipient`
--

DROP TABLE IF EXISTS `ms_recipient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ms_recipient` (
  `id` int(11) NOT NULL auto_increment,
  `recipient` varchar(255) NOT NULL,
  `ms_mail_id` int(11) NOT NULL,
  `ms_status_id` int(11) NOT NULL default '2',
  `date_update` datetime default NULL,
  `language` char(2) NOT NULL,
  `recipient_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `ms_mail_id_idx` (`ms_mail_id`),
  KEY `ms_status_id_idx` (`ms_status_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ms_recipient`
--

LOCK TABLES `ms_recipient` WRITE;
/*!40000 ALTER TABLE `ms_recipient` DISABLE KEYS */;
/*!40000 ALTER TABLE `ms_recipient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ms_status`
--

DROP TABLE IF EXISTS `ms_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ms_status` (
  `id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `ms_status_key` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ms_status`
--

LOCK TABLES `ms_status` WRITE;
/*!40000 ALTER TABLE `ms_status` DISABLE KEYS */;
INSERT INTO `ms_status` VALUES (1,'draft'),(2,'outbox'),(3,'sent'),(4,'deleted'),(5,'error'),(6,'archive');
/*!40000 ALTER TABLE `ms_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nl_attachments`
--

DROP TABLE IF EXISTS `nl_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nl_attachments` (
  `id` int(11) NOT NULL auto_increment,
  `nl_id` int(11) NOT NULL,
  `file_name` varchar(50) NOT NULL,
  `file_content` longblob NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `nl_id_idx` (`nl_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nl_attachments`
--

LOCK TABLES `nl_attachments` WRITE;
/*!40000 ALTER TABLE `nl_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `nl_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nl_email`
--

DROP TABLE IF EXISTS `nl_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nl_email` (
  `id` int(11) NOT NULL auto_increment,
  `from_name` varchar(255) NOT NULL,
  `from_email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `tpl` varchar(255) default NULL,
  `body` longtext,
  `header` longtext,
  `transaction_id` int(11) default NULL,
  `finish_date` date default NULL,
  `ip_address` varchar(50) default NULL,
  `create_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `transaction_id_idx` (`transaction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nl_email`
--

LOCK TABLES `nl_email` WRITE;
/*!40000 ALTER TABLE `nl_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `nl_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nl_email_group`
--

DROP TABLE IF EXISTS `nl_email_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nl_email_group` (
  `nl_email_id` int(11) NOT NULL,
  `nl_group_id` int(11) NOT NULL,
  UNIQUE KEY `UQ__nl_email_group__22FF2F51` (`nl_email_id`,`nl_group_id`),
  KEY `nl_email_id_idx` (`nl_email_id`),
  KEY `nl_group_id_idx` (`nl_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nl_email_group`
--

LOCK TABLES `nl_email_group` WRITE;
/*!40000 ALTER TABLE `nl_email_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `nl_email_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nl_group`
--

DROP TABLE IF EXISTS `nl_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nl_group` (
  `id` int(11) NOT NULL auto_increment,
  `group_name` varchar(255) NOT NULL,
  `show_on_front` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UQ__nl_group__40058253` (`group_name`),
  KEY `show_on_front_idx` (`show_on_front`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nl_group`
--

LOCK TABLES `nl_group` WRITE;
/*!40000 ALTER TABLE `nl_group` DISABLE KEYS */;
INSERT INTO `nl_group` VALUES (1,'newsletter group',1);
/*!40000 ALTER TABLE `nl_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nl_subscriber`
--

DROP TABLE IF EXISTS `nl_subscriber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nl_subscriber` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(255) NOT NULL,
  `nl_group_id` int(11) NOT NULL,
  `status` int(2) default NULL,
  `reg_date` datetime default NULL,
  `last_send` datetime default NULL,
  `confirm_code` bigint(20) default NULL,
  `language` char(2) default NULL,
  `company` char(255) default NULL,
  `first_name` varchar(50) default NULL,
  `sur_name` varchar(50) default NULL,
  `city` char(255) default NULL,
  `ip_address` varchar(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `nl_group_id_idx` (`nl_group_id`),
  KEY `status_idx` (`status`),
  KEY `nl_subscriber_language_idx` (`language`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nl_subscriber`
--

LOCK TABLES `nl_subscriber` WRITE;
/*!40000 ALTER TABLE `nl_subscriber` DISABLE KEYS */;
/*!40000 ALTER TABLE `nl_subscriber` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nl_subscriber_status`
--

DROP TABLE IF EXISTS `nl_subscriber_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nl_subscriber_status` (
  `id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  UNIQUE KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nl_subscriber_status`
--

LOCK TABLES `nl_subscriber_status` WRITE;
/*!40000 ALTER TABLE `nl_subscriber_status` DISABLE KEYS */;
INSERT INTO `nl_subscriber_status` VALUES (0,'subscribe requested'),(1,'subscribed'),(3,'unsubscribe requested'),(4,'unsubscribed');
/*!40000 ALTER TABLE `nl_subscriber_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object`
--

DROP TABLE IF EXISTS `object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object`
--

LOCK TABLES `object` WRITE;
/*!40000 ALTER TABLE `object` DISABLE KEYS */;
INSERT INTO `object` VALUES (10,'answer'),(14,'ap_investigation'),(13,'ap_news'),(1,'captcha'),(3,'formbuilder'),(2,'form_mails'),(5,'gallery'),(4,'gallery_image'),(6,'news_channels'),(7,'news_export'),(8,'news_items'),(9,'news_mapping'),(11,'question'),(12,'survey');
/*!40000 ALTER TABLE `object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_content`
--

DROP TABLE IF EXISTS `object_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_content` (
  `object_field_id` int(11) NOT NULL,
  `object_record_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `language` char(2) NOT NULL default 'UA',
  PRIMARY KEY  (`object_field_id`,`object_record_id`,`language`),
  KEY `object_content_object_record_id` (`object_record_id`),
  KEY `language` (`language`),
  CONSTRAINT `object_content_ibfk_1` FOREIGN KEY (`object_field_id`) REFERENCES `object_field` (`id`) ON DELETE CASCADE,
  CONSTRAINT `object_content_ibfk_2` FOREIGN KEY (`language`) REFERENCES `language` (`language_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `object_content_object_record_id` FOREIGN KEY (`object_record_id`) REFERENCES `object_record` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_content`
--

LOCK TABLES `object_content` WRITE;
/*!40000 ALTER TABLE `object_content` DISABLE KEYS */;
INSERT INTO `object_content` VALUES (71,4,'001265666400','UA'),(72,4,'TNS Opros набирає обертів','UA'),(73,4,'Цього дня стартував наймасштабніший проект у галузі маркетингових досліджень на території України.','UA'),(74,4,'<p>Цього дня стартував наймасштабніший проект у галузі маркетингових досліджень на території України - аксес-панель &ldquo;Opros&rdquo;. Ми раді сповістити Вас, що Ви маєте нагоду приєднатися до нас та почати змінювати світ навколо Вас.</p>','UA'),(75,4,'News_UA_4_ap_news_img.png','UA'),(76,18,'001265234400','UA'),(76,27,'001265580000','UA'),(76,28,'001265580000','UA'),(76,30,'001265580000','UA'),(76,31,'001266184800','UA'),(76,32,'001266184800','UA'),(76,33,'001266184800','UA'),(76,34,'001266184800','UA'),(77,18,'Використання мобільного телефону','UA'),(77,27,'Кількість автомобілів у сім’ї','UA'),(77,28,'Інтерактивне спілкування і спілкування у реальному житті','UA'),(77,30,'На що витрачаються кишенькові гроші','UA'),(77,31,'Покупка презервативів','UA'),(77,32,'Вживання засобів від похмілля','UA'),(77,33,'Без чого ми не можемо уявити своє життя? ','UA'),(77,34,'Користування Інтернет','UA'),(78,18,'Ще 12 років назад ніхто нічого не знав про мобільний звязок, а на сьогоднішній день 88 % міського населення використовують мобільний звязок, і кількість користувачів збільшується. ','UA'),(78,27,'Не дивлячись на фінансову кризу, кількість автомобілів і Україні зберігається. В кожній 5ій сімї, що проживає в містах Українм, є один автомобіль (20, 4%), а 2% українців мають два та більше автомобілів.','UA'),(78,28,'Трохи більше половини міського населення України у віці 16-65 років, а саме 58 %, поділяють побоювання, що компютер замінить просте спілкування між людьми, хоча всього 22% населення України у віці 16-65 років використовують комп’ютер вдома кожен день і 11% на роботі/під час навчання. ','UA'),(78,30,'56.7% дітей у віці від 12 до 15 років (які проживають у містах України з населенням більше, ніж 50 тис. жителів), у яких є кишенькові гроші, витрачають їх на покупку солодощів, чіпсів, сухариків і 50,2% витрачають свої кишенькові гроші на напої. ','UA'),(78,31,'Кожен 5-й міський житель України у віці 16-65 років купує презервативи (21,9%). ','UA'),(78,32,'5% серед міського населення України в віці 16-65 років хоча б раз у півроку вживали покупні засоби від похмілля. ','UA'),(78,33,'Люди не можуть прожити без повітря, без їжі та води, але ще, крім того, 62,3% міського населення України у віці 16-65 років не можуть уявити свого життя без перегляду ТВ. ','UA'),(78,34,'Виявляється, рівень користування Інтернет вдома зростає, а рівень використання на роботі – падає. ','UA'),(79,18,'<p>Кожен другий українець відправляє SMS кожен або майже кожен день (21,9%). 34.6% міського населення України у віці 12-65 років не можуть уявити свого життя без розмов по мобільному телефону. 69,4% міського населення України у віці 12-65 років згодні з твердженням, що мобільний телефон допомагає людям жити повноцінним життям.</p>\r\n<p><img width=\"420\" height=\"256\" src=\"/usersimage/Image/article_UA_telephone.PNG\" alt=\"\" /></p>\r\n<p>&nbsp;</p>\r\n<p>Джерело: MMI Ukraine</p>','UA'),(79,27,'<p><img width=\"420\" height=\"198\" alt=\"\" src=\"/usersimage/Image/article_UA_cars.PNG\" /></p>\r\n<p>&nbsp;</p>\r\n<p>Джерело: MMI Ukraine</p>','UA'),(79,28,'<p><img width=\"420\" height=\"251\" src=\"/usersimage/Image/article_UA_communication.PNG\" alt=\"\" /></p>\r\n<p>&nbsp;</p>\r\n<p>Джерело: MMI Ukraine</p>','UA'),(79,30,'<p><img width=\"390\" height=\"814\" align=\"middle\" src=\"/usersimage/Image/123.png\" alt=\"\" /></p>\r\n<p>&nbsp;</p>\r\n<p>Джерело: MMI Ukraine</p>','UA'),(79,31,'<p>Серед тих, хто є холостими або не заміжніми, 26,3% купують презервативи, це більше, ніж серед усього міського населення України у віці 16-65 років. Серед тих, хто згодні з твердженнями, що перед тим як заводити дітей, потрібно як можна довше пожити у своє задоволення, і заводити дітей можна тільки після того, як досягнеш чогось у житті - 24,7% и 24,4% відповідно купують презервативи, це більше ніж серед усього міського населення України у віці 16-65 років.</p>\r\n<p class=\"MsoNormal\">&nbsp;</p>\r\n<p class=\"MsoNormal\"><span lang=\"UK\" style=\"font-size: 10pt; font-family: Arial;\"><img width=\"420\" height=\"256\" src=\"/usersimage/Image/article_UA_condoms.PNG\" alt=\"\" /></span></p>\r\n<p>&nbsp;</p>\r\nДжерело: MMI Ukraine','UA'),(79,32,'Серед тих, хто вживав вермут декілька разів в місяць чи раз в місяць, засоби від похмілля вживали 18%. А серед тих, хто вживає горілку частіше одного разу в місяць або раз в місяць, 12% вживали засоби від похмілля. Це більше, ніж серед усього міського населення України у віці 16-65 років.\r\n<p><img width=\"420\" height=\"258\" src=\"/usersimage/Image/article_UA_drunk.PNG\" alt=\"\" /></p>\r\n<p>Джерело: MMI Ukraine</p>','UA'),(79,33,'<p><img width=\"420\" height=\"319\" alt=\"\" src=\"/usersimage/Image/article_UA_lifewithout.PNG\" /></p>\r\n<p>&nbsp;</p>\r\n<p>Джерело: MMI Ukraine</p>','UA'),(79,34,'<p><img width=\"420\" height=\"254\" src=\"/usersimage/Image/article_UA_internetusing.PNG\" alt=\"\" /></p>\r\n<p>&nbsp;</p>\r\nДжерело: MMI Ukraine','UA');
/*!40000 ALTER TABLE `object_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_field`
--

DROP TABLE IF EXISTS `object_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_field` (
  `id` int(11) NOT NULL auto_increment,
  `object_id` int(11) NOT NULL,
  `object_field_name` varchar(50) NOT NULL,
  `object_field_type` varchar(20) NOT NULL,
  `one_for_all_languages` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `object_id` (`object_id`,`object_field_name`),
  KEY `object_field_type` (`object_field_type`),
  KEY `one_for_all_languages_idx` (`one_for_all_languages`),
  CONSTRAINT `object_field_object_id` FOREIGN KEY (`object_id`) REFERENCES `object` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `object_field_type` FOREIGN KEY (`object_field_type`) REFERENCES `object_field_type` (`object_field_type`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_field`
--

LOCK TABLES `object_field` WRITE;
/*!40000 ALTER TABLE `object_field` DISABLE KEYS */;
INSERT INTO `object_field` VALUES (1,1,'captcha_word','TEXT',0),(2,2,'form_name','TEXT',1),(3,2,'user_name','TEXT',1),(4,2,'date','TEXT',1),(5,2,'ip','TEXT',1),(6,2,'serialized','LONGTEXT',1),(7,3,'form_name','TEXT',1),(8,3,'form_config','LONGTEXT',1),(9,3,'content','LONGTEXT',1),(10,5,'gallery_date','DATE',1),(11,5,'gallery_title','TEXT',0),(12,5,'gallery_description','TEXT',0),(13,5,'gallery_status','INTEGER',1),(14,5,'gallery_image_w','INTEGER',1),(15,5,'gallery_image_h','INTEGER',1),(16,5,'gallery_images','INTEGER',1),(17,5,'load_gallery','TEXT',1),(18,5,'gallery_id','ID',1),(19,4,'gallery_id','FOREIGN_KEY',1),(20,4,'image_filename','TEXT',1),(21,4,'image_title','TEXT',0),(22,4,'image_description','TEXT',0),(23,4,'is_gallery_image','INTEGER',1),(24,4,'item_order','INTEGER',1),(25,4,'load_image','TEXT',1),(26,4,'text_above_image','TEXT',0),(27,4,'text_below_image','TEXT',0),(28,4,'publish_date','DATE',1),(29,4,'KEYWORDS','TEXT',0),(30,4,'DESCRIPTION','TEXT',0),(31,4,'TITLE','TEXT',0),(32,6,'channel_title','TEXT',0),(33,6,'channel_link','TEXT',0),(34,6,'channel_description','TEXT',0),(35,6,'channel_language','TEXT',0),(36,6,'channel_pubDate','DATE',1),(37,6,'channel_lastBuildDate','DATE',0),(38,6,'channel_docs','TEXT',0),(39,6,'channel_generator','TEXT',0),(40,6,'channel_managingEditor','TEXT',0),(41,6,'channel_webMaster','TEXT',0),(42,6,'status_id','TEXT',1),(43,8,'summary_title','TEXT',0),(44,8,'item_title','TEXT',0),(45,8,'item_link','TEXT',0),(46,8,'item_description','TEXT',0),(47,8,'item_pubDate','DATE',1),(48,8,'item_guid','TEXT',0),(49,8,'item_channel_id','ID',1),(50,8,'status_of_news','TEXT',0),(51,8,'html_content','HTML',1),(52,8,'gallery_id','FOREIGN_KEY',1),(53,7,'name','TEXT',0),(54,7,'template','TEXT',0),(55,9,'title','TEXT',0),(56,9,'channel','ID',0),(57,9,'type_of_export','ID',0),(58,10,'answer','TEXT',0),(59,10,'question_id','FOREIGN_KEY',1),(60,11,'question','TEXT',0),(61,11,'active','INTEGER',1),(62,11,'date','TEXT',1),(63,11,'hide_results','INTEGER ',1),(64,11,'text_instead_hidden_results','HTML',0),(65,12,'question_id','FOREIGN_KEY',1),(66,12,'answer_id','FOREIGN_KEY',1),(67,12,'date','TEXT',1),(68,12,'ip','TEXT',1),(69,12,'answer_language','TEXT',1),(70,12,'user_id','TEXT',1),(71,13,'ap_news_date','DATE',1),(72,13,'ap_news_title','TEXT',0),(73,13,'ap_news_preview','LONGTEXT',0),(74,13,'ap_news_content','HTML',0),(75,13,'ap_news_img','IMAGE',1),(76,14,'ap_investigation_date','DATE',1),(77,14,'ap_investigation_title','TEXT',0),(78,14,'ap_investigation_preview','LONGTEXT',0),(79,14,'ap_investigation_content','HTML',0);
/*!40000 ALTER TABLE `object_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_field_type`
--

DROP TABLE IF EXISTS `object_field_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_field_type` (
  `id` int(11) NOT NULL auto_increment,
  `object_field_type` varchar(20) NOT NULL,
  `one_for_all_languages` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `object_field_type` (`object_field_type`),
  KEY `one_for_all_languages_idx` (`one_for_all_languages`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_field_type`
--

LOCK TABLES `object_field_type` WRITE;
/*!40000 ALTER TABLE `object_field_type` DISABLE KEYS */;
INSERT INTO `object_field_type` VALUES (1,'DATE',0),(2,'TEXT',0),(3,'INTEGER',0),(4,'IMAGE',0),(5,'HTML',0),(6,'ID',0),(7,'FOREIGN_KEY',0),(8,'LONGTEXT',0);
/*!40000 ALTER TABLE `object_field_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_record`
--

DROP TABLE IF EXISTS `object_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_record` (
  `id` int(11) NOT NULL auto_increment,
  `object_id` int(11) NOT NULL,
  `last_update` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `user_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `object_id` (`object_id`),
  CONSTRAINT `object_record_object_id` FOREIGN KEY (`object_id`) REFERENCES `object` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_record`
--

LOCK TABLES `object_record` WRITE;
/*!40000 ALTER TABLE `object_record` DISABLE KEYS */;
INSERT INTO `object_record` VALUES (4,13,'2010-01-21 16:19:34','Admin'),(18,14,'2010-02-04 13:56:45','Admin'),(27,14,'2010-02-08 09:48:34','Admin'),(28,14,'2010-02-08 10:41:03','Admin'),(30,14,'2010-02-08 12:54:07','Admin'),(31,14,'2010-02-15 13:08:24','Admin'),(32,14,'2010-02-15 13:15:11','Admin'),(33,14,'2010-02-15 13:17:44','Admin'),(34,14,'2010-02-15 13:21:18','Admin');
/*!40000 ALTER TABLE `object_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_template`
--

DROP TABLE IF EXISTS `object_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_template` (
  `id` int(11) NOT NULL auto_increment,
  `object_id` int(11) default NULL,
  `template_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `object_id` (`object_id`,`template_id`),
  KEY `object_template_template_id` (`template_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_template`
--

LOCK TABLES `object_template` WRITE;
/*!40000 ALTER TABLE `object_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permanent_redirect`
--

DROP TABLE IF EXISTS `permanent_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permanent_redirect` (
  `id` int(11) NOT NULL auto_increment,
  `source_url` varchar(255) default NULL,
  `target_url` varchar(255) default NULL,
  `page_id` int(11) default NULL,
  `lang_code` char(2) default NULL,
  `t_view` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `source_url` (`source_url`),
  KEY `page_id` (`page_id`),
  KEY `pr_language_code_idx` (`lang_code`),
  KEY `t_view` (`t_view`),
  CONSTRAINT `permanent_redirect_ibfk_1` FOREIGN KEY (`page_id`) REFERENCES `tpl_pages` (`id`),
  CONSTRAINT `permanent_redirect_ibfk_2` FOREIGN KEY (`lang_code`) REFERENCES `language` (`language_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `permanent_redirect_ibfk_3` FOREIGN KEY (`t_view`) REFERENCES `tpl_views` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permanent_redirect`
--

LOCK TABLES `permanent_redirect` WRITE;
/*!40000 ALTER TABLE `permanent_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `permanent_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permanent_redirect_object`
--

DROP TABLE IF EXISTS `permanent_redirect_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permanent_redirect_object` (
  `id` int(11) NOT NULL auto_increment,
  `source_url` varchar(255) NOT NULL,
  `target_url` varchar(255) default NULL,
  `language` char(2) default NULL,
  `tpl_view` int(11) default NULL,
  `object_record_id` int(11) default NULL,
  `object_view` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `pr_object_source_url` (`source_url`),
  KEY `pr_object_language_idx` (`language`),
  KEY `pr_object_tpl_view_idx` (`tpl_view`),
  KEY `pr_object_record_id` (`object_record_id`),
  KEY `pr_object_object_view` (`object_view`),
  CONSTRAINT `permanent_redirect_object_ibfk_1` FOREIGN KEY (`language`) REFERENCES `language` (`language_code`),
  CONSTRAINT `permanent_redirect_object_ibfk_2` FOREIGN KEY (`tpl_view`) REFERENCES `tpl_views` (`id`),
  CONSTRAINT `permanent_redirect_object_ibfk_3` FOREIGN KEY (`object_record_id`) REFERENCES `object_record` (`id`),
  CONSTRAINT `permanent_redirect_object_ibfk_4` FOREIGN KEY (`object_view`) REFERENCES `tpl_files` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permanent_redirect_object`
--

LOCK TABLES `permanent_redirect_object` WRITE;
/*!40000 ALTER TABLE `permanent_redirect_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `permanent_redirect_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `role_name` varchar(50) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (0,'None',0),(2,'Backoffice user (Restricted access)',2),(3,'Administrator (Full Access)',1);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `styles`
--

DROP TABLE IF EXISTS `styles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `styles` (
  `id` int(11) NOT NULL auto_increment,
  `element` varchar(50) NOT NULL,
  `class` varchar(50) NOT NULL default '',
  `title` varchar(50) NOT NULL,
  `declaration` text,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`element`,`class`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `styles`
--

LOCK TABLES `styles` WRITE;
/*!40000 ALTER TABLE `styles` DISABLE KEYS */;
INSERT INTO `styles` VALUES (4,'a','small_pink_down_arrow_at_left','Pink down arrow at left','a:6:{s:5:\"color\";s:4:\"#f09\";s:10:\"background\";s:54:\"url(images/small_pink_down_arrow.gif) no-repeat 0% 4px\";s:9:\"font-size\";s:4:\"15px\";s:11:\"font-weight\";s:4:\"bold\";s:11:\"font-family\";s:5:\"Arial\";s:12:\"padding-left\";s:4:\"20px\";}'),(9,'a','system_button','System button','a:0:{}'),(3,'p','content_simple_text','13px simple text','a:3:{s:5:\"color\";s:4:\"#333\";s:9:\"font-size\";s:4:\"13px\";s:11:\"font-family\";s:5:\"Arial\";}'),(5,'a','pink_microbox_at_left','Pink micro-box at left','a:8:{s:5:\"float\";s:4:\"left\";s:5:\"color\";s:4:\"#036\";s:10:\"background\";s:47:\"url(images/pink_microbox.gif) no-repeat 0% 5px;\";s:9:\"font-size\";s:4:\"12px\";s:11:\"font-weight\";s:4:\"bold\";s:11:\"font-family\";s:5:\"Arial\";s:11:\"margin-left\";s:4:\"45px\";s:12:\"padding-left\";s:3:\"8px\";}'),(6,'a','system_button2','System button 2','a:6:{s:5:\"color\";s:4:\"#036\";s:10:\"background\";s:50:\"url(images/imgArrowPinkBig.gif) no-repeat 100% 1px\";s:9:\"font-size\";s:4:\"12px\";s:11:\"font-weight\";s:4:\"bold\";s:11:\"font-family\";s:5:\"Arial\";s:13:\"padding-right\";s:4:\"19px\";}'),(7,'p','content_simple_text_lm','13px simple text lm','a:4:{s:5:\"color\";s:4:\"#333\";s:9:\"font-size\";s:4:\"13px\";s:11:\"font-family\";s:5:\"Arial\";s:11:\"margin-left\";s:4:\"60px\";}'),(8,'p','pink_15_lm','Pink 15px lm','a:5:{s:5:\"color\";s:4:\"#f09\";s:9:\"font-size\";s:4:\"15px\";s:11:\"font-weight\";s:4:\"bold\";s:11:\"font-family\";s:5:\"Arial\";s:11:\"margin-left\";s:4:\"60px\";}'),(10,'a','faq_question','FAQ question','a:4:{s:5:\"color\";s:4:\"#036\";s:9:\"font-size\";s:4:\"13px\";s:11:\"font-weight\";s:4:\"bold\";s:11:\"font-family\";s:5:\"Arial\";}'),(11,'ol','content_simple_text','OL simple text','a:3:{s:5:\"color\";s:4:\"#333\";s:9:\"font-size\";s:4:\"13px\";s:11:\"font-family\";s:5:\"Arial\";}');
/*!40000 ALTER TABLE `styles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tpl_files`
--

DROP TABLE IF EXISTS `tpl_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tpl_files` (
  `id` int(11) NOT NULL auto_increment,
  `file_name` varchar(100) NOT NULL default '',
  `type` int(11) NOT NULL default '0',
  `description` text,
  `cachable` enum('0','1') NOT NULL default '1',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `file_name` (`file_name`),
  KEY `type_idx` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tpl_files`
--

LOCK TABLES `tpl_files` WRITE;
/*!40000 ALTER TABLE `tpl_files` DISABLE KEYS */;
INSERT INTO `tpl_files` VALUES (1,'index',0,NULL,'1'),(2,'internal',0,NULL,'1'),(3,'login',0,NULL,'1'),(4,'filters',0,NULL,'1'),(5,'search',0,NULL,'1'),(6,'sitemap',0,NULL,'1'),(7,'rss_news',0,NULL,'1'),(8,'news_published',0,NULL,'1'),(9,'subscription_form',0,NULL,'1'),(10,'unsubscription_form',0,NULL,'1'),(11,'form_builder',0,NULL,'1'),(12,'media_doc',1,NULL,'1'),(13,'media_image',1,NULL,'1'),(14,'media_flash',1,NULL,'1'),(15,'subscribe_thanks',0,NULL,'1'),(16,'subscribe_confirm_thanks',0,NULL,'1'),(17,'unsubscribe_thanks',0,NULL,'1'),(18,'unsubscribe_confirm_thanks',0,NULL,'1'),(19,'subscribe_newsletter',0,NULL,'1'),(20,'unsubscribe_newsletter',0,NULL,'1'),(21,'subscribe_error',0,NULL,'1'),(22,'nl_notification',2,NULL,'1'),(24,'ap_respondent_edit_profile_form',0,'','1'),(25,'ap_respondent_register_form',0,'','1'),(27,'ap_password_reminder',0,'','1'),(28,'ap_respondent_reset_password_check_email',0,'','1'),(29,'ap_respondent_enter_password',0,'','1'),(31,'ap_sitemap',0,'','1'),(32,'error_404',0,'','1'),(33,'current_projects',0,'','1'),(34,'ap_respondent_enter_password_approv',0,'','1'),(35,'ap_respondent_enter_password_remind',0,'','1'),(36,'survey_history',0,'','1'),(37,'points_convertion',0,'','1'),(38,'ap_login_form',0,'','1'),(39,'int_why_register',0,'','1'),(40,'int_advantages',0,'','1'),(41,'faq',0,'','1'),(42,'int_simple',0,'','1'),(43,'int_project_complete',0,'','1'),(44,'int_news',0,'','1'),(45,'int_investigations',0,'Investigations','1');
/*!40000 ALTER TABLE `tpl_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tpl_folder`
--

DROP TABLE IF EXISTS `tpl_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tpl_folder` (
  `id` int(11) NOT NULL auto_increment,
  `folder` varchar(50) NOT NULL default '',
  `create_date` timestamp NOT NULL default '0000-00-00 00:00:00',
  `edit_date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `owner_name` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `folder` (`folder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tpl_folder`
--

LOCK TABLES `tpl_folder` WRITE;
/*!40000 ALTER TABLE `tpl_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `tpl_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tpl_pages`
--

DROP TABLE IF EXISTS `tpl_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tpl_pages` (
  `id` int(11) NOT NULL auto_increment,
  `page_name` varchar(50) NOT NULL default '',
  `extension` enum('html','htm','xml') NOT NULL default 'html',
  `page_description` varchar(255) default NULL,
  `default_page` int(11) NOT NULL default '0',
  `create_date` timestamp NOT NULL default '0000-00-00 00:00:00',
  `edit_date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `tpl_id` int(11) default NULL,
  `folder_id` int(11) default NULL,
  `for_search` int(11) default '1',
  `owner_name` varchar(45) default NULL,
  `is_locked` int(11) NOT NULL default '0',
  `group_access` int(11) NOT NULL default '1',
  `priority` varchar(4) default NULL,
  `cachable` enum('0','1') NOT NULL default '1',
  `change_freq` enum('always','hourly','daily','weekly','monthly','yearly','never') default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `page_name` (`page_name`,`folder_id`),
  KEY `for_search_idx` (`for_search`),
  KEY `is_locked_idx` (`is_locked`),
  KEY `folder_id` (`folder_id`),
  CONSTRAINT `tpl_pages_ibfk_1` FOREIGN KEY (`folder_id`) REFERENCES `tpl_pages` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tpl_pages`
--

LOCK TABLES `tpl_pages` WRITE;
/*!40000 ALTER TABLE `tpl_pages` DISABLE KEYS */;
INSERT INTO `tpl_pages` VALUES (1,'Home','html','Перша сторінка',1,'2009-11-14 21:07:33','2009-11-14 21:23:44',1,NULL,1,NULL,0,1,NULL,'1',NULL),(2,'login','html','Description of login',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',3,NULL,1,NULL,0,1,NULL,'1',NULL),(9,'sitemap','html','Description of sitemap',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',6,NULL,0,NULL,0,1,NULL,'1',NULL),(10,'rss','html','News in RSS format',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',7,NULL,0,NULL,0,1,NULL,'1',NULL),(11,'news_rss','html','Description of News RSS',0,'2009-11-14 21:07:33','2010-01-21 16:11:06',7,NULL,1,NULL,0,1,NULL,'1',NULL),(12,'subscribe_newsletter','html','subscribe_newsletter',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',9,NULL,1,NULL,0,1,NULL,'1',NULL),(13,'unsubscribe_newsletter','html','unsubscribe_newsletter',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',10,NULL,1,NULL,0,1,NULL,'1',NULL),(14,'newsletter_subscribe_notification','html','newsletter_subscribe_notification',0,'2009-11-14 21:07:33','2010-01-18 18:05:18',14,NULL,1,NULL,0,1,NULL,'1',NULL),(15,'newsletter_unsubscribe_notification','html','newsletter_unsubscribe_notification',0,'2009-11-14 21:07:33','2010-01-18 18:05:18',14,NULL,1,NULL,0,1,NULL,'1',NULL),(16,'subscribe_newsletter','html','subscribe_newsletter',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',19,NULL,1,NULL,0,1,NULL,'1',NULL),(17,'unsubscribe_newsletter','html','unsubscribe_newsletter',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',20,NULL,1,NULL,0,1,NULL,'1',NULL),(18,'subscribe_thanks','html','subscribe_thanks',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',15,NULL,1,NULL,0,1,NULL,'1',NULL),(19,'newsletter_subscribe_notification','html','newsletter_subscribe_notification',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',22,NULL,1,NULL,0,1,NULL,'1',NULL),(20,'newsletter_unsubscribe_notification','html','newsletter_unsubscribe_notification',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',22,NULL,1,NULL,0,1,NULL,'1',NULL),(21,'subscribe_confirm_thanks','html','subscribe_confirm_thanks',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',16,NULL,1,NULL,0,1,NULL,'1',NULL),(22,'unsubscribe_thanks','html','unsubscribe_thanks',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',17,NULL,1,NULL,0,1,NULL,'1',NULL),(23,'unsubscribe_confirm_thanks','html','unsubscribe_confirm_thanks',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',18,NULL,1,NULL,0,1,NULL,'1',NULL),(24,'subscribe_error','html','subscribe_error',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',21,NULL,1,NULL,0,1,NULL,'1',NULL),(25,'subscribe_error','html','subscribe_error',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',21,NULL,1,NULL,0,1,NULL,'1',NULL),(26,'subscribe_newsletter','html','subscribe_newsletter',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',19,NULL,1,NULL,0,1,NULL,'1',NULL),(27,'unsubscribe_newsletter','html','unsubscribe_newsletter',0,'2009-11-14 21:07:33','2009-11-14 21:07:33',20,NULL,1,NULL,0,1,NULL,'1',NULL),(28,'TNS_v_Ukrajini','html','TNS в Україні',0,'2009-11-16 10:18:48','2009-12-25 14:41:51',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(29,'vidpividalnist','html','Відповідальність',0,'2009-11-16 10:19:42','2010-01-14 15:54:20',42,NULL,1,'Admin',0,1,NULL,'1',NULL),(30,'survey-history','html','Історія опитувань',0,'2009-11-16 10:20:14','2010-01-18 19:05:40',36,NULL,1,'Admin',0,1,NULL,'1',NULL),(31,'konvertacija_baliv','html','Конвертація балів',0,'2009-11-16 10:20:56','2009-12-30 14:55:11',37,NULL,1,'Admin',0,1,NULL,'1',NULL),(32,'Kontakty','html','Контакти',0,'2009-11-16 10:22:12','2010-01-13 14:34:32',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(33,'Konfedencijnist','html','Конфеденційність',0,'2009-11-16 10:22:42','2010-01-14 15:53:27',42,NULL,1,'Admin',0,1,NULL,'1',NULL),(34,'mapa_sajtu','html','Мапа сайту',0,'2009-11-16 10:23:17','2009-12-25 14:39:31',31,NULL,1,'Admin',0,1,NULL,'1',NULL),(35,'my_Opros','html','Ми Opros',0,'2009-11-16 10:23:47','2010-03-29 17:52:57',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(36,'moji_baly','html','Мої бали',0,'2009-11-16 10:42:00','2009-12-25 14:46:53',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(37,'user-profile','html','Мої особисті дані',0,'2009-11-16 10:42:38','2010-01-18 19:07:30',24,NULL,1,'Admin',0,1,NULL,'1',NULL),(38,'Miy_Opros','html','Мій Opros',0,'2009-11-16 10:43:11','2010-03-29 17:40:31',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(39,'navishcho_reestruvatys','html','Навіщо реєструватись',0,'2009-11-16 10:43:43','2010-01-12 16:15:19',39,NULL,1,'Admin',0,1,NULL,'1',NULL),(40,'news','html','Новини',0,'2009-11-16 10:44:21','2010-01-21 16:11:37',44,NULL,1,'Admin',0,1,NULL,'1',NULL),(41,'ostanni_novyny','html','Останні новини',0,'2009-11-16 10:44:55','2009-12-25 14:33:32',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(42,'perevagy_36_6','html','Переваги 36.6',0,'2009-11-16 10:45:29','2010-01-12 21:24:29',40,NULL,1,'Admin',0,1,NULL,'1',NULL),(43,'pidsumky_doslidzhen','html','Підсумки досліджень',0,'2009-11-16 10:46:09','2009-12-25 14:40:09',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(44,'pozhiva_dlya_rozdumiv','html','Пожива для роздумів',0,'2009-11-16 10:46:48','2009-12-25 14:45:53',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(45,'potochni_proekty','html','Поточні проекти',0,'2009-11-16 10:47:18','2009-12-25 14:47:37',33,NULL,1,'Admin',0,1,NULL,'1',NULL),(46,'pravyla_uchasti','html','Правила участі',0,'2009-11-16 10:47:53','2010-01-14 15:55:32',42,NULL,1,'Admin',0,1,NULL,'1',NULL),(47,'forma_reestracii','html','Форма реєстрації',0,'2009-11-16 10:48:22','2010-03-20 06:28:04',25,NULL,1,'Admin',0,1,NULL,'0',NULL),(48,'pro_36_6','html','Про 36.6',0,'2009-11-16 10:49:06','2009-12-25 14:48:45',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(49,'pro_TNS_ta_36_6','html','Про TNS та 36.6',0,'2009-11-16 10:49:37','2009-12-25 14:49:23',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(50,'50','html','Проекти',0,'2009-11-16 10:50:11','2009-12-25 14:52:45',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(51,'rezultaty_doslidzhen','html','Результати досліджень',0,'2009-11-16 10:50:41','2010-01-29 14:37:14',45,NULL,1,'Admin',0,1,NULL,'1',NULL),(52,'systema_zaohochennya','html','Система заохочення',0,'2009-11-16 10:51:23','2009-12-25 14:51:02',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(53,'statystyka_vidviduvan','html','Статистика відвідувань',0,'2009-11-16 10:51:58','2009-12-25 14:51:33',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(55,'misija_36_6','html','Місія 36.6',0,'2009-11-16 11:10:40','2009-12-25 14:53:28',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(57,'57','html','Відновлення паролю (форма вводу email)',0,'2009-11-26 11:44:00','2010-03-20 05:29:46',27,NULL,1,'Admin',0,1,NULL,'0',NULL),(59,'respondent-registration-approve','html','Форма підтвердження реєстрації',0,'2009-11-26 12:41:53','2010-03-20 06:16:50',34,NULL,1,'Admin',0,1,NULL,'0',NULL),(60,'respondent-password-update','html','Оновлення паролю (форма для вводу нового паролю)',0,'2009-11-26 12:44:05','2010-03-20 06:10:03',35,NULL,1,'Admin',0,1,NULL,'0',NULL),(61,'respondent-registered-success','html','Реєстрацію завершено успішно',0,'2009-12-10 16:01:56','2010-01-14 18:12:51',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(62,'respondent_registration_approved_success','html','Реєстрацію завершено остаточно, пароль збережено.',0,'2009-12-11 10:36:12','2009-12-11 10:36:12',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(63,'page_not_found','html','404',0,'2009-12-11 14:41:48','2009-12-13 12:03:25',32,NULL,1,'Admin',0,1,NULL,'1',NULL),(64,'password_reminde_sended','html','Надіслано інструкції що до відновлення паролю',0,'2009-12-25 10:16:13','2009-12-25 10:16:13',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(65,'password_update_success','html','Новий пароль збережено',0,'2009-12-25 12:06:37','2009-12-25 12:06:37',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(66,'respondent_updated','html','Персональні дані оновлено',0,'2009-12-25 13:38:56','2009-12-25 13:38:56',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(67,'ap_forbidden','html','Немає доступу',0,'2009-12-29 21:55:04','2009-12-29 21:55:04',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(68,'Authorization','html','Авторизація',0,'2010-01-05 23:45:01','2010-03-20 06:01:09',38,NULL,1,'Admin',0,1,NULL,'0',NULL),(69,'tns_new_year','html','Сніжинки',0,'2010-01-08 13:48:26','2010-03-04 16:25:51',13,NULL,0,'Admin',0,1,NULL,'0',NULL),(70,'main_block_about_36_6_header','html','',0,'2010-01-08 13:54:20','2010-01-18 18:05:18',13,NULL,0,'Admin',0,1,NULL,'0',NULL),(71,'main_block_about_36_6','html','',0,'2010-01-08 13:54:20','2010-01-29 12:11:41',13,NULL,0,'Admin',0,1,NULL,'0',NULL),(72,'main_block_news_header','html','',0,'2010-01-08 13:54:20','2010-01-18 18:05:18',13,NULL,0,'Admin',0,1,NULL,'0',NULL),(73,'main_block_news','html','',0,'2010-01-08 13:54:20','2010-01-29 12:11:59',13,NULL,0,'Admin',0,1,NULL,'0',NULL),(74,'main_block_join_header','html','',0,'2010-01-08 13:54:20','2010-01-18 18:05:18',13,NULL,0,'Admin',0,1,NULL,'0',NULL),(75,'main_block_pryednajtes','html','',0,'2010-01-08 13:54:21','2010-01-29 12:12:24',13,NULL,0,'Admin',0,1,NULL,'0',NULL),(76,'main_block_about_tns_header','html','',0,'2010-01-08 13:54:21','2010-01-18 18:05:18',13,NULL,0,'Admin',0,1,NULL,'0',NULL),(77,'my_36_6_header','html','',0,'2010-01-11 08:15:54','2010-01-18 18:05:18',13,NULL,0,'Admin',0,1,NULL,'0',NULL),(78,'current_projects_header','html','',0,'2010-01-11 08:17:33','2010-01-18 18:05:18',13,NULL,0,'Admin',0,1,NULL,'0',NULL),(79,'darts_arrow','html','',0,'2010-01-12 16:16:31','2010-01-29 12:02:42',13,NULL,0,'Admin',0,1,NULL,'1',NULL),(80,'uah_sign','html','',0,'2010-01-12 16:46:34','2010-01-29 12:03:49',13,NULL,0,'Admin',0,1,NULL,'0',NULL),(81,'handshake','html','',0,'2010-01-12 18:24:59','2010-01-29 12:04:07',13,NULL,0,'Admin',0,1,NULL,'0',NULL),(84,'quotes','html','',0,'2010-01-12 18:41:00','2010-01-30 13:32:40',14,NULL,0,'Admin',0,1,NULL,'0',NULL),(85,'quotes_with_text','html','',0,'2010-01-12 18:51:31','2010-01-18 18:05:18',14,NULL,0,'Admin',0,1,NULL,'0',NULL),(86,'faq','html','Питання що часто задаються',0,'2010-01-13 11:37:30','2010-01-13 11:37:30',41,NULL,1,'Admin',0,1,NULL,'1',NULL),(88,'project_complete','html','Завершення проекту',0,'2010-01-18 18:14:11','2010-01-18 18:16:37',43,NULL,1,'Admin',0,1,NULL,'1',NULL),(89,'new','html','',0,'2010-01-19 08:28:41','2010-01-19 08:28:41',2,NULL,1,'viktor',0,1,NULL,'1',NULL),(90,'password_updated_success','html','Новий пароль збережено',0,'2010-01-19 11:56:40','2010-01-19 11:56:40',2,NULL,1,'Admin',0,1,NULL,'1',NULL),(91,'91','html','flash_el_advantages',0,'2010-01-30 13:30:09','2010-01-30 13:31:34',14,NULL,0,'Admin',0,1,NULL,'0',NULL),(92,'tns_March_8','html','Girl with flower and smile',0,'2010-03-04 15:13:43','2010-03-04 15:16:56',13,NULL,0,'Admin',0,1,NULL,'0',NULL);
/*!40000 ALTER TABLE `tpl_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tpl_views`
--

DROP TABLE IF EXISTS `tpl_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tpl_views` (
  `id` int(11) NOT NULL auto_increment,
  `view_name` varchar(100) default NULL,
  `view_folder` varchar(100) NOT NULL,
  `description` text,
  `icon` varchar(150) default NULL,
  `is_default` enum('1') default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `view_folder` (`view_folder`),
  UNIQUE KEY `view_name` (`view_name`),
  UNIQUE KEY `is_default` (`is_default`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tpl_views`
--

LOCK TABLES `tpl_views` WRITE;
/*!40000 ALTER TABLE `tpl_views` DISABLE KEYS */;
INSERT INTO `tpl_views` VALUES (1,'s','html','simple','doc.png','1');
/*!40000 ALTER TABLE `tpl_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `url_mapping_object`
--

DROP TABLE IF EXISTS `url_mapping_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `url_mapping_object` (
  `id` int(11) NOT NULL auto_increment,
  `target_url` varchar(255) NOT NULL,
  `language` char(2) NOT NULL,
  `tpl_view` int(11) default NULL,
  `object_record_id` int(11) NOT NULL,
  `object_view` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `url_mapping_object_target_url` (`target_url`),
  KEY `url_mapping_object_language_idx` (`language`),
  KEY `url_mapping_object_tpl_view_idx` (`tpl_view`),
  KEY `url_mapping_object_record_id` (`object_record_id`),
  KEY `url_mapping_object_object_view` (`object_view`),
  CONSTRAINT `url_mapping_object_ibfk_1` FOREIGN KEY (`language`) REFERENCES `language` (`language_code`),
  CONSTRAINT `url_mapping_object_ibfk_2` FOREIGN KEY (`tpl_view`) REFERENCES `tpl_views` (`id`),
  CONSTRAINT `url_mapping_object_ibfk_3` FOREIGN KEY (`object_record_id`) REFERENCES `object_record` (`id`),
  CONSTRAINT `url_mapping_object_ibfk_4` FOREIGN KEY (`object_view`) REFERENCES `tpl_files` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `url_mapping_object`
--

LOCK TABLES `url_mapping_object` WRITE;
/*!40000 ALTER TABLE `url_mapping_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `url_mapping_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group`
--

DROP TABLE IF EXISTS `user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_group` (
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  KEY `user_id` (`user_id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group`
--

LOCK TABLES `user_group` WRITE;
/*!40000 ALTER TABLE `user_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_groups` (
  `id` int(11) NOT NULL auto_increment,
  `group_name` varchar(250) NOT NULL,
  `group_code` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `group_code` (`group_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups`
--

LOCK TABLES `user_groups` WRITE;
/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(150) default NULL,
  `login` varchar(50) default NULL,
  `passw` varchar(50) default NULL,
  `email` varchar(150) default NULL,
  `status` int(11) default '1',
  `role` int(11) default '0',
  `content_access` int(11) default NULL,
  `comment` text,
  `icq` int(11) default NULL,
  `city` varchar(50) default NULL,
  `resetpassw` int(11) default '1',
  `ip` varchar(20) default NULL,
  `browser` varchar(50) default NULL,
  `login_datetime` datetime default NULL,
  `month_visits` int(11) default NULL,
  `passw_update_datetime` datetime default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `login_idx` (`login`),
  KEY `status_idx` (`status`),
  KEY `role_idx` (`role`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin','root','64306313b693cdc49241199449a6a3f6','...@2kgroup.com',1,3,NULL,'Full access',NULL,'',0,'91.200.192.6','Firefox 3.6','2010-04-07 18:14:12',6,'2010-01-21 19:54:57'),(2,'admin','admin','06ffd971cb908550d220791c56cc6240','kostyaz@2kgroup.com',1,3,4,'',NULL,'',0,'91.200.192.6','Firefox 3.5.5 (.NET CLR 3.5.30729)','2010-01-19 10:18:43',3,'2010-01-18 21:48:16'),(3,'viktor','viktor','b2e0775187b751e83d7b901c67310081','tortiki@ukr.net',1,3,4,'',NULL,'',0,'91.200.192.6','Firefox 3.5.5 (.NET CLR 3.5.30729)','2010-01-19 10:20:25',1,'2010-01-19 10:20:25');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `v_channel_db`
--

DROP TABLE IF EXISTS `v_channel_db`;
/*!50001 DROP VIEW IF EXISTS `v_channel_db`*/;
/*!50001 CREATE TABLE `v_channel_db` (
  `id` varchar(139),
  `language` char(2),
  `channel_id` longtext,
  `status` longtext,
  `author` longtext,
  `channel_type` longtext,
  `title` longtext,
  `description` longtext,
  `rss` longtext,
  `copyright` longtext
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_channel_edit`
--

DROP TABLE IF EXISTS `v_channel_edit`;
/*!50001 DROP VIEW IF EXISTS `v_channel_edit`*/;
/*!50001 CREATE TABLE `v_channel_edit` (
  `channel_id` longtext,
  `title` longtext,
  `description` longtext,
  `status` longtext,
  `author` longtext,
  `channel_type` longtext,
  `copyright` longtext,
  `rss` longtext
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_channel_grid`
--

DROP TABLE IF EXISTS `v_channel_grid`;
/*!50001 DROP VIEW IF EXISTS `v_channel_grid`*/;
/*!50001 CREATE TABLE `v_channel_grid` (
  `channel_id` longtext,
  `title` longtext,
  `status` varchar(8),
  `author` longtext,
  `channel_type` longtext,
  `rss` varchar(3)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_dns`
--

DROP TABLE IF EXISTS `v_dns`;
/*!50001 DROP VIEW IF EXISTS `v_dns`*/;
/*!50001 CREATE TABLE `v_dns` (
  `id` int(11),
  `dns` varchar(255),
  `comment` text,
  `status` int(11),
  `language_forwarding` char(2),
  `draft_mode` tinyint(1),
  `cdn_server` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_dns_edit`
--

DROP TABLE IF EXISTS `v_dns_edit`;
/*!50001 DROP VIEW IF EXISTS `v_dns_edit`*/;
/*!50001 CREATE TABLE `v_dns_edit` (
  `id` int(11),
  `dns` varchar(255),
  `comment` text,
  `status` int(11),
  `language_forwarding` char(2),
  `draft_mode` tinyint(1),
  `cdn_server` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_dns_grid`
--

DROP TABLE IF EXISTS `v_dns_grid`;
/*!50001 DROP VIEW IF EXISTS `v_dns_grid`*/;
/*!50001 CREATE TABLE `v_dns_grid` (
  `id` int(11),
  `dns` varchar(255),
  `comment` text,
  `status` varchar(8),
  `language_forwarding` char(2),
  `draft_mode` tinyint(1)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_events_db`
--

DROP TABLE IF EXISTS `v_events_db`;
/*!50001 DROP VIEW IF EXISTS `v_events_db`*/;
/*!50001 CREATE TABLE `v_events_db` (
  `id` varchar(140),
  `language` char(2),
  `news_id` longtext,
  `title` longtext,
  `description` longtext,
  `SystemDate` longtext,
  `SystemDate_d` varchar(10),
  `ExpiryDate` longtext,
  `ExpiryDate_d` varchar(10),
  `DisplayDate` longtext,
  `PublishedDate` longtext,
  `PublishedDate_d` varchar(10),
  `status` longtext,
  `channel_id` longtext,
  `show_on_home` longtext,
  `category` longtext,
  `status_text` varchar(9)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_lang_edit`
--

DROP TABLE IF EXISTS `v_lang_edit`;
/*!50001 DROP VIEW IF EXISTS `v_lang_edit`*/;
/*!50001 CREATE TABLE `v_lang_edit` (
  `id` char(2),
  `language_url` char(10),
  `language_name` varchar(30),
  `language_link_title` char(0),
  `l_encode` varchar(50),
  `paypal_lang` char(2),
  `status` int(11),
  `is_default` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_lang_grid`
--

DROP TABLE IF EXISTS `v_lang_grid`;
/*!50001 DROP VIEW IF EXISTS `v_lang_grid`*/;
/*!50001 CREATE TABLE `v_lang_grid` (
  `language_code` char(2),
  `language_url` char(10),
  `language_name` varchar(30),
  `language_link_title` longtext,
  `l_encode` varchar(50),
  `paypal_lang` char(2),
  `status` varchar(8),
  `default_language` varchar(3)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_language`
--

DROP TABLE IF EXISTS `v_language`;
/*!50001 DROP VIEW IF EXISTS `v_language`*/;
/*!50001 CREATE TABLE `v_language` (
  `language_code` char(2),
  `language_url` char(10),
  `language_name` varchar(30),
  `l_encode` varchar(50),
  `paypal_lang` char(2),
  `language_of_browser` char(50),
  `status` int(11),
  `default_language` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_mail_inbox_edit`
--

DROP TABLE IF EXISTS `v_mail_inbox_edit`;
/*!50001 DROP VIEW IF EXISTS `v_mail_inbox_edit`*/;
/*!50001 CREATE TABLE `v_mail_inbox_edit` (
  `id` int(11),
  `name` varchar(100),
  `email` varchar(50),
  `send_date` varchar(21),
  `add_info` text
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_mail_inbox_grid`
--

DROP TABLE IF EXISTS `v_mail_inbox_grid`;
/*!50001 DROP VIEW IF EXISTS `v_mail_inbox_grid`*/;
/*!50001 CREATE TABLE `v_mail_inbox_grid` (
  `id` int(11),
  `name` varchar(100),
  `email` varchar(50),
  `send_date` datetime,
  `message` text,
  `add_info` text,
  `viewed` varchar(3)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_mailing_edit`
--

DROP TABLE IF EXISTS `v_mailing_edit`;
/*!50001 DROP VIEW IF EXISTS `v_mailing_edit`*/;
/*!50001 CREATE TABLE `v_mailing_edit` (
  `id` int(11),
  `original_id` int(11),
  `subject` varchar(255),
  `date_reg` datetime,
  `from_` longtext,
  `status` varchar(255),
  `recipients_count` varchar(45)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_mailing_grid`
--

DROP TABLE IF EXISTS `v_mailing_grid`;
/*!50001 DROP VIEW IF EXISTS `v_mailing_grid`*/;
/*!50001 CREATE TABLE `v_mailing_grid` (
  `id` int(11),
  `original_id` int(11),
  `subject` varchar(255),
  `date_reg` datetime,
  `from_` longtext,
  `status` varchar(255),
  `recipients_count` varchar(45)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_media`
--

DROP TABLE IF EXISTS `v_media`;
/*!50001 DROP VIEW IF EXISTS `v_media`*/;
/*!50001 CREATE TABLE `v_media` (
  `id` int(11),
  `page_name` varchar(50),
  `extension` enum('html','htm','xml'),
  `page_description` varchar(255),
  `default_page` int(11),
  `create_date` timestamp,
  `edit_date` timestamp,
  `tpl_id` int(11),
  `folder_id` int(11),
  `for_search` int(11),
  `owner_name` varchar(45),
  `is_locked` int(11),
  `type` bigint(11),
  `file_name` varchar(100),
  `group_access` int(11),
  `priority` varchar(4),
  `cachable` enum('0','1')
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_media_content`
--

DROP TABLE IF EXISTS `v_media_content`;
/*!50001 DROP VIEW IF EXISTS `v_media_content`*/;
/*!50001 CREATE TABLE `v_media_content` (
  `id` int(11),
  `page_name` longtext,
  `page_description` varchar(255),
  `default_page` int(11),
  `create_date` timestamp,
  `edit_date` timestamp,
  `tpl_id` int(11),
  `folder_id` int(11),
  `for_search` int(11),
  `owner_name` varchar(45),
  `is_locked` int(11),
  `type` bigint(11),
  `file_name` varchar(100),
  `cachable` enum('0','1'),
  `language` char(2)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_media_edit`
--

DROP TABLE IF EXISTS `v_media_edit`;
/*!50001 DROP VIEW IF EXISTS `v_media_edit`*/;
/*!50001 CREATE TABLE `v_media_edit` (
  `id` int(11),
  `page_name` varchar(50),
  `media_description` varchar(255),
  `template` int(11),
  `folder` int(11),
  `size` char(0),
  `alt_tag` char(0),
  `zip_file_name` char(0),
  `cachable` enum('0','1')
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_media_file`
--

DROP TABLE IF EXISTS `v_media_file`;
/*!50001 DROP VIEW IF EXISTS `v_media_file`*/;
/*!50001 CREATE TABLE `v_media_file` (
  `id` int(11),
  `file_name` varchar(100),
  `type` int(11),
  `description` text,
  `cachable` enum('0','1')
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_media_grid`
--

DROP TABLE IF EXISTS `v_media_grid`;
/*!50001 DROP VIEW IF EXISTS `v_media_grid`*/;
/*!50001 CREATE TABLE `v_media_grid` (
  `id` int(11),
  `media_name` longtext,
  `media_description` varchar(255),
  `template` varchar(104),
  `folder` longtext,
  `edit_date` timestamp,
  `cachable` varchar(3),
  `in_draft_state` varchar(3),
  `language` char(2)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_ms_mail`
--

DROP TABLE IF EXISTS `v_ms_mail`;
/*!50001 DROP VIEW IF EXISTS `v_ms_mail`*/;
/*!50001 CREATE TABLE `v_ms_mail` (
  `id` int(11),
  `original_id` int(11),
  `subject` varchar(255),
  `date_reg` datetime,
  `body` longtext,
  `from_` longtext,
  `status` varchar(255),
  `recipients_count` varchar(45)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_ms_recipient`
--

DROP TABLE IF EXISTS `v_ms_recipient`;
/*!50001 DROP VIEW IF EXISTS `v_ms_recipient`*/;
/*!50001 CREATE TABLE `v_ms_recipient` (
  `id` int(11),
  `ms_mail_id` int(11),
  `recipient` varchar(255),
  `date_update` datetime,
  `status` varchar(255),
  `recipient_id` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_news_edit`
--

DROP TABLE IF EXISTS `v_news_edit`;
/*!50001 DROP VIEW IF EXISTS `v_news_edit`*/;
/*!50001 CREATE TABLE `v_news_edit` (
  `news_id` longtext,
  `title` longtext,
  `description` longtext,
  `status` longtext,
  `category` longtext,
  `show_on_home` longtext,
  `channel_id` longtext,
  `SystemDate` longtext,
  `ExpiryDate` longtext,
  `PublishedDate` longtext
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_news_grid`
--

DROP TABLE IF EXISTS `v_news_grid`;
/*!50001 DROP VIEW IF EXISTS `v_news_grid`*/;
/*!50001 CREATE TABLE `v_news_grid` (
  `news_id` longtext,
  `title` longtext,
  `status` varchar(9),
  `category` longtext,
  `channel_id` longtext,
  `SystemDate` longtext,
  `ExpiryDate` longtext,
  `PublishedDate` longtext
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_news_letters_edit`
--

DROP TABLE IF EXISTS `v_news_letters_edit`;
/*!50001 DROP VIEW IF EXISTS `v_news_letters_edit`*/;
/*!50001 CREATE TABLE `v_news_letters_edit` (
  `id` int(11),
  `email_from_name` varchar(255),
  `email_from_email` varchar(255),
  `email_subject` longtext,
  `email_tpl` varchar(255),
  `email_body` longtext,
  `email_header` longtext,
  `group_count` bigint(21),
  `subscr_count` bigint(21),
  `email_status` varchar(7),
  `email_transaction_id` int(11),
  `finish_date` varbinary(30),
  `ip_address` varchar(50),
  `create_date` timestamp
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_news_letters_grid`
--

DROP TABLE IF EXISTS `v_news_letters_grid`;
/*!50001 DROP VIEW IF EXISTS `v_news_letters_grid`*/;
/*!50001 CREATE TABLE `v_news_letters_grid` (
  `id` int(11),
  `from_name` varchar(255),
  `from_email` varchar(255),
  `subject` longtext,
  `status` varchar(7),
  `Finish Date` varchar(10),
  `ip_address` varchar(50),
  `create_date` timestamp
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_nl_email`
--

DROP TABLE IF EXISTS `v_nl_email`;
/*!50001 DROP VIEW IF EXISTS `v_nl_email`*/;
/*!50001 CREATE TABLE `v_nl_email` (
  `email_id` int(11),
  `email_from_name` varchar(255),
  `email_from_email` varchar(255),
  `email_subject` varchar(255),
  `email_tpl` varchar(255),
  `email_body` longtext,
  `email_header` longtext,
  `group_count` bigint(21),
  `subscr_count` bigint(21),
  `email_status` varchar(6),
  `email_transaction_id` int(11),
  `finish_date` varbinary(30),
  `ip_address` varchar(50),
  `create_date` timestamp
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_nl_email_edit`
--

DROP TABLE IF EXISTS `v_nl_email_edit`;
/*!50001 DROP VIEW IF EXISTS `v_nl_email_edit`*/;
/*!50001 CREATE TABLE `v_nl_email_edit` (
  `email_id` int(11),
  `email_from_name` varchar(255),
  `email_from_email` varchar(255),
  `email_subject` varchar(255),
  `email_tpl` varchar(255),
  `email_body` longtext,
  `email_header` longtext,
  `group_count` bigint(21),
  `subscr_count` bigint(21),
  `email_status` varchar(6),
  `email_transaction_id` int(11),
  `finish_date` varbinary(30),
  `ip_address` varchar(50),
  `create_date` timestamp
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_nl_email_grid`
--

DROP TABLE IF EXISTS `v_nl_email_grid`;
/*!50001 DROP VIEW IF EXISTS `v_nl_email_grid`*/;
/*!50001 CREATE TABLE `v_nl_email_grid` (
  `email_id` int(11),
  `email_from_name` varchar(255),
  `email_from_email` varchar(255),
  `email_subject` varchar(255),
  `email_header` longtext,
  `email_status` varchar(6),
  `finish_date` varbinary(30),
  `ip_address` varchar(50),
  `create_date` timestamp
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_nl_group`
--

DROP TABLE IF EXISTS `v_nl_group`;
/*!50001 DROP VIEW IF EXISTS `v_nl_group`*/;
/*!50001 CREATE TABLE `v_nl_group` (
  `id` int(11),
  `group_name` varchar(255),
  `show_on_front` int(11),
  `letters_count` bigint(21),
  `subscr_count` bigint(21)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_nl_groups_edit`
--

DROP TABLE IF EXISTS `v_nl_groups_edit`;
/*!50001 DROP VIEW IF EXISTS `v_nl_groups_edit`*/;
/*!50001 CREATE TABLE `v_nl_groups_edit` (
  `id` int(11),
  `group_name` varchar(255),
  `show_on_front` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_nl_groups_grid`
--

DROP TABLE IF EXISTS `v_nl_groups_grid`;
/*!50001 DROP VIEW IF EXISTS `v_nl_groups_grid`*/;
/*!50001 CREATE TABLE `v_nl_groups_grid` (
  `id` int(11),
  `group_name` varchar(255),
  `show_on_front` int(11),
  `letters_count` bigint(21),
  `subscr_count` bigint(21)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_nl_notification`
--

DROP TABLE IF EXISTS `v_nl_notification`;
/*!50001 DROP VIEW IF EXISTS `v_nl_notification`*/;
/*!50001 CREATE TABLE `v_nl_notification` (
  `id` int(11),
  `page_name` varchar(50),
  `extension` enum('html','htm','xml'),
  `page_description` varchar(255),
  `default_page` int(11),
  `create_date` timestamp,
  `edit_date` timestamp,
  `tpl_id` int(11),
  `folder_id` int(11),
  `for_search` int(11),
  `owner_name` varchar(45),
  `is_locked` int(11),
  `group_access` int(11),
  `priority` varchar(4),
  `cachable` enum('0','1'),
  `change_freq` enum('always','hourly','daily','weekly','monthly','yearly','never'),
  `subject` longtext,
  `from_email` longtext
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_nl_notification_edit`
--

DROP TABLE IF EXISTS `v_nl_notification_edit`;
/*!50001 DROP VIEW IF EXISTS `v_nl_notification_edit`*/;
/*!50001 CREATE TABLE `v_nl_notification_edit` (
  `id` int(11),
  `notification_type` varchar(50),
  `from_email` longtext
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_nl_notification_grid`
--

DROP TABLE IF EXISTS `v_nl_notification_grid`;
/*!50001 DROP VIEW IF EXISTS `v_nl_notification_grid`*/;
/*!50001 CREATE TABLE `v_nl_notification_grid` (
  `id` int(11),
  `notification_type` varchar(50),
  `subject` longtext,
  `from_email` longtext
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_nl_subscriber`
--

DROP TABLE IF EXISTS `v_nl_subscriber`;
/*!50001 DROP VIEW IF EXISTS `v_nl_subscriber`*/;
/*!50001 CREATE TABLE `v_nl_subscriber` (
  `id` int(11),
  `email` varchar(255),
  `nl_group_id` int(11),
  `reg_date` datetime,
  `last_send` datetime,
  `ip_address` varchar(50),
  `subscriber_status` varchar(50),
  `confirm_code` bigint(20),
  `status` int(2),
  `company` char(255),
  `first_name` varchar(50),
  `sur_name` varchar(50),
  `city` char(255),
  `group_name` varchar(255),
  `language` char(2),
  `letters_count` bigint(21)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_nl_subscribers_edit`
--

DROP TABLE IF EXISTS `v_nl_subscribers_edit`;
/*!50001 DROP VIEW IF EXISTS `v_nl_subscribers_edit`*/;
/*!50001 CREATE TABLE `v_nl_subscribers_edit` (
  `id` int(11),
  `email` varchar(255),
  `group_name` varchar(255),
  `status` varchar(50),
  `company` char(255),
  `first_name` varchar(50),
  `sur_name` varchar(50),
  `city` char(255),
  `language` char(2),
  `ip_address` varchar(50)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_nl_subscribers_grid`
--

DROP TABLE IF EXISTS `v_nl_subscribers_grid`;
/*!50001 DROP VIEW IF EXISTS `v_nl_subscribers_grid`*/;
/*!50001 CREATE TABLE `v_nl_subscribers_grid` (
  `id` int(11),
  `email` varchar(255),
  `status` varchar(50),
  `company` char(255),
  `first_name` varchar(50),
  `sur_name` varchar(50),
  `city` char(255),
  `group_name` varchar(255),
  `language` char(2),
  `reg_date` datetime,
  `last_send` datetime,
  `ip_address` varchar(50)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object`
--

DROP TABLE IF EXISTS `v_object`;
/*!50001 DROP VIEW IF EXISTS `v_object`*/;
/*!50001 CREATE TABLE `v_object` (
  `id` int(11),
  `name` varchar(50)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_content`
--

DROP TABLE IF EXISTS `v_object_content`;
/*!50001 DROP VIEW IF EXISTS `v_object_content`*/;
/*!50001 CREATE TABLE `v_object_content` (
  `object_field_id` int(11),
  `object_record_id` int(11),
  `value` text,
  `language` char(2)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_content_edit`
--

DROP TABLE IF EXISTS `v_object_content_edit`;
/*!50001 DROP VIEW IF EXISTS `v_object_content_edit`*/;
/*!50001 CREATE TABLE `v_object_content_edit` (
  `object_field_id` int(11),
  `object_record_id` int(11),
  `value` text,
  `language` char(2)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_content_grid`
--

DROP TABLE IF EXISTS `v_object_content_grid`;
/*!50001 DROP VIEW IF EXISTS `v_object_content_grid`*/;
/*!50001 CREATE TABLE `v_object_content_grid` (
  `object_field_id` int(11),
  `object_record_id` int(11),
  `value` text,
  `language` char(2),
  `object_name` varchar(50),
  `object_field_name` varchar(50)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_edit`
--

DROP TABLE IF EXISTS `v_object_edit`;
/*!50001 DROP VIEW IF EXISTS `v_object_edit`*/;
/*!50001 CREATE TABLE `v_object_edit` (
  `id` int(11),
  `name` varchar(50)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_field`
--

DROP TABLE IF EXISTS `v_object_field`;
/*!50001 DROP VIEW IF EXISTS `v_object_field`*/;
/*!50001 CREATE TABLE `v_object_field` (
  `id` int(11),
  `object_id` int(11),
  `object_field_name` varchar(50),
  `object_field_type` varchar(20),
  `one_for_all_languages` int(1)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_field_edit`
--

DROP TABLE IF EXISTS `v_object_field_edit`;
/*!50001 DROP VIEW IF EXISTS `v_object_field_edit`*/;
/*!50001 CREATE TABLE `v_object_field_edit` (
  `id` int(11),
  `object_id` int(11),
  `object_field_name` varchar(50),
  `object_field_type` varchar(20),
  `one_for_all_languages` int(1)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_field_grid`
--

DROP TABLE IF EXISTS `v_object_field_grid`;
/*!50001 DROP VIEW IF EXISTS `v_object_field_grid`*/;
/*!50001 CREATE TABLE `v_object_field_grid` (
  `id` int(11),
  `object` varchar(50),
  `object_field_name` varchar(50),
  `object_field_type` varchar(20),
  `one_for_all_languages` int(1)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_field_type`
--

DROP TABLE IF EXISTS `v_object_field_type`;
/*!50001 DROP VIEW IF EXISTS `v_object_field_type`*/;
/*!50001 CREATE TABLE `v_object_field_type` (
  `id` int(11),
  `object_field_type` varchar(20),
  `one_for_all_languages` int(1)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_field_type_edit`
--

DROP TABLE IF EXISTS `v_object_field_type_edit`;
/*!50001 DROP VIEW IF EXISTS `v_object_field_type_edit`*/;
/*!50001 CREATE TABLE `v_object_field_type_edit` (
  `id` int(11),
  `object_field_type` varchar(20),
  `one_for_all_languages` int(1)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_field_type_grid`
--

DROP TABLE IF EXISTS `v_object_field_type_grid`;
/*!50001 DROP VIEW IF EXISTS `v_object_field_type_grid`*/;
/*!50001 CREATE TABLE `v_object_field_type_grid` (
  `id` int(11),
  `object_field_type` varchar(20),
  `one_for_all_languages` varchar(3)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_grid`
--

DROP TABLE IF EXISTS `v_object_grid`;
/*!50001 DROP VIEW IF EXISTS `v_object_grid`*/;
/*!50001 CREATE TABLE `v_object_grid` (
  `id` int(11),
  `name` varchar(50)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_record`
--

DROP TABLE IF EXISTS `v_object_record`;
/*!50001 DROP VIEW IF EXISTS `v_object_record`*/;
/*!50001 CREATE TABLE `v_object_record` (
  `id` int(11),
  `object_id` int(11),
  `last_update` timestamp,
  `user_name` varchar(50)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_record_edit`
--

DROP TABLE IF EXISTS `v_object_record_edit`;
/*!50001 DROP VIEW IF EXISTS `v_object_record_edit`*/;
/*!50001 CREATE TABLE `v_object_record_edit` (
  `id` int(11),
  `object_id` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_record_grid`
--

DROP TABLE IF EXISTS `v_object_record_grid`;
/*!50001 DROP VIEW IF EXISTS `v_object_record_grid`*/;
/*!50001 CREATE TABLE `v_object_record_grid` (
  `id` int(11),
  `object_id` int(11),
  `user_name` varchar(50),
  `last_update` timestamp,
  `name` varchar(50)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_template`
--

DROP TABLE IF EXISTS `v_object_template`;
/*!50001 DROP VIEW IF EXISTS `v_object_template`*/;
/*!50001 CREATE TABLE `v_object_template` (
  `id` int(11),
  `object_id` int(11),
  `template_id` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_template_edit`
--

DROP TABLE IF EXISTS `v_object_template_edit`;
/*!50001 DROP VIEW IF EXISTS `v_object_template_edit`*/;
/*!50001 CREATE TABLE `v_object_template_edit` (
  `id` int(11),
  `object_id` int(11),
  `template_id` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_object_template_grid`
--

DROP TABLE IF EXISTS `v_object_template_grid`;
/*!50001 DROP VIEW IF EXISTS `v_object_template_grid`*/;
/*!50001 CREATE TABLE `v_object_template_grid` (
  `id` int(11),
  `object_name` varchar(50),
  `template_name` varchar(100)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_permanent_redirect_edit`
--

DROP TABLE IF EXISTS `v_permanent_redirect_edit`;
/*!50001 DROP VIEW IF EXISTS `v_permanent_redirect_edit`*/;
/*!50001 CREATE TABLE `v_permanent_redirect_edit` (
  `id` int(11),
  `source_url` varchar(255),
  `target_url` varchar(255),
  `url` char(0),
  `page_id` int(11),
  `lang_code` char(2),
  `t_view` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_permanent_redirect_grid`
--

DROP TABLE IF EXISTS `v_permanent_redirect_grid`;
/*!50001 DROP VIEW IF EXISTS `v_permanent_redirect_grid`*/;
/*!50001 CREATE TABLE `v_permanent_redirect_grid` (
  `id` int(11),
  `source_url` varchar(255),
  `target_url` varchar(255),
  `page_id` int(11),
  `lang_code` char(2),
  `t_view` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_search_tpl_pages`
--

DROP TABLE IF EXISTS `v_search_tpl_pages`;
/*!50001 DROP VIEW IF EXISTS `v_search_tpl_pages`*/;
/*!50001 CREATE TABLE `v_search_tpl_pages` (
  `id` int(11),
  `page_name` varchar(50),
  `extension` enum('html','htm','xml'),
  `page_description` varchar(255),
  `default_page` int(11),
  `create_date` timestamp,
  `edit_date` timestamp,
  `tpl_id` int(11),
  `folder_id` int(11),
  `for_search` int(11),
  `owner_name` varchar(45),
  `is_locked` int(11),
  `group_access` int(11),
  `priority` varchar(4),
  `cachable` enum('0','1'),
  `change_freq` enum('always','hourly','daily','weekly','monthly','yearly','never'),
  `language_code` char(2)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_styles_edit`
--

DROP TABLE IF EXISTS `v_styles_edit`;
/*!50001 DROP VIEW IF EXISTS `v_styles_edit`*/;
/*!50001 CREATE TABLE `v_styles_edit` (
  `id` int(11),
  `element` varchar(50),
  `class` varchar(50),
  `title` varchar(50),
  `declaration` text
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_styles_grid`
--

DROP TABLE IF EXISTS `v_styles_grid`;
/*!50001 DROP VIEW IF EXISTS `v_styles_grid`*/;
/*!50001 CREATE TABLE `v_styles_grid` (
  `id` int(11),
  `element` varchar(50),
  `class` varchar(50),
  `title` varchar(50),
  `sample_text` text
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_file`
--

DROP TABLE IF EXISTS `v_tpl_file`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_file`*/;
/*!50001 CREATE TABLE `v_tpl_file` (
  `id` int(11),
  `file_name` varchar(100),
  `description` text,
  `cachable` enum('0','1')
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_file_edit`
--

DROP TABLE IF EXISTS `v_tpl_file_edit`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_file_edit`*/;
/*!50001 CREATE TABLE `v_tpl_file_edit` (
  `id` int(11),
  `file_name` varchar(100),
  `description` text,
  `cachable` enum('0','1')
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_file_grid`
--

DROP TABLE IF EXISTS `v_tpl_file_grid`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_file_grid`*/;
/*!50001 CREATE TABLE `v_tpl_file_grid` (
  `id` int(11),
  `file_name` varchar(100),
  `description` text,
  `cachable` varchar(3)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_folder`
--

DROP TABLE IF EXISTS `v_tpl_folder`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_folder`*/;
/*!50001 CREATE TABLE `v_tpl_folder` (
  `id` int(11),
  `page_name` varchar(50),
  `page_description` varchar(255),
  `default_page` int(11),
  `create_date` timestamp,
  `edit_date` timestamp,
  `folder_id` int(11),
  `for_search` int(11),
  `owner_name` varchar(45),
  `is_locked` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_folder_content`
--

DROP TABLE IF EXISTS `v_tpl_folder_content`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_folder_content`*/;
/*!50001 CREATE TABLE `v_tpl_folder_content` (
  `id` int(11),
  `page_name` longtext,
  `page_description` varchar(255),
  `default_page` int(11),
  `create_date` timestamp,
  `edit_date` timestamp,
  `folder_id` int(11),
  `for_search` int(11),
  `owner_name` varchar(45),
  `is_locked` int(11),
  `language` char(2)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_folder_edit`
--

DROP TABLE IF EXISTS `v_tpl_folder_edit`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_folder_edit`*/;
/*!50001 CREATE TABLE `v_tpl_folder_edit` (
  `id` int(11),
  `page_name` varchar(50),
  `page_description` varchar(255),
  `create_date` timestamp,
  `edit_date` timestamp,
  `folder_id` int(11),
  `for_search` int(11),
  `owner_name` varchar(45),
  `is_locked` int(11),
  `group_access` int(11),
  `folder_groups` char(0)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_folder_grid`
--

DROP TABLE IF EXISTS `v_tpl_folder_grid`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_folder_grid`*/;
/*!50001 CREATE TABLE `v_tpl_folder_grid` (
  `id` int(11),
  `folder` longtext,
  `folder_description` varchar(255),
  `is_locked` int(11),
  `owner_name` varchar(45),
  `items_count` bigint(21),
  `language` char(2)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_non_folder`
--

DROP TABLE IF EXISTS `v_tpl_non_folder`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_non_folder`*/;
/*!50001 CREATE TABLE `v_tpl_non_folder` (
  `id` int(11),
  `page_name` varchar(50),
  `extension` enum('html','htm','xml'),
  `page_description` varchar(255),
  `default_page` int(11),
  `create_date` timestamp,
  `edit_date` timestamp,
  `tpl_id` int(11),
  `folder_id` int(11),
  `for_search` int(11),
  `owner_name` varchar(45),
  `is_locked` int(11),
  `type` bigint(11),
  `file_name` varchar(100),
  `group_access` int(11),
  `priority` varchar(4),
  `cachable` enum('0','1')
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_non_folder_content`
--

DROP TABLE IF EXISTS `v_tpl_non_folder_content`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_non_folder_content`*/;
/*!50001 CREATE TABLE `v_tpl_non_folder_content` (
  `id` int(11),
  `page_name` longtext,
  `page_description` varchar(255),
  `default_page` int(11),
  `create_date` timestamp,
  `edit_date` timestamp,
  `tpl_id` int(11),
  `folder_id` int(11),
  `for_search` int(11),
  `owner_name` varchar(45),
  `is_locked` int(11),
  `type` bigint(11),
  `file_name` varchar(100),
  `language` char(2),
  `priority` varchar(4)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_non_folder_statistic`
--

DROP TABLE IF EXISTS `v_tpl_non_folder_statistic`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_non_folder_statistic`*/;
/*!50001 CREATE TABLE `v_tpl_non_folder_statistic` (
  `id` int(11),
  `page_name` varchar(50),
  `extension` enum('html','htm','xml'),
  `page_description` varchar(255),
  `default_page` int(11),
  `create_date` timestamp,
  `edit_date` timestamp,
  `tpl_id` int(11),
  `folder_id` int(11),
  `for_search` int(11),
  `owner_name` varchar(45),
  `is_locked` int(11),
  `type` bigint(11),
  `file_name` varchar(100),
  `group_access` int(11),
  `priority` varchar(4),
  `cachable` enum('0','1'),
  `in_draft_state` varchar(3),
  `is_draft_page` varchar(3),
  `publish_date` timestamp,
  `edit_date_draft` timestamp,
  `edit_user` longtext
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_non_folder_without_stat`
--

DROP TABLE IF EXISTS `v_tpl_non_folder_without_stat`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_non_folder_without_stat`*/;
/*!50001 CREATE TABLE `v_tpl_non_folder_without_stat` (
  `id` int(11),
  `type` int(11),
  `file_name` varchar(100),
  `page_description` varchar(255),
  `group_access` int(11),
  `var` varchar(50),
  `var_id` int(11) unsigned,
  `val` text,
  `language` char(2),
  `default_language` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_page`
--

DROP TABLE IF EXISTS `v_tpl_page`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_page`*/;
/*!50001 CREATE TABLE `v_tpl_page` (
  `id` int(11),
  `page_name` varchar(50),
  `extension` enum('html','htm','xml'),
  `page_description` varchar(255),
  `default_page` int(11),
  `create_date` timestamp,
  `edit_date` timestamp,
  `tpl_id` int(11),
  `folder_id` int(11),
  `for_search` int(11),
  `owner_name` varchar(45),
  `is_locked` int(11),
  `type` bigint(11),
  `file_name` varchar(100),
  `group_access` int(11),
  `priority` varchar(4),
  `cachable` enum('0','1')
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_page_content`
--

DROP TABLE IF EXISTS `v_tpl_page_content`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_page_content`*/;
/*!50001 CREATE TABLE `v_tpl_page_content` (
  `id` int(11),
  `page_name` longtext,
  `page_description` varchar(255),
  `default_page` int(11),
  `create_date` timestamp,
  `edit_date` timestamp,
  `tpl_id` int(11),
  `folder_id` int(11),
  `for_search` int(11),
  `owner_name` varchar(45),
  `is_locked` int(11),
  `type` bigint(11),
  `file_name` varchar(100),
  `language` char(2),
  `group_access` int(11),
  `priority` varchar(4),
  `cachable` enum('0','1')
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_page_detail`
--

DROP TABLE IF EXISTS `v_tpl_page_detail`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_page_detail`*/;
/*!50001 CREATE TABLE `v_tpl_page_detail` (
  `id` int(11),
  `page_name` varchar(50),
  `extension` enum('html','htm','xml'),
  `page_description` varchar(255),
  `default_page` int(11),
  `create_date` timestamp,
  `edit_date` timestamp,
  `tpl_id` int(11),
  `folder_id` int(11),
  `for_search` int(11),
  `owner_name` varchar(45),
  `is_locked` int(11),
  `type` bigint(11),
  `file_name` varchar(100),
  `group_access` int(11),
  `priority` varchar(4),
  `cachable` enum('0','1')
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_page_edit`
--

DROP TABLE IF EXISTS `v_tpl_page_edit`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_page_edit`*/;
/*!50001 CREATE TABLE `v_tpl_page_edit` (
  `id` int(11),
  `page_name` varchar(50),
  `extension` enum('html','htm','xml'),
  `page_description` varchar(255),
  `is_default` int(11),
  `template` int(11),
  `folder` int(11),
  `search` int(11),
  `page_locked` int(11),
  `cachable` enum('0','1')
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_page_folder`
--

DROP TABLE IF EXISTS `v_tpl_page_folder`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_page_folder`*/;
/*!50001 CREATE TABLE `v_tpl_page_folder` (
  `id` int(11),
  `page_name` varchar(103),
  `page_description` varchar(255),
  `default_page` int(11),
  `create_date` timestamp,
  `edit_date` timestamp,
  `tpl_id` int(11),
  `folder_id` int(11),
  `for_search` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_page_grid`
--

DROP TABLE IF EXISTS `v_tpl_page_grid`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_page_grid`*/;
/*!50001 CREATE TABLE `v_tpl_page_grid` (
  `id` int(11),
  `page_name` longtext,
  `page_description` varchar(255),
  `template` varchar(104),
  `folder` longtext,
  `is_default` int(11),
  `default_page` varchar(3),
  `for_search` varchar(3),
  `locked` varchar(3),
  `cachable` varchar(3),
  `language` char(2),
  `in_draft_state` varchar(3),
  `edit_date` timestamp,
  `edit_date_draft` timestamp,
  `edit_user` longtext
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_page_not_locked`
--

DROP TABLE IF EXISTS `v_tpl_page_not_locked`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_page_not_locked`*/;
/*!50001 CREATE TABLE `v_tpl_page_not_locked` (
  `id` int(11),
  `page_name` varchar(50),
  `extension` enum('html','htm','xml'),
  `page_description` varchar(255),
  `default_page` int(11),
  `create_date` timestamp,
  `edit_date` timestamp,
  `tpl_id` int(11),
  `folder_id` int(11),
  `for_search` int(11),
  `owner_name` varchar(45),
  `is_locked` int(11),
  `type` bigint(11),
  `file_name` varchar(100),
  `group_access` int(11),
  `priority` varchar(4),
  `cachable` enum('0','1')
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_path_content`
--

DROP TABLE IF EXISTS `v_tpl_path_content`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_path_content`*/;
/*!50001 CREATE TABLE `v_tpl_path_content` (
  `id` int(11),
  `folder` longtext,
  `language` char(2)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_views`
--

DROP TABLE IF EXISTS `v_tpl_views`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_views`*/;
/*!50001 CREATE TABLE `v_tpl_views` (
  `id` int(11),
  `view_name` varchar(100),
  `view_folder` varchar(100),
  `description` text,
  `icon` varchar(150),
  `is_default` enum('1')
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_views_edit`
--

DROP TABLE IF EXISTS `v_tpl_views_edit`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_views_edit`*/;
/*!50001 CREATE TABLE `v_tpl_views_edit` (
  `id` int(11),
  `view_name` varchar(100),
  `view_folder` varchar(100),
  `description` text,
  `icon` varchar(150),
  `is_default` enum('1')
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_tpl_views_grid`
--

DROP TABLE IF EXISTS `v_tpl_views_grid`;
/*!50001 DROP VIEW IF EXISTS `v_tpl_views_grid`*/;
/*!50001 CREATE TABLE `v_tpl_views_grid` (
  `id` int(11),
  `view_name` varchar(100),
  `view_folder` varchar(100),
  `description` text,
  `icon` varchar(150),
  `is_default` enum('1'),
  `default_view` varchar(3)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_user`
--

DROP TABLE IF EXISTS `v_user`;
/*!50001 DROP VIEW IF EXISTS `v_user`*/;
/*!50001 CREATE TABLE `v_user` (
  `id` int(11),
  `name` varchar(150),
  `login` varchar(50),
  `passw` varchar(50),
  `email` varchar(150),
  `status` int(11),
  `role` int(11),
  `content_access` int(11),
  `comment` text,
  `icq` int(11),
  `city` varchar(50),
  `resetpassw` int(11),
  `ip` varchar(20),
  `browser` varchar(50),
  `login_datetime` datetime,
  `month_visits` int(11),
  `passw_update_datetime` datetime
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_user_edit`
--

DROP TABLE IF EXISTS `v_user_edit`;
/*!50001 DROP VIEW IF EXISTS `v_user_edit`*/;
/*!50001 CREATE TABLE `v_user_edit` (
  `id` int(11),
  `name` varchar(150),
  `login` varchar(50),
  `email` varchar(150),
  `status` int(11),
  `comment` text,
  `icq` int(11),
  `city` varchar(50),
  `change_password` char(0),
  `old_password` char(0),
  `new_password` char(0),
  `confirm_new_password` char(0),
  `currently` char(0),
  `ip` varchar(20),
  `browser` varchar(50),
  `last_login` varchar(21),
  `month_visits` int(11),
  `user_groups` char(0),
  `role` int(11),
  `content_access` int(11)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_user_grid`
--

DROP TABLE IF EXISTS `v_user_grid`;
/*!50001 DROP VIEW IF EXISTS `v_user_grid`*/;
/*!50001 CREATE TABLE `v_user_grid` (
  `id` int(11),
  `name` varchar(150),
  `login` varchar(50),
  `email` varchar(150),
  `status` varchar(8),
  `role` int(11),
  `role_name` varchar(50),
  `groups` longtext
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_user_groups`
--

DROP TABLE IF EXISTS `v_user_groups`;
/*!50001 DROP VIEW IF EXISTS `v_user_groups`*/;
/*!50001 CREATE TABLE `v_user_groups` (
  `id` int(11),
  `group_name` varchar(250),
  `group_code` varchar(50)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_user_groups_edit`
--

DROP TABLE IF EXISTS `v_user_groups_edit`;
/*!50001 DROP VIEW IF EXISTS `v_user_groups_edit`*/;
/*!50001 CREATE TABLE `v_user_groups_edit` (
  `id` int(11),
  `group_name` varchar(250),
  `group_code` varchar(50)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_user_groups_grid`
--

DROP TABLE IF EXISTS `v_user_groups_grid`;
/*!50001 DROP VIEW IF EXISTS `v_user_groups_grid`*/;
/*!50001 CREATE TABLE `v_user_groups_grid` (
  `id` int(11),
  `group_name` varchar(250),
  `group_code` varchar(50)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `v_user_profile`
--

DROP TABLE IF EXISTS `v_user_profile`;
/*!50001 DROP VIEW IF EXISTS `v_user_profile`*/;
/*!50001 CREATE TABLE `v_user_profile` (
  `id` int(11),
  `name` varchar(150),
  `email` varchar(150),
  `change_password` char(0),
  `old_password` char(0),
  `new_password` char(0),
  `confirm_new_password` char(0)
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `vbrowser_grid`
--

DROP TABLE IF EXISTS `vbrowser_grid`;
/*!50001 DROP VIEW IF EXISTS `vbrowser_grid`*/;
/*!50001 CREATE TABLE `vbrowser_grid` (
  `id` int(11),
  `page_name` longtext,
  `page_description` varchar(255),
  `template` varchar(104),
  `folder` longtext,
  `is_default` int(11),
  `default_page` varchar(3),
  `for_search` varchar(3),
  `locked` varchar(3),
  `cachable` varchar(3),
  `language` char(2),
  `in_draft_state` varchar(3),
  `edit_date` timestamp,
  `edit_date_draft` timestamp,
  `edit_user` longtext
) ENGINE=MyISAM */;

--
-- Temporary table structure for view `vmbrowser_grid`
--

DROP TABLE IF EXISTS `vmbrowser_grid`;
/*!50001 DROP VIEW IF EXISTS `vmbrowser_grid`*/;
/*!50001 CREATE TABLE `vmbrowser_grid` (
  `id` int(11),
  `media_name` longtext,
  `media_description` varchar(255),
  `template` varchar(104),
  `folder` longtext,
  `edit_date` timestamp,
  `cachable` varchar(3),
  `in_draft_state` varchar(3),
  `language` char(2)
) ENGINE=MyISAM */;

--
-- Final view structure for view `v_channel_db`
--

/*!50001 DROP TABLE `v_channel_db`*/;
/*!50001 DROP VIEW IF EXISTS `v_channel_db`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_channel_db` AS select distinct substr(`c1`.`var`,12,(locate(_utf8'_channel_id',`c1`.`var`) - 12)) AS `id`,`lan`.`language_code` AS `language`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'channel_db_',substr(`content`.`var`,12,(locate(_utf8'_channel_id',`content`.`var`) - 12)),_utf8'_channel_id')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `channel_id`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'channel_db_',substr(`content`.`var`,12,(locate(_utf8'_channel_id',`content`.`var`) - 12)),_utf8'_status')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `status`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'channel_db_',substr(`content`.`var`,12,(locate(_utf8'_channel_id',`content`.`var`) - 12)),_utf8'_author')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `author`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'channel_db_',substr(`content`.`var`,12,(locate(_utf8'_channel_id',`content`.`var`) - 12)),_utf8'_channel_type')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `channel_type`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'channel_db_',substr(`content`.`var`,12,(locate(_utf8'_channel_id',`content`.`var`) - 12)),_utf8'_title')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `title`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'channel_db_',substr(`content`.`var`,12,(locate(_utf8'_channel_id',`content`.`var`) - 12)),_utf8'_description')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `description`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'channel_db_',substr(`content`.`var`,12,(locate(_utf8'_channel_id',`content`.`var`) - 12)),_utf8'_rss')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `rss`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'channel_db_',substr(`content`.`var`,12,(locate(_utf8'_channel_id',`content`.`var`) - 12)),_utf8'_copyright')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `copyright` from (`content` `c1` join `v_language` `lan`) where ((locate(_utf8'_channel_id',`c1`.`var`) > 0) and (locate(_utf8'channel_db_',`c1`.`var`) > 0) and (`lan`.`status` = 1)) */;

--
-- Final view structure for view `v_channel_edit`
--

/*!50001 DROP TABLE `v_channel_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_channel_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_channel_edit` AS select `v_channel_db`.`channel_id` AS `channel_id`,`v_channel_db`.`title` AS `title`,`v_channel_db`.`description` AS `description`,`v_channel_db`.`status` AS `status`,`v_channel_db`.`author` AS `author`,`v_channel_db`.`channel_type` AS `channel_type`,`v_channel_db`.`copyright` AS `copyright`,`v_channel_db`.`rss` AS `rss` from `v_channel_db` */;

--
-- Final view structure for view `v_channel_grid`
--

/*!50001 DROP TABLE `v_channel_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_channel_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_channel_grid` AS select `v_channel_db`.`channel_id` AS `channel_id`,`v_channel_db`.`title` AS `title`,(case `v_channel_db`.`status` when 0 then _latin1'inactive' when 1 then _latin1'active' end) AS `status`,`v_channel_db`.`author` AS `author`,`v_channel_db`.`channel_type` AS `channel_type`,(case `v_channel_db`.`rss` when 0 then _latin1'No' when 1 then _latin1'Yes' end) AS `rss` from `v_channel_db` where (`v_channel_db`.`language` = (select `v_language`.`language_code` AS `language_code` from `v_language` where (`v_language`.`default_language` = 1))) */;

--
-- Final view structure for view `v_dns`
--

/*!50001 DROP TABLE `v_dns`*/;
/*!50001 DROP VIEW IF EXISTS `v_dns`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_dns` AS select `dns`.`id` AS `id`,`dns`.`dns` AS `dns`,`dns`.`comment` AS `comment`,`dns`.`status` AS `status`,`dns`.`language_forwarding` AS `language_forwarding`,`dns`.`draft_mode` AS `draft_mode`,`dns`.`cdn_server` AS `cdn_server` from `dns` */;

--
-- Final view structure for view `v_dns_edit`
--

/*!50001 DROP TABLE `v_dns_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_dns_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_dns_edit` AS select `v_dns`.`id` AS `id`,`v_dns`.`dns` AS `dns`,`v_dns`.`comment` AS `comment`,`v_dns`.`status` AS `status`,`v_dns`.`language_forwarding` AS `language_forwarding`,`v_dns`.`draft_mode` AS `draft_mode`,`v_dns`.`cdn_server` AS `cdn_server` from `v_dns` */;

--
-- Final view structure for view `v_dns_grid`
--

/*!50001 DROP TABLE `v_dns_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_dns_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_dns_grid` AS select `v_dns`.`id` AS `id`,`v_dns`.`dns` AS `dns`,`v_dns`.`comment` AS `comment`,(case `v_dns`.`status` when 1 then _latin1'Enabled' else _latin1'Disabled' end) AS `status`,`v_dns`.`language_forwarding` AS `language_forwarding`,`v_dns`.`draft_mode` AS `draft_mode` from `v_dns` */;

--
-- Final view structure for view `v_events_db`
--

/*!50001 DROP TABLE `v_events_db`*/;
/*!50001 DROP VIEW IF EXISTS `v_events_db`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_events_db` AS select distinct substr(`c1`.`var`,11,(locate(_utf8'_news_id',`c1`.`var`) - 11)) AS `id`,`lan`.`language_code` AS `language`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_news_id')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `news_id`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_title')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `title`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_description')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `description`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_SystemDate')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `SystemDate`,(select if((`content`.`val` <> _utf8''),date_format(`content`.`val`,_latin1'%d.%m.%Y'),_utf8'') AS `IF(val<>'',date_format(val,'%d.%m.%Y'),'')` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_SystemDate')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `SystemDate_d`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_ExpiryDate')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `ExpiryDate`,(select if((`content`.`val` <> _utf8''),date_format(`content`.`val`,_latin1'%d.%m.%Y'),_utf8'') AS `IF(val<>'',date_format(val,'%d.%m.%Y'),'')` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_ExpiryDate')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `ExpiryDate_d`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_DisplayDate')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `DisplayDate`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_PublishedDate')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `PublishedDate`,(select if((`content`.`val` <> _utf8''),date_format(`content`.`val`,_latin1'%d.%m.%Y'),_utf8'') AS `IF(val<>'',date_format(val,'%d.%m.%Y'),'')` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_PublishedDate')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `PublishedDate_d`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_status')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `status`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_channel_id')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `channel_id`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_show_on_home')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `show_on_home`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_category')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `category`,(select (case trim(`content`.`val`) when _latin1'0' then _latin1'draft' when _latin1'1' then _latin1'published' when _latin1'2' then _latin1'archive' end) AS `val` from `content` where ((`content`.`var` = concat(_utf8'events_db_',substr(`content`.`var`,11,(locate(_utf8'_news_id',`content`.`var`) - 11)),_utf8'_status')) and (`content`.`language` in (`lan`.`language_code`,_utf8'EN'))) order by concat(convert((case `content`.`language` when `lan`.`language_code` then _latin1'0' else _latin1'1' end) using utf8),`content`.`language`) limit 1) AS `status_text` from (`content` `c1` join `v_language` `lan`) where ((locate(_utf8'_news_id',`c1`.`var`) > 0) and (locate(_utf8'events_db_',`c1`.`var`) > 0) and (`lan`.`status` = 1)) */;

--
-- Final view structure for view `v_lang_edit`
--

/*!50001 DROP TABLE `v_lang_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_lang_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_lang_edit` AS select `v_language`.`language_code` AS `id`,`v_language`.`language_url` AS `language_url`,`v_language`.`language_name` AS `language_name`,_latin1'' AS `language_link_title`,`v_language`.`l_encode` AS `l_encode`,`v_language`.`paypal_lang` AS `paypal_lang`,`v_language`.`status` AS `status`,`v_language`.`default_language` AS `is_default` from `v_language` */;

--
-- Final view structure for view `v_lang_grid`
--

/*!50001 DROP TABLE `v_lang_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_lang_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_lang_grid` AS select `v_language`.`language_code` AS `language_code`,`v_language`.`language_url` AS `language_url`,`v_language`.`language_name` AS `language_name`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = concat(_utf8'ee_lang_title_',`v_language`.`language_code`)) and (`content`.`language` = (select `v_language`.`language_code` AS `language_code` from `v_language` where (`v_language`.`default_language` = _latin1'1')))) limit 0,1) AS `language_link_title`,`v_language`.`l_encode` AS `l_encode`,`v_language`.`paypal_lang` AS `paypal_lang`,(case `v_language`.`status` when 1 then _latin1'Enabled' else _latin1'Disabled' end) AS `status`,(case `v_language`.`default_language` when 1 then _latin1'Yes' else _latin1'' end) AS `default_language` from `v_language` */;

--
-- Final view structure for view `v_language`
--

/*!50001 DROP TABLE `v_language`*/;
/*!50001 DROP VIEW IF EXISTS `v_language`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_language` AS select `language`.`language_code` AS `language_code`,`language`.`language_url` AS `language_url`,`language`.`language_name` AS `language_name`,`language`.`l_encode` AS `l_encode`,`language`.`paypal_lang` AS `paypal_lang`,`language`.`language_of_browser` AS `language_of_browser`,`language`.`status` AS `status`,`language`.`default_language` AS `default_language` from `language` where (`language`.`language_code` <> _utf8'') */;

--
-- Final view structure for view `v_mail_inbox_edit`
--

/*!50001 DROP TABLE `v_mail_inbox_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_mail_inbox_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_mail_inbox_edit` AS select `mail_inbox`.`id` AS `id`,`mail_inbox`.`name` AS `name`,`mail_inbox`.`email` AS `email`,date_format(`mail_inbox`.`send_date`,_latin1'%d.%m.%Y %H:%i') AS `send_date`,`mail_inbox`.`add_info` AS `add_info` from `mail_inbox` */;

--
-- Final view structure for view `v_mail_inbox_grid`
--

/*!50001 DROP TABLE `v_mail_inbox_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_mail_inbox_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_mail_inbox_grid` AS select `mail_inbox`.`id` AS `id`,`mail_inbox`.`name` AS `name`,`mail_inbox`.`email` AS `email`,`mail_inbox`.`send_date` AS `send_date`,`mail_inbox`.`message` AS `message`,`mail_inbox`.`add_info` AS `add_info`,(case `mail_inbox`.`viewed` when 1 then _latin1'Yes' else _latin1'No' end) AS `viewed` from `mail_inbox` */;

--
-- Final view structure for view `v_mailing_edit`
--

/*!50001 DROP TABLE `v_mailing_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_mailing_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_mailing_edit` AS select `v_ms_mail`.`id` AS `id`,`v_ms_mail`.`original_id` AS `original_id`,`v_ms_mail`.`subject` AS `subject`,`v_ms_mail`.`date_reg` AS `date_reg`,`v_ms_mail`.`from_` AS `from_`,`v_ms_mail`.`status` AS `status`,`v_ms_mail`.`recipients_count` AS `recipients_count` from `v_ms_mail` */;

--
-- Final view structure for view `v_mailing_grid`
--

/*!50001 DROP TABLE `v_mailing_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_mailing_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_mailing_grid` AS select `v_mailing_edit`.`id` AS `id`,`v_mailing_edit`.`original_id` AS `original_id`,`v_mailing_edit`.`subject` AS `subject`,`v_mailing_edit`.`date_reg` AS `date_reg`,`v_mailing_edit`.`from_` AS `from_`,`v_mailing_edit`.`status` AS `status`,`v_mailing_edit`.`recipients_count` AS `recipients_count` from `v_mailing_edit` */;

--
-- Final view structure for view `v_media`
--

/*!50001 DROP TABLE `v_media`*/;
/*!50001 DROP VIEW IF EXISTS `v_media`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_media` AS select `v_tpl_non_folder`.`id` AS `id`,`v_tpl_non_folder`.`page_name` AS `page_name`,`v_tpl_non_folder`.`extension` AS `extension`,`v_tpl_non_folder`.`page_description` AS `page_description`,`v_tpl_non_folder`.`default_page` AS `default_page`,`v_tpl_non_folder`.`create_date` AS `create_date`,`v_tpl_non_folder`.`edit_date` AS `edit_date`,`v_tpl_non_folder`.`tpl_id` AS `tpl_id`,`v_tpl_non_folder`.`folder_id` AS `folder_id`,`v_tpl_non_folder`.`for_search` AS `for_search`,`v_tpl_non_folder`.`owner_name` AS `owner_name`,`v_tpl_non_folder`.`is_locked` AS `is_locked`,`v_tpl_non_folder`.`type` AS `type`,`v_tpl_non_folder`.`file_name` AS `file_name`,`v_tpl_non_folder`.`group_access` AS `group_access`,`v_tpl_non_folder`.`priority` AS `priority`,`v_tpl_non_folder`.`cachable` AS `cachable` from `v_tpl_non_folder` where (`v_tpl_non_folder`.`type` = 1) */;

--
-- Final view structure for view `v_media_content`
--

/*!50001 DROP TABLE `v_media_content`*/;
/*!50001 DROP VIEW IF EXISTS `v_media_content`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_media_content` AS select `v_tpl_non_folder`.`id` AS `id`,if(isnull(`regular_content`.`val`),if(isnull(`default_content`.`val`),`v_tpl_non_folder`.`page_name`,`default_content`.`val`),`regular_content`.`val`) AS `page_name`,`v_tpl_non_folder`.`page_description` AS `page_description`,`v_tpl_non_folder`.`default_page` AS `default_page`,`v_tpl_non_folder`.`create_date` AS `create_date`,`v_tpl_non_folder`.`edit_date` AS `edit_date`,`v_tpl_non_folder`.`tpl_id` AS `tpl_id`,`v_tpl_non_folder`.`folder_id` AS `folder_id`,`v_tpl_non_folder`.`for_search` AS `for_search`,`v_tpl_non_folder`.`owner_name` AS `owner_name`,`v_tpl_non_folder`.`is_locked` AS `is_locked`,`v_tpl_non_folder`.`type` AS `type`,`v_tpl_non_folder`.`file_name` AS `file_name`,`v_tpl_non_folder`.`cachable` AS `cachable`,`language`.`language_code` AS `language` from (((`v_tpl_non_folder` join `v_language` `language`) left join `content` `regular_content` on(((`v_tpl_non_folder`.`id` = `regular_content`.`var_id`) and (`regular_content`.`var` = _utf8'page_name_') and (`regular_content`.`language` = `language`.`language_code`)))) left join `content` `default_content` on(((`v_tpl_non_folder`.`id` = `default_content`.`var_id`) and (`default_content`.`var` = _utf8'page_name_') and (`default_content`.`language` = (select `language`.`language_code` AS `language_code` from `language` where (`language`.`default_language` = 1)))))) where (`v_tpl_non_folder`.`type` = 1) */;

--
-- Final view structure for view `v_media_edit`
--

/*!50001 DROP TABLE `v_media_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_media_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_media_edit` AS select `v_media`.`id` AS `id`,`v_media`.`page_name` AS `page_name`,`v_media`.`page_description` AS `media_description`,`v_media`.`tpl_id` AS `template`,`v_media`.`folder_id` AS `folder`,_latin1'' AS `size`,_latin1'' AS `alt_tag`,_latin1'' AS `zip_file_name`,`v_media`.`cachable` AS `cachable` from `v_media` */;

--
-- Final view structure for view `v_media_file`
--

/*!50001 DROP TABLE `v_media_file`*/;
/*!50001 DROP VIEW IF EXISTS `v_media_file`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_media_file` AS select `tpl_files`.`id` AS `id`,`tpl_files`.`file_name` AS `file_name`,`tpl_files`.`type` AS `type`,`tpl_files`.`description` AS `description`,`tpl_files`.`cachable` AS `cachable` from `tpl_files` where (`tpl_files`.`type` = _latin1'1') */;

--
-- Final view structure for view `v_media_grid`
--

/*!50001 DROP TABLE `v_media_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_media_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_media_grid` AS select `v_media_content`.`id` AS `id`,concat(`v_media_content`.`page_name`,convert((case when (`v_media_content`.`default_page` > 0) then _latin1' ( default )' else _latin1'' end) using utf8)) AS `media_name`,`v_media_content`.`page_description` AS `media_description`,concat(`v_media_content`.`file_name`,_latin1'.tpl') AS `template`,concat(_utf8'/',if(isnull(`v_tpl_path_content`.`folder`),_utf8'',`v_tpl_path_content`.`folder`)) AS `folder`,`v_media_content`.`edit_date` AS `edit_date`,(case `v_media_content`.`cachable` when _latin1'1' then _latin1'Yes' else _latin1'No' end) AS `cachable`,(case (select count(0) AS `COUNT(*)` from `content` where (((`content`.`val` <> (`content`.`val_draft` collate utf8_bin)) or isnull(`content`.`val`)) and (`content`.`val_draft` is not null) and (`content`.`var` = _utf8'media_') and (`content`.`var_id` = `v_media_content`.`id`))) when 0 then _latin1'No' else _latin1'Yes' end) AS `in_draft_state`,`v_media_content`.`language` AS `language` from (`v_media_content` left join `v_tpl_path_content` on((((`v_media_content`.`folder_id` = `v_tpl_path_content`.`id`) and (`v_media_content`.`language` = `v_tpl_path_content`.`language`)) or isnull(`v_tpl_path_content`.`id`)))) */;

--
-- Final view structure for view `v_ms_mail`
--

/*!50001 DROP TABLE `v_ms_mail`*/;
/*!50001 DROP VIEW IF EXISTS `v_ms_mail`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ms_mail` AS select `ms_mail`.`id` AS `id`,`ms_mail`.`original_id` AS `original_id`,`ms_mail`.`subject` AS `subject`,`ms_mail`.`date_reg` AS `date_reg`,`ms_mail`.`body` AS `body`,concat(`ms_mail`.`from_name`,_latin1' (',`ms_mail`.`from_email`,_latin1')') AS `from_`,(select `ms_status`.`status` AS `status` from `ms_status` where (`ms_status`.`id` = `ms_mail`.`ms_status_id`)) AS `status`,concat((select rtrim(cast(count(0) as char charset latin1)) AS `rtrim(cast(COUNT(*) AS char))` from `ms_recipient` `recip1` where (`recip1`.`ms_mail_id` = `ms_mail`.`id`)),_latin1' / ',(select rtrim(cast(count(0) as char charset latin1)) AS `rtrim(cast(COUNT(*) AS char))` from `ms_recipient` `recip2` where ((`recip2`.`ms_mail_id` = `ms_mail`.`id`) and (`recip2`.`ms_status_id` = 3)))) AS `recipients_count` from `ms_mail` */;

--
-- Final view structure for view `v_ms_recipient`
--

/*!50001 DROP TABLE `v_ms_recipient`*/;
/*!50001 DROP VIEW IF EXISTS `v_ms_recipient`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ms_recipient` AS select `ms_recipient`.`id` AS `id`,`ms_recipient`.`ms_mail_id` AS `ms_mail_id`,`ms_recipient`.`recipient` AS `recipient`,`ms_recipient`.`date_update` AS `date_update`,(select `ms_status`.`status` AS `status` from `ms_status` where (`ms_status`.`id` = `ms_recipient`.`ms_status_id`)) AS `status`,`ms_recipient`.`recipient_id` AS `recipient_id` from `ms_recipient` */;

--
-- Final view structure for view `v_news_edit`
--

/*!50001 DROP TABLE `v_news_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_news_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_news_edit` AS select `v_events_db`.`news_id` AS `news_id`,`v_events_db`.`title` AS `title`,`v_events_db`.`description` AS `description`,`v_events_db`.`status` AS `status`,`v_events_db`.`category` AS `category`,`v_events_db`.`show_on_home` AS `show_on_home`,`v_events_db`.`channel_id` AS `channel_id`,`v_events_db`.`SystemDate` AS `SystemDate`,`v_events_db`.`ExpiryDate` AS `ExpiryDate`,`v_events_db`.`PublishedDate` AS `PublishedDate` from `v_events_db` where (`v_events_db`.`language` = (select `language`.`language_code` AS `language_code` from `language` where (`language`.`default_language` = 1))) */;

--
-- Final view structure for view `v_news_grid`
--

/*!50001 DROP TABLE `v_news_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_news_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_news_grid` AS select `v_events_db`.`news_id` AS `news_id`,`v_events_db`.`title` AS `title`,(case `v_events_db`.`status` when 0 then _latin1'draft' when 1 then _latin1'published' when 2 then _latin1'archive' end) AS `status`,`v_events_db`.`category` AS `category`,`v_events_db`.`channel_id` AS `channel_id`,`v_events_db`.`SystemDate` AS `SystemDate`,`v_events_db`.`ExpiryDate` AS `ExpiryDate`,`v_events_db`.`PublishedDate` AS `PublishedDate` from `v_events_db` where (`v_events_db`.`language` = (select `language`.`language_code` AS `language_code` from `language` where (`language`.`default_language` = 1))) */;

--
-- Final view structure for view `v_news_letters_edit`
--

/*!50001 DROP TABLE `v_news_letters_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_news_letters_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_news_letters_edit` AS select `nl_email`.`id` AS `id`,`nl_email`.`from_name` AS `email_from_name`,`nl_email`.`from_email` AS `email_from_email`,ifnull(`content`.`val`,convert(`nl_email`.`subject` using utf8)) AS `email_subject`,`nl_email`.`tpl` AS `email_tpl`,`nl_email`.`body` AS `email_body`,`nl_email`.`header` AS `email_header`,(select count(0) AS `COUNT(*)` from `nl_email_group` where (`nl_email_group`.`nl_email_id` = `nl_email`.`id`)) AS `group_count`,(select count(0) AS `COUNT(*)` from `nl_subscriber` where `nl_subscriber`.`nl_group_id` in (select `nl_email_group`.`nl_group_id` AS `nl_group_id` from `nl_email_group` where (`nl_email_group`.`nl_email_id` = `nl_email`.`id`))) AS `subscr_count`,(case when ((select count(0) AS `COUNT(*)` from `nl_email_group` where (`nl_email_group`.`nl_email_id` = `nl_email`.`id`)) = 0) then _latin1'draft' else (case when ((select `ms_mail`.`ms_status_id` AS `ms_status_id` from `ms_mail` where (`ms_mail`.`id` = `nl_email`.`transaction_id`)) = 3) then _latin1'sent' else (case when ((select `ms_mail`.`ms_status_id` AS `ms_status_id` from `ms_mail` where (`ms_mail`.`id` = `nl_email`.`transaction_id`)) = 6) then _latin1'archive' else _latin1'outbox' end) end) end) AS `email_status`,`nl_email`.`transaction_id` AS `email_transaction_id`,(case when (`nl_email`.`finish_date` = NULL) then (select date_format((date_format(now(),_latin1'%Y-%m-%d') + interval (select `config`.`val` AS `val` from `config` where (`config`.`var` = _utf8'default_active_period')) day),_latin1'%d-%m-%Y') AS `date_format(DATE_ADD(date_format(now(), '%Y-%m-%d'),INTERVAL (select val from config where var = 'default_active_period') DAY), '%d-%m-%Y')`) else `nl_email`.`finish_date` end) AS `finish_date`,`nl_email`.`ip_address` AS `ip_address`,`nl_email`.`create_date` AS `create_date` from (`nl_email` left join (`content` join `language` on(((`content`.`language` = `language`.`language_code`) and (`language`.`default_language` = 1)))) on(((`nl_email`.`id` = `content`.`var_id`) and (`content`.`var` = _utf8'news_letter_subject_')))) */;

--
-- Final view structure for view `v_news_letters_grid`
--

/*!50001 DROP TABLE `v_news_letters_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_news_letters_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_news_letters_grid` AS select `v_news_letters_edit`.`id` AS `id`,`v_news_letters_edit`.`email_from_name` AS `from_name`,`v_news_letters_edit`.`email_from_email` AS `from_email`,`v_news_letters_edit`.`email_subject` AS `subject`,`v_news_letters_edit`.`email_status` AS `status`,date_format(`v_news_letters_edit`.`finish_date`,_latin1'%d-%m-%Y') AS `Finish Date`,`v_news_letters_edit`.`ip_address` AS `ip_address`,`v_news_letters_edit`.`create_date` AS `create_date` from `v_news_letters_edit` */;

--
-- Final view structure for view `v_nl_email`
--

/*!50001 DROP TABLE `v_nl_email`*/;
/*!50001 DROP VIEW IF EXISTS `v_nl_email`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_nl_email` AS select `nl_email`.`id` AS `email_id`,`nl_email`.`from_name` AS `email_from_name`,`nl_email`.`from_email` AS `email_from_email`,`nl_email`.`subject` AS `email_subject`,`nl_email`.`tpl` AS `email_tpl`,`nl_email`.`body` AS `email_body`,`nl_email`.`header` AS `email_header`,(select count(0) AS `COUNT(*)` from `nl_email_group` where (`nl_email_group`.`nl_email_id` = `nl_email`.`id`)) AS `group_count`,(select count(0) AS `COUNT(*)` from `nl_subscriber` where `nl_subscriber`.`nl_group_id` in (select `nl_email_group`.`nl_group_id` AS `nl_group_id` from `nl_email_group` where (`nl_email_group`.`nl_email_id` = `nl_email`.`id`))) AS `subscr_count`,(case when ((select count(0) AS `COUNT(*)` from `nl_email_group` where (`nl_email_group`.`nl_email_id` = `nl_email`.`id`)) = 0) then _latin1'draft' else (case when ((select `ms_mail`.`ms_status_id` AS `ms_status_id` from `ms_mail` where (`ms_mail`.`id` = `nl_email`.`transaction_id`)) = 3) then _latin1'sent' else _latin1'outbox' end) end) AS `email_status`,`nl_email`.`transaction_id` AS `email_transaction_id`,(case when (`nl_email`.`finish_date` = NULL) then (select date_format((date_format(now(),_latin1'%Y-%m-%d') + interval (select `config`.`val` AS `val` from `config` where (`config`.`var` = _utf8'default_active_period')) day),_latin1'%d-%m-%Y') AS `date_format(DATE_ADD(date_format(now(), '%Y-%m-%d'),INTERVAL (select val from config where var = 'default_active_period') DAY), '%d-%m-%Y')`) else `nl_email`.`finish_date` end) AS `finish_date`,`nl_email`.`ip_address` AS `ip_address`,`nl_email`.`create_date` AS `create_date` from `nl_email` */;

--
-- Final view structure for view `v_nl_email_edit`
--

/*!50001 DROP TABLE `v_nl_email_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_nl_email_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_nl_email_edit` AS select `v_nl_email`.`email_id` AS `email_id`,`v_nl_email`.`email_from_name` AS `email_from_name`,`v_nl_email`.`email_from_email` AS `email_from_email`,`v_nl_email`.`email_subject` AS `email_subject`,`v_nl_email`.`email_tpl` AS `email_tpl`,`v_nl_email`.`email_body` AS `email_body`,`v_nl_email`.`email_header` AS `email_header`,`v_nl_email`.`group_count` AS `group_count`,`v_nl_email`.`subscr_count` AS `subscr_count`,`v_nl_email`.`email_status` AS `email_status`,`v_nl_email`.`email_transaction_id` AS `email_transaction_id`,`v_nl_email`.`finish_date` AS `finish_date`,`v_nl_email`.`ip_address` AS `ip_address`,`v_nl_email`.`create_date` AS `create_date` from `v_nl_email` */;

--
-- Final view structure for view `v_nl_email_grid`
--

/*!50001 DROP TABLE `v_nl_email_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_nl_email_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_nl_email_grid` AS select `v_nl_email`.`email_id` AS `email_id`,`v_nl_email`.`email_from_name` AS `email_from_name`,`v_nl_email`.`email_from_email` AS `email_from_email`,`v_nl_email`.`email_subject` AS `email_subject`,`v_nl_email`.`email_header` AS `email_header`,`v_nl_email`.`email_status` AS `email_status`,`v_nl_email`.`finish_date` AS `finish_date`,`v_nl_email`.`ip_address` AS `ip_address`,`v_nl_email`.`create_date` AS `create_date` from `v_nl_email` */;

--
-- Final view structure for view `v_nl_group`
--

/*!50001 DROP TABLE `v_nl_group`*/;
/*!50001 DROP VIEW IF EXISTS `v_nl_group`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_nl_group` AS select `nl_group`.`id` AS `id`,`nl_group`.`group_name` AS `group_name`,`nl_group`.`show_on_front` AS `show_on_front`,(select count(0) AS `COUNT(*)` from `nl_email_group` where (`nl_email_group`.`nl_group_id` = `nl_group`.`id`)) AS `letters_count`,(select count(0) AS `COUNT(*)` from `nl_subscriber` where ((`nl_subscriber`.`nl_group_id` = `nl_group`.`id`) and (`nl_subscriber`.`status` in (1,3)))) AS `subscr_count` from `nl_group` */;

--
-- Final view structure for view `v_nl_groups_edit`
--

/*!50001 DROP TABLE `v_nl_groups_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_nl_groups_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_nl_groups_edit` AS select `nl_group`.`id` AS `id`,`nl_group`.`group_name` AS `group_name`,`nl_group`.`show_on_front` AS `show_on_front` from `nl_group` */;

--
-- Final view structure for view `v_nl_groups_grid`
--

/*!50001 DROP TABLE `v_nl_groups_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_nl_groups_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_nl_groups_grid` AS select `v_nl_group`.`id` AS `id`,`v_nl_group`.`group_name` AS `group_name`,`v_nl_group`.`show_on_front` AS `show_on_front`,`v_nl_group`.`letters_count` AS `letters_count`,`v_nl_group`.`subscr_count` AS `subscr_count` from `v_nl_group` */;

--
-- Final view structure for view `v_nl_notification`
--

/*!50001 DROP TABLE `v_nl_notification`*/;
/*!50001 DROP VIEW IF EXISTS `v_nl_notification`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_nl_notification` AS select `p`.`id` AS `id`,`p`.`page_name` AS `page_name`,`p`.`extension` AS `extension`,`p`.`page_description` AS `page_description`,`p`.`default_page` AS `default_page`,`p`.`create_date` AS `create_date`,`p`.`edit_date` AS `edit_date`,`p`.`tpl_id` AS `tpl_id`,`p`.`folder_id` AS `folder_id`,`p`.`for_search` AS `for_search`,`p`.`owner_name` AS `owner_name`,`p`.`is_locked` AS `is_locked`,`p`.`group_access` AS `group_access`,`p`.`priority` AS `priority`,`p`.`cachable` AS `cachable`,`p`.`change_freq` AS `change_freq`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = _utf8'nl_notification_subject') and (`content`.`page_id` = `p`.`id`) and (`content`.`language` = (select `language`.`language_code` AS `language_code` from `language` where (`language`.`default_language` = 1)))) limit 1) AS `subject`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = _utf8'nl_notification_from_email') and (`content`.`page_id` = `p`.`id`)) limit 1) AS `from_email` from (`tpl_pages` `p` left join `tpl_files` `f` on((`p`.`tpl_id` = `f`.`id`))) where (`f`.`type` = _latin1'2') */;

--
-- Final view structure for view `v_nl_notification_edit`
--

/*!50001 DROP TABLE `v_nl_notification_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_nl_notification_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_nl_notification_edit` AS select `v_nl_notification`.`id` AS `id`,`v_nl_notification`.`page_name` AS `notification_type`,`v_nl_notification`.`from_email` AS `from_email` from `v_nl_notification` */;

--
-- Final view structure for view `v_nl_notification_grid`
--

/*!50001 DROP TABLE `v_nl_notification_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_nl_notification_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_nl_notification_grid` AS select `v_nl_notification`.`id` AS `id`,`v_nl_notification`.`page_name` AS `notification_type`,`v_nl_notification`.`subject` AS `subject`,`v_nl_notification`.`from_email` AS `from_email` from `v_nl_notification` */;

--
-- Final view structure for view `v_nl_subscriber`
--

/*!50001 DROP TABLE `v_nl_subscriber`*/;
/*!50001 DROP VIEW IF EXISTS `v_nl_subscriber`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_nl_subscriber` AS select `nl_subscriber`.`id` AS `id`,`nl_subscriber`.`email` AS `email`,`nl_subscriber`.`nl_group_id` AS `nl_group_id`,`nl_subscriber`.`reg_date` AS `reg_date`,(select max(`v`.`date_update`) AS `max(date_update)` from `v_ms_recipient` `v` where ((`v`.`status` = _latin1'sent') and (`v`.`recipient_id` = `nl_subscriber`.`id`))) AS `last_send`,`nl_subscriber`.`ip_address` AS `ip_address`,`nl_subscriber_status`.`status` AS `subscriber_status`,`nl_subscriber`.`confirm_code` AS `confirm_code`,`nl_subscriber`.`status` AS `status`,`nl_subscriber`.`company` AS `company`,`nl_subscriber`.`first_name` AS `first_name`,`nl_subscriber`.`sur_name` AS `sur_name`,`nl_subscriber`.`city` AS `city`,(select `nl_group`.`group_name` AS `group_name` from `nl_group` where (`nl_group`.`id` = `nl_subscriber`.`nl_group_id`)) AS `group_name`,`nl_subscriber`.`language` AS `language`,(select count(0) AS `COUNT(*)` from `nl_email_group` where (`nl_email_group`.`nl_group_id` = `nl_subscriber`.`nl_group_id`)) AS `letters_count` from (`nl_subscriber` left join `nl_subscriber_status` on((`nl_subscriber`.`status` = `nl_subscriber_status`.`id`))) */;

--
-- Final view structure for view `v_nl_subscribers_edit`
--

/*!50001 DROP TABLE `v_nl_subscribers_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_nl_subscribers_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_nl_subscribers_edit` AS select `v_nl_subscriber`.`id` AS `id`,`v_nl_subscriber`.`email` AS `email`,`v_nl_subscriber`.`group_name` AS `group_name`,`v_nl_subscriber`.`subscriber_status` AS `status`,`v_nl_subscriber`.`company` AS `company`,`v_nl_subscriber`.`first_name` AS `first_name`,`v_nl_subscriber`.`sur_name` AS `sur_name`,`v_nl_subscriber`.`city` AS `city`,`v_nl_subscriber`.`language` AS `language`,`v_nl_subscriber`.`ip_address` AS `ip_address` from `v_nl_subscriber` */;

--
-- Final view structure for view `v_nl_subscribers_grid`
--

/*!50001 DROP TABLE `v_nl_subscribers_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_nl_subscribers_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_nl_subscribers_grid` AS select `v_nl_subscriber`.`id` AS `id`,`v_nl_subscriber`.`email` AS `email`,`v_nl_subscriber`.`subscriber_status` AS `status`,`v_nl_subscriber`.`company` AS `company`,`v_nl_subscriber`.`first_name` AS `first_name`,`v_nl_subscriber`.`sur_name` AS `sur_name`,`v_nl_subscriber`.`city` AS `city`,`v_nl_subscriber`.`group_name` AS `group_name`,`v_nl_subscriber`.`language` AS `language`,`v_nl_subscriber`.`reg_date` AS `reg_date`,`v_nl_subscriber`.`last_send` AS `last_send`,`v_nl_subscriber`.`ip_address` AS `ip_address` from `v_nl_subscriber` */;

--
-- Final view structure for view `v_object`
--

/*!50001 DROP TABLE `v_object`*/;
/*!50001 DROP VIEW IF EXISTS `v_object`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object` AS select `object`.`id` AS `id`,`object`.`name` AS `name` from `object` */;

--
-- Final view structure for view `v_object_content`
--

/*!50001 DROP TABLE `v_object_content`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_content`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_content` AS select `object_content`.`object_field_id` AS `object_field_id`,`object_content`.`object_record_id` AS `object_record_id`,`object_content`.`value` AS `value`,`object_content`.`language` AS `language` from `object_content` */;

--
-- Final view structure for view `v_object_content_edit`
--

/*!50001 DROP TABLE `v_object_content_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_content_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_content_edit` AS select `object_content`.`object_field_id` AS `object_field_id`,`object_content`.`object_record_id` AS `object_record_id`,`object_content`.`value` AS `value`,`object_content`.`language` AS `language` from `object_content` */;

--
-- Final view structure for view `v_object_content_grid`
--

/*!50001 DROP TABLE `v_object_content_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_content_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_content_grid` AS select `object_content`.`object_field_id` AS `object_field_id`,`object_content`.`object_record_id` AS `object_record_id`,`object_content`.`value` AS `value`,`object_content`.`language` AS `language`,`object`.`name` AS `object_name`,`object_field`.`object_field_name` AS `object_field_name` from ((`object_content` join `object_field` on((`object_content`.`object_field_id` = `object_field`.`id`))) join `object` on((`object_field`.`object_id` = `object`.`id`))) order by `object_content`.`object_record_id` */;

--
-- Final view structure for view `v_object_edit`
--

/*!50001 DROP TABLE `v_object_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_edit` AS select `object`.`id` AS `id`,`object`.`name` AS `name` from `object` */;

--
-- Final view structure for view `v_object_field`
--

/*!50001 DROP TABLE `v_object_field`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_field`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_field` AS select `object_field`.`id` AS `id`,`object_field`.`object_id` AS `object_id`,`object_field`.`object_field_name` AS `object_field_name`,`object_field`.`object_field_type` AS `object_field_type`,`object_field`.`one_for_all_languages` AS `one_for_all_languages` from `object_field` */;

--
-- Final view structure for view `v_object_field_edit`
--

/*!50001 DROP TABLE `v_object_field_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_field_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_field_edit` AS select `object_field`.`id` AS `id`,`object_field`.`object_id` AS `object_id`,`object_field`.`object_field_name` AS `object_field_name`,`object_field`.`object_field_type` AS `object_field_type`,`object_field`.`one_for_all_languages` AS `one_for_all_languages` from `object_field` */;

--
-- Final view structure for view `v_object_field_grid`
--

/*!50001 DROP TABLE `v_object_field_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_field_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_field_grid` AS select `f`.`id` AS `id`,(select `o`.`name` AS `name` from `object` `o` where (`o`.`id` = `f`.`object_id`)) AS `object`,`f`.`object_field_name` AS `object_field_name`,`f`.`object_field_type` AS `object_field_type`,`f`.`one_for_all_languages` AS `one_for_all_languages` from `object_field` `f` */;

--
-- Final view structure for view `v_object_field_type`
--

/*!50001 DROP TABLE `v_object_field_type`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_field_type`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_field_type` AS select `object_field_type`.`id` AS `id`,`object_field_type`.`object_field_type` AS `object_field_type`,`object_field_type`.`one_for_all_languages` AS `one_for_all_languages` from `object_field_type` */;

--
-- Final view structure for view `v_object_field_type_edit`
--

/*!50001 DROP TABLE `v_object_field_type_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_field_type_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_field_type_edit` AS select `v_object_field_type`.`id` AS `id`,`v_object_field_type`.`object_field_type` AS `object_field_type`,`v_object_field_type`.`one_for_all_languages` AS `one_for_all_languages` from `v_object_field_type` */;

--
-- Final view structure for view `v_object_field_type_grid`
--

/*!50001 DROP TABLE `v_object_field_type_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_field_type_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_field_type_grid` AS select `v_object_field_type`.`id` AS `id`,`v_object_field_type`.`object_field_type` AS `object_field_type`,(case `v_object_field_type`.`one_for_all_languages` when 1 then _latin1'YES' else _latin1'' end) AS `one_for_all_languages` from `v_object_field_type` */;

--
-- Final view structure for view `v_object_grid`
--

/*!50001 DROP TABLE `v_object_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_grid` AS select `object`.`id` AS `id`,`object`.`name` AS `name` from `object` */;

--
-- Final view structure for view `v_object_record`
--

/*!50001 DROP TABLE `v_object_record`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_record`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_record` AS select `object_record`.`id` AS `id`,`object_record`.`object_id` AS `object_id`,`object_record`.`last_update` AS `last_update`,`object_record`.`user_name` AS `user_name` from `object_record` */;

--
-- Final view structure for view `v_object_record_edit`
--

/*!50001 DROP TABLE `v_object_record_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_record_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_record_edit` AS select `object_record`.`id` AS `id`,`object_record`.`object_id` AS `object_id` from `object_record` */;

--
-- Final view structure for view `v_object_record_grid`
--

/*!50001 DROP TABLE `v_object_record_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_record_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_record_grid` AS select `object_record`.`id` AS `id`,`object_record`.`object_id` AS `object_id`,`object_record`.`user_name` AS `user_name`,`object_record`.`last_update` AS `last_update`,`object`.`name` AS `name` from (`object_record` join `object` on((`object_record`.`object_id` = `object`.`id`))) order by `object_record`.`id` */;

--
-- Final view structure for view `v_object_template`
--

/*!50001 DROP TABLE `v_object_template`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_template`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_template` AS select `object_template`.`id` AS `id`,`object_template`.`object_id` AS `object_id`,`object_template`.`template_id` AS `template_id` from `object_template` */;

--
-- Final view structure for view `v_object_template_edit`
--

/*!50001 DROP TABLE `v_object_template_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_template_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_template_edit` AS select `v_object_template`.`id` AS `id`,`v_object_template`.`object_id` AS `object_id`,`v_object_template`.`template_id` AS `template_id` from `v_object_template` */;

--
-- Final view structure for view `v_object_template_grid`
--

/*!50001 DROP TABLE `v_object_template_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_object_template_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_object_template_grid` AS select `v_object_template`.`id` AS `id`,`v_object`.`name` AS `object_name`,`tpl_files`.`file_name` AS `template_name` from ((`v_object_template` join `v_object` on((`v_object`.`id` = `v_object_template`.`object_id`))) join `tpl_files` on((`tpl_files`.`id` = `v_object_template`.`template_id`))) */;

--
-- Final view structure for view `v_permanent_redirect_edit`
--

/*!50001 DROP TABLE `v_permanent_redirect_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_permanent_redirect_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_permanent_redirect_edit` AS select `permanent_redirect`.`id` AS `id`,`permanent_redirect`.`source_url` AS `source_url`,`permanent_redirect`.`target_url` AS `target_url`,_latin1'' AS `url`,`permanent_redirect`.`page_id` AS `page_id`,`permanent_redirect`.`lang_code` AS `lang_code`,`permanent_redirect`.`t_view` AS `t_view` from `permanent_redirect` */;

--
-- Final view structure for view `v_permanent_redirect_grid`
--

/*!50001 DROP TABLE `v_permanent_redirect_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_permanent_redirect_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_permanent_redirect_grid` AS select `permanent_redirect`.`id` AS `id`,`permanent_redirect`.`source_url` AS `source_url`,`permanent_redirect`.`target_url` AS `target_url`,`permanent_redirect`.`page_id` AS `page_id`,`permanent_redirect`.`lang_code` AS `lang_code`,`permanent_redirect`.`t_view` AS `t_view` from `permanent_redirect` */;

--
-- Final view structure for view `v_search_tpl_pages`
--

/*!50001 DROP TABLE `v_search_tpl_pages`*/;
/*!50001 DROP VIEW IF EXISTS `v_search_tpl_pages`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_search_tpl_pages` AS select `tpl_pages`.`id` AS `id`,`tpl_pages`.`page_name` AS `page_name`,`tpl_pages`.`extension` AS `extension`,`tpl_pages`.`page_description` AS `page_description`,`tpl_pages`.`default_page` AS `default_page`,`tpl_pages`.`create_date` AS `create_date`,`tpl_pages`.`edit_date` AS `edit_date`,`tpl_pages`.`tpl_id` AS `tpl_id`,`tpl_pages`.`folder_id` AS `folder_id`,`tpl_pages`.`for_search` AS `for_search`,`tpl_pages`.`owner_name` AS `owner_name`,`tpl_pages`.`is_locked` AS `is_locked`,`tpl_pages`.`group_access` AS `group_access`,`tpl_pages`.`priority` AS `priority`,`tpl_pages`.`cachable` AS `cachable`,`tpl_pages`.`change_freq` AS `change_freq`,`language`.`language_code` AS `language_code` from ((`tpl_pages` join `tpl_files` on((`tpl_pages`.`tpl_id` = `tpl_files`.`id`))) join `v_language` `language`) where ((`tpl_pages`.`for_search` = _latin1'1') and (`tpl_files`.`type` = 0)) */;

--
-- Final view structure for view `v_styles_edit`
--

/*!50001 DROP TABLE `v_styles_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_styles_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_styles_edit` AS select `styles`.`id` AS `id`,`styles`.`element` AS `element`,`styles`.`class` AS `class`,`styles`.`title` AS `title`,`styles`.`declaration` AS `declaration` from `styles` */;

--
-- Final view structure for view `v_styles_grid`
--

/*!50001 DROP TABLE `v_styles_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_styles_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_styles_grid` AS select `styles`.`id` AS `id`,`styles`.`element` AS `element`,`styles`.`class` AS `class`,`styles`.`title` AS `title`,`styles`.`declaration` AS `sample_text` from `styles` */;

--
-- Final view structure for view `v_tpl_file`
--

/*!50001 DROP TABLE `v_tpl_file`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_file`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_file` AS select `tpl_files`.`id` AS `id`,`tpl_files`.`file_name` AS `file_name`,`tpl_files`.`description` AS `description`,`tpl_files`.`cachable` AS `cachable` from `tpl_files` where (`tpl_files`.`type` = _latin1'0') */;

--
-- Final view structure for view `v_tpl_file_edit`
--

/*!50001 DROP TABLE `v_tpl_file_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_file_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_file_edit` AS select `v_tpl_file`.`id` AS `id`,`v_tpl_file`.`file_name` AS `file_name`,`v_tpl_file`.`description` AS `description`,`v_tpl_file`.`cachable` AS `cachable` from `v_tpl_file` */;

--
-- Final view structure for view `v_tpl_file_grid`
--

/*!50001 DROP TABLE `v_tpl_file_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_file_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_file_grid` AS select `v_tpl_file`.`id` AS `id`,`v_tpl_file`.`file_name` AS `file_name`,`v_tpl_file`.`description` AS `description`,(case `v_tpl_file`.`cachable` when _latin1'1' then _latin1'Yes' else _latin1'No' end) AS `cachable` from `v_tpl_file` */;

--
-- Final view structure for view `v_tpl_folder`
--

/*!50001 DROP TABLE `v_tpl_folder`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_folder`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_folder` AS select `tpl_pages`.`id` AS `id`,`tpl_pages`.`page_name` AS `page_name`,`tpl_pages`.`page_description` AS `page_description`,`tpl_pages`.`default_page` AS `default_page`,`tpl_pages`.`create_date` AS `create_date`,`tpl_pages`.`edit_date` AS `edit_date`,`tpl_pages`.`folder_id` AS `folder_id`,`tpl_pages`.`for_search` AS `for_search`,`tpl_pages`.`owner_name` AS `owner_name`,`tpl_pages`.`is_locked` AS `is_locked` from `tpl_pages` where isnull(`tpl_pages`.`tpl_id`) */;

--
-- Final view structure for view `v_tpl_folder_content`
--

/*!50001 DROP TABLE `v_tpl_folder_content`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_folder_content`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_folder_content` AS select `v_tpl_folder`.`id` AS `id`,if(isnull(`regular_content`.`val`),if(isnull(`default_content`.`val`),`v_tpl_folder`.`page_name`,`default_content`.`val`),`regular_content`.`val`) AS `page_name`,`v_tpl_folder`.`page_description` AS `page_description`,`v_tpl_folder`.`default_page` AS `default_page`,`v_tpl_folder`.`create_date` AS `create_date`,`v_tpl_folder`.`edit_date` AS `edit_date`,`v_tpl_folder`.`folder_id` AS `folder_id`,`v_tpl_folder`.`for_search` AS `for_search`,`v_tpl_folder`.`owner_name` AS `owner_name`,`v_tpl_folder`.`is_locked` AS `is_locked`,`language`.`language_code` AS `language` from (((`v_tpl_folder` join `v_language` `language`) left join `content` `regular_content` on(((`v_tpl_folder`.`id` = `regular_content`.`var_id`) and (`regular_content`.`var` = _utf8'page_name_') and (`regular_content`.`language` = `language`.`language_code`)))) left join `content` `default_content` on(((`v_tpl_folder`.`id` = `default_content`.`var_id`) and (`default_content`.`var` = _utf8'page_name_') and (`default_content`.`language` = (select `language`.`language_code` AS `language_code` from `language` where (`language`.`default_language` = 1)))))) */;

--
-- Final view structure for view `v_tpl_folder_edit`
--

/*!50001 DROP TABLE `v_tpl_folder_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_folder_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_folder_edit` AS select `tpl_pages`.`id` AS `id`,`tpl_pages`.`page_name` AS `page_name`,`tpl_pages`.`page_description` AS `page_description`,`tpl_pages`.`create_date` AS `create_date`,`tpl_pages`.`edit_date` AS `edit_date`,`tpl_pages`.`folder_id` AS `folder_id`,`tpl_pages`.`for_search` AS `for_search`,`tpl_pages`.`owner_name` AS `owner_name`,`tpl_pages`.`is_locked` AS `is_locked`,`tpl_pages`.`group_access` AS `group_access`,_latin1'' AS `folder_groups` from `tpl_pages` where isnull(`tpl_pages`.`tpl_id`) */;

--
-- Final view structure for view `v_tpl_folder_grid`
--

/*!50001 DROP TABLE `v_tpl_folder_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_folder_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_folder_grid` AS select `v_tpl_folder`.`id` AS `id`,concat(_utf8'/',`v_tpl_path_content`.`folder`) AS `folder`,`v_tpl_folder`.`page_description` AS `folder_description`,`v_tpl_folder`.`is_locked` AS `is_locked`,`v_tpl_folder`.`owner_name` AS `owner_name`,(select count(`t`.`id`) AS `count(t.id)` from `tpl_pages` `t` where (`t`.`folder_id` = `v_tpl_folder`.`id`)) AS `items_count`,`v_tpl_path_content`.`language` AS `language` from (`v_tpl_folder` left join `v_tpl_path_content` on((`v_tpl_folder`.`id` = `v_tpl_path_content`.`id`))) */;

--
-- Final view structure for view `v_tpl_non_folder`
--

/*!50001 DROP TABLE `v_tpl_non_folder`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_non_folder`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_non_folder` AS select `p`.`id` AS `id`,`p`.`page_name` AS `page_name`,`p`.`extension` AS `extension`,`p`.`page_description` AS `page_description`,`p`.`default_page` AS `default_page`,`p`.`create_date` AS `create_date`,`p`.`edit_date` AS `edit_date`,`p`.`tpl_id` AS `tpl_id`,`p`.`folder_id` AS `folder_id`,`p`.`for_search` AS `for_search`,`p`.`owner_name` AS `owner_name`,`p`.`is_locked` AS `is_locked`,if((`p`.`tpl_id` = 0),0,`tpl_files`.`type`) AS `type`,if((`p`.`tpl_id` = 0),_latin1'',`tpl_files`.`file_name`) AS `file_name`,`p`.`group_access` AS `group_access`,`p`.`priority` AS `priority`,`p`.`cachable` AS `cachable` from (`tpl_pages` `p` left join `tpl_files` on((`p`.`tpl_id` = `tpl_files`.`id`))) where (`p`.`tpl_id` is not null) */;

--
-- Final view structure for view `v_tpl_non_folder_content`
--

/*!50001 DROP TABLE `v_tpl_non_folder_content`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_non_folder_content`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_non_folder_content` AS select `v_tpl_non_folder`.`id` AS `id`,if(isnull(`regular_content`.`val`),if(isnull(`default_content`.`val`),`v_tpl_non_folder`.`page_name`,`default_content`.`val`),`regular_content`.`val`) AS `page_name`,`v_tpl_non_folder`.`page_description` AS `page_description`,`v_tpl_non_folder`.`default_page` AS `default_page`,`v_tpl_non_folder`.`create_date` AS `create_date`,`v_tpl_non_folder`.`edit_date` AS `edit_date`,`v_tpl_non_folder`.`tpl_id` AS `tpl_id`,`v_tpl_non_folder`.`folder_id` AS `folder_id`,`v_tpl_non_folder`.`for_search` AS `for_search`,`v_tpl_non_folder`.`owner_name` AS `owner_name`,`v_tpl_non_folder`.`is_locked` AS `is_locked`,`v_tpl_non_folder`.`type` AS `type`,`v_tpl_non_folder`.`file_name` AS `file_name`,`language`.`language_code` AS `language`,`v_tpl_non_folder`.`priority` AS `priority` from (((`v_tpl_non_folder` join `v_language` `language`) left join `content` `regular_content` on(((`v_tpl_non_folder`.`id` = `regular_content`.`var_id`) and (`regular_content`.`var` = _utf8'page_name_') and (`regular_content`.`language` = `language`.`language_code`)))) left join `content` `default_content` on(((`v_tpl_non_folder`.`id` = `default_content`.`var_id`) and (`default_content`.`var` = _utf8'page_name_') and (`default_content`.`language` = (select `language`.`language_code` AS `language_code` from `language` where (`language`.`default_language` = 1)))))) */;

--
-- Final view structure for view `v_tpl_non_folder_statistic`
--

/*!50001 DROP TABLE `v_tpl_non_folder_statistic`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_non_folder_statistic`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_non_folder_statistic` AS select `p`.`id` AS `id`,`p`.`page_name` AS `page_name`,`p`.`extension` AS `extension`,`p`.`page_description` AS `page_description`,`p`.`default_page` AS `default_page`,`p`.`create_date` AS `create_date`,`p`.`edit_date` AS `edit_date`,`p`.`tpl_id` AS `tpl_id`,`p`.`folder_id` AS `folder_id`,`p`.`for_search` AS `for_search`,`p`.`owner_name` AS `owner_name`,`p`.`is_locked` AS `is_locked`,`p`.`type` AS `type`,`p`.`file_name` AS `file_name`,`p`.`group_access` AS `group_access`,`p`.`priority` AS `priority`,`p`.`cachable` AS `cachable`,(case (select count(`content`.`page_id`) AS `COUNT(page_id)` from `content` where (((`content`.`val` <> (`content`.`val_draft` collate utf8_bin)) or isnull(`content`.`val`)) and (`content`.`val_draft` is not null) and (`content`.`page_id` = `p`.`id`))) when 0 then _latin1'No' else _latin1'Yes' end) AS `in_draft_state`,(case (select count(`content`.`page_id`) AS `COUNT(page_id)` from `content` where (((`content`.`val` <> (`content`.`val_draft` collate utf8_bin)) or isnull(`content`.`val`)) and (`content`.`page_id` = _latin1'0') and (`content`.`var` = _utf8'page_name_') and (`content`.`var_id` = `p`.`id`) and (`content`.`val_draft` is not null))) when 0 then _latin1'No' else _latin1'Yes' end) AS `is_draft_page`,(select max(`content`.`edit_date`) AS `MAX(content.edit_date)` from `content` where (`content`.`page_id` = `p`.`id`)) AS `publish_date`,(select max(`content`.`edit_date_draft`) AS `MAX(content.edit_date_draft)` from `content` where (`content`.`page_id` = `p`.`id`)) AS `edit_date_draft`,(select `content`.`val` AS `val` from `content` where ((`content`.`var` = _utf8'edit_user') and (`content`.`page_id` = `p`.`id`))) AS `edit_user` from `v_tpl_non_folder` `p` */;

--
-- Final view structure for view `v_tpl_non_folder_without_stat`
--

/*!50001 DROP TABLE `v_tpl_non_folder_without_stat`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_non_folder_without_stat`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_non_folder_without_stat` AS select `tpl_pages`.`id` AS `id`,`tpl_files`.`type` AS `type`,`tpl_files`.`file_name` AS `file_name`,`tpl_pages`.`page_description` AS `page_description`,`tpl_pages`.`group_access` AS `group_access`,`content`.`var` AS `var`,`content`.`var_id` AS `var_id`,`content`.`val` AS `val`,`content`.`language` AS `language`,`language`.`default_language` AS `default_language` from (((`content` left join `tpl_pages` on((`content`.`var_id` = `tpl_pages`.`id`))) join `tpl_files` on((`tpl_pages`.`tpl_id` = `tpl_files`.`id`))) left join `v_language` `language` on((`content`.`language` = `language`.`language_code`))) where ((`content`.`var` = _utf8'folder_path_') or (`content`.`var` = _utf8'page_name_')) */;

--
-- Final view structure for view `v_tpl_page`
--

/*!50001 DROP TABLE `v_tpl_page`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_page`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_page` AS select `v_tpl_non_folder`.`id` AS `id`,`v_tpl_non_folder`.`page_name` AS `page_name`,`v_tpl_non_folder`.`extension` AS `extension`,`v_tpl_non_folder`.`page_description` AS `page_description`,`v_tpl_non_folder`.`default_page` AS `default_page`,`v_tpl_non_folder`.`create_date` AS `create_date`,`v_tpl_non_folder`.`edit_date` AS `edit_date`,`v_tpl_non_folder`.`tpl_id` AS `tpl_id`,`v_tpl_non_folder`.`folder_id` AS `folder_id`,`v_tpl_non_folder`.`for_search` AS `for_search`,`v_tpl_non_folder`.`owner_name` AS `owner_name`,`v_tpl_non_folder`.`is_locked` AS `is_locked`,`v_tpl_non_folder`.`type` AS `type`,`v_tpl_non_folder`.`file_name` AS `file_name`,`v_tpl_non_folder`.`group_access` AS `group_access`,`v_tpl_non_folder`.`priority` AS `priority`,`v_tpl_non_folder`.`cachable` AS `cachable` from `v_tpl_non_folder` where (`v_tpl_non_folder`.`type` = 0) */;

--
-- Final view structure for view `v_tpl_page_content`
--

/*!50001 DROP TABLE `v_tpl_page_content`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_page_content`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_page_content` AS select `v_tpl_non_folder`.`id` AS `id`,if(isnull(`regular_content`.`val`),if(isnull(`regular_content`.`val_draft`),if(isnull(`default_content`.`val`),`v_tpl_non_folder`.`page_name`,`default_content`.`val`),`regular_content`.`val_draft`),`regular_content`.`val`) AS `page_name`,`v_tpl_non_folder`.`page_description` AS `page_description`,`v_tpl_non_folder`.`default_page` AS `default_page`,`v_tpl_non_folder`.`create_date` AS `create_date`,`v_tpl_non_folder`.`edit_date` AS `edit_date`,`v_tpl_non_folder`.`tpl_id` AS `tpl_id`,`v_tpl_non_folder`.`folder_id` AS `folder_id`,`v_tpl_non_folder`.`for_search` AS `for_search`,`v_tpl_non_folder`.`owner_name` AS `owner_name`,`v_tpl_non_folder`.`is_locked` AS `is_locked`,`v_tpl_non_folder`.`type` AS `type`,`v_tpl_non_folder`.`file_name` AS `file_name`,`language`.`language_code` AS `language`,`v_tpl_non_folder`.`group_access` AS `group_access`,`v_tpl_non_folder`.`priority` AS `priority`,`v_tpl_non_folder`.`cachable` AS `cachable` from (((`v_tpl_non_folder` join `v_language` `language`) left join `content` `regular_content` on(((`v_tpl_non_folder`.`id` = `regular_content`.`var_id`) and (`regular_content`.`var` = _utf8'page_name_') and (`regular_content`.`language` = `language`.`language_code`)))) left join `content` `default_content` on(((`v_tpl_non_folder`.`id` = `default_content`.`var_id`) and (`default_content`.`var` = _utf8'page_name_') and (`default_content`.`language` = (select `language`.`language_code` AS `language_code` from `language` where (`language`.`default_language` = 1) limit 0,1))))) where (`v_tpl_non_folder`.`type` = 0) */;

--
-- Final view structure for view `v_tpl_page_detail`
--

/*!50001 DROP TABLE `v_tpl_page_detail`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_page_detail`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_page_detail` AS select `v_tpl_page`.`id` AS `id`,`v_tpl_page`.`page_name` AS `page_name`,`v_tpl_page`.`extension` AS `extension`,`v_tpl_page`.`page_description` AS `page_description`,`v_tpl_page`.`default_page` AS `default_page`,`v_tpl_page`.`create_date` AS `create_date`,`v_tpl_page`.`edit_date` AS `edit_date`,`v_tpl_page`.`tpl_id` AS `tpl_id`,`v_tpl_page`.`folder_id` AS `folder_id`,`v_tpl_page`.`for_search` AS `for_search`,`v_tpl_page`.`owner_name` AS `owner_name`,`v_tpl_page`.`is_locked` AS `is_locked`,`v_tpl_page`.`type` AS `type`,`v_tpl_page`.`file_name` AS `file_name`,`v_tpl_page`.`group_access` AS `group_access`,`v_tpl_page`.`priority` AS `priority`,`v_tpl_page`.`cachable` AS `cachable` from `v_tpl_page` */;

--
-- Final view structure for view `v_tpl_page_edit`
--

/*!50001 DROP TABLE `v_tpl_page_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_page_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_page_edit` AS select `v_tpl_page`.`id` AS `id`,`v_tpl_page`.`page_name` AS `page_name`,`v_tpl_page`.`extension` AS `extension`,`v_tpl_page`.`page_description` AS `page_description`,`v_tpl_page`.`default_page` AS `is_default`,`v_tpl_page`.`tpl_id` AS `template`,`v_tpl_page`.`folder_id` AS `folder`,`v_tpl_page`.`for_search` AS `search`,`v_tpl_page`.`is_locked` AS `page_locked`,`v_tpl_page`.`cachable` AS `cachable` from `v_tpl_page` */;

--
-- Final view structure for view `v_tpl_page_folder`
--

/*!50001 DROP TABLE `v_tpl_page_folder`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_page_folder`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_page_folder` AS select `p`.`id` AS `id`,if(((`p`.`folder_id` is not null) and (`p`.`folder_id` <> 0)),concat(`f`.`page_name`,_utf8' / ',`p`.`page_name`),`p`.`page_name`) AS `page_name`,`p`.`page_description` AS `page_description`,`p`.`default_page` AS `default_page`,`p`.`create_date` AS `create_date`,`p`.`edit_date` AS `edit_date`,`p`.`tpl_id` AS `tpl_id`,`p`.`folder_id` AS `folder_id`,`p`.`for_search` AS `for_search` from (`v_tpl_page` `p` left join `v_tpl_folder` `f` on((`p`.`folder_id` = `f`.`id`))) */;

--
-- Final view structure for view `v_tpl_page_grid`
--

/*!50001 DROP TABLE `v_tpl_page_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_page_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_page_grid` AS select `v_tpl_page_content`.`id` AS `id`,`v_tpl_page_content`.`page_name` AS `page_name`,`v_tpl_page_content`.`page_description` AS `page_description`,concat(`v_tpl_page_content`.`file_name`,_latin1'.tpl') AS `template`,if(isnull(`v_tpl_path_content`.`folder`),_utf8'/',concat(_utf8'/',`v_tpl_path_content`.`folder`)) AS `folder`,`v_tpl_page_content`.`default_page` AS `is_default`,(case `v_tpl_page_content`.`default_page` when 1 then _latin1'Yes' else _latin1'' end) AS `default_page`,(case `v_tpl_page_content`.`for_search` when 1 then _latin1'Yes' else _latin1'' end) AS `for_search`,(case `v_tpl_page_content`.`is_locked` when 1 then _latin1'Yes' else _latin1'No' end) AS `locked`,(case `v_tpl_page_content`.`cachable` when _latin1'1' then _latin1'Yes' else _latin1'No' end) AS `cachable`,`v_tpl_page_content`.`language` AS `language`,`v_st`.`in_draft_state` AS `in_draft_state`,`v_st`.`publish_date` AS `edit_date`,`v_st`.`edit_date_draft` AS `edit_date_draft`,`v_st`.`edit_user` AS `edit_user` from ((`v_tpl_page_content` left join `v_tpl_path_content` on((((`v_tpl_page_content`.`folder_id` = `v_tpl_path_content`.`id`) and (`v_tpl_page_content`.`language` = `v_tpl_path_content`.`language`)) or isnull(`v_tpl_path_content`.`id`)))) join `v_tpl_non_folder_statistic` `v_st` on((`v_tpl_page_content`.`id` = `v_st`.`id`))) */;

--
-- Final view structure for view `v_tpl_page_not_locked`
--

/*!50001 DROP TABLE `v_tpl_page_not_locked`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_page_not_locked`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_page_not_locked` AS select `v_tpl_page`.`id` AS `id`,`v_tpl_page`.`page_name` AS `page_name`,`v_tpl_page`.`extension` AS `extension`,`v_tpl_page`.`page_description` AS `page_description`,`v_tpl_page`.`default_page` AS `default_page`,`v_tpl_page`.`create_date` AS `create_date`,`v_tpl_page`.`edit_date` AS `edit_date`,`v_tpl_page`.`tpl_id` AS `tpl_id`,`v_tpl_page`.`folder_id` AS `folder_id`,`v_tpl_page`.`for_search` AS `for_search`,`v_tpl_page`.`owner_name` AS `owner_name`,`v_tpl_page`.`is_locked` AS `is_locked`,`v_tpl_page`.`type` AS `type`,`v_tpl_page`.`file_name` AS `file_name`,`v_tpl_page`.`group_access` AS `group_access`,`v_tpl_page`.`priority` AS `priority`,`v_tpl_page`.`cachable` AS `cachable` from `v_tpl_page` where (`v_tpl_page`.`is_locked` = 0) */;

--
-- Final view structure for view `v_tpl_path_content`
--

/*!50001 DROP TABLE `v_tpl_path_content`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_path_content`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_path_content` AS select `v_tpl_folder`.`id` AS `id`,if(isnull(`regular_content`.`val`),if(isnull(`regular_content`.`val_draft`),if(isnull(`default_content`.`val`),if(isnull(`default_content`.`val_draft`),`v_tpl_folder`.`page_name`,`default_content`.`val_draft`),`default_content`.`val`),`regular_content`.`val_draft`),`regular_content`.`val`) AS `folder`,`language`.`language_code` AS `language` from (((`v_tpl_folder` join `v_language` `language`) left join `content` `regular_content` on(((`v_tpl_folder`.`id` = `regular_content`.`var_id`) and (`regular_content`.`var` = _utf8'folder_path_') and (`regular_content`.`language` = `language`.`language_code`)))) left join `content` `default_content` on(((`v_tpl_folder`.`id` = `default_content`.`var_id`) and (`default_content`.`var` = _utf8'folder_path_') and (`default_content`.`language` = (select `language`.`language_code` AS `language_code` from `language` where (`language`.`default_language` = 1)))))) */;

--
-- Final view structure for view `v_tpl_views`
--

/*!50001 DROP TABLE `v_tpl_views`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_views`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_views` AS select `tpl_views`.`id` AS `id`,`tpl_views`.`view_name` AS `view_name`,`tpl_views`.`view_folder` AS `view_folder`,`tpl_views`.`description` AS `description`,`tpl_views`.`icon` AS `icon`,`tpl_views`.`is_default` AS `is_default` from `tpl_views` */;

--
-- Final view structure for view `v_tpl_views_edit`
--

/*!50001 DROP TABLE `v_tpl_views_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_views_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_views_edit` AS select `tpl_views`.`id` AS `id`,`tpl_views`.`view_name` AS `view_name`,`tpl_views`.`view_folder` AS `view_folder`,`tpl_views`.`description` AS `description`,`tpl_views`.`icon` AS `icon`,`tpl_views`.`is_default` AS `is_default` from `tpl_views` */;

--
-- Final view structure for view `v_tpl_views_grid`
--

/*!50001 DROP TABLE `v_tpl_views_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_tpl_views_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tpl_views_grid` AS select `tpl_views`.`id` AS `id`,`tpl_views`.`view_name` AS `view_name`,`tpl_views`.`view_folder` AS `view_folder`,`tpl_views`.`description` AS `description`,`tpl_views`.`icon` AS `icon`,`tpl_views`.`is_default` AS `is_default`,(case `tpl_views`.`is_default` when 1 then _latin1'Yes' else _latin1'' end) AS `default_view` from `tpl_views` */;

--
-- Final view structure for view `v_user`
--

/*!50001 DROP TABLE `v_user`*/;
/*!50001 DROP VIEW IF EXISTS `v_user`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user` AS select `users`.`id` AS `id`,`users`.`name` AS `name`,`users`.`login` AS `login`,`users`.`passw` AS `passw`,`users`.`email` AS `email`,`users`.`status` AS `status`,`users`.`role` AS `role`,`users`.`content_access` AS `content_access`,`users`.`comment` AS `comment`,`users`.`icq` AS `icq`,`users`.`city` AS `city`,`users`.`resetpassw` AS `resetpassw`,`users`.`ip` AS `ip`,`users`.`browser` AS `browser`,`users`.`login_datetime` AS `login_datetime`,`users`.`month_visits` AS `month_visits`,`users`.`passw_update_datetime` AS `passw_update_datetime` from `users` */;

--
-- Final view structure for view `v_user_edit`
--

/*!50001 DROP TABLE `v_user_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_user_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_edit` AS select `users`.`id` AS `id`,`users`.`name` AS `name`,`users`.`login` AS `login`,`users`.`email` AS `email`,`users`.`status` AS `status`,`users`.`comment` AS `comment`,`users`.`icq` AS `icq`,`users`.`city` AS `city`,_latin1'' AS `change_password`,_latin1'' AS `old_password`,_latin1'' AS `new_password`,_latin1'' AS `confirm_new_password`,_latin1'' AS `currently`,`users`.`ip` AS `ip`,`users`.`browser` AS `browser`,date_format(`users`.`login_datetime`,_latin1'%d-%m-%Y %H:%i') AS `last_login`,`users`.`month_visits` AS `month_visits`,_latin1'' AS `user_groups`,`users`.`role` AS `role`,`users`.`content_access` AS `content_access` from `users` */;

--
-- Final view structure for view `v_user_grid`
--

/*!50001 DROP TABLE `v_user_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_user_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_grid` AS select `users`.`id` AS `id`,`users`.`name` AS `name`,`users`.`login` AS `login`,`users`.`email` AS `email`,(case `users`.`status` when 0 then _latin1'Disabled' when 1 then _latin1'Enabled' end) AS `status`,`users`.`role` AS `role`,(select `role`.`role_name` AS `role_name` from `role` where (`role`.`id` = `users`.`role`)) AS `role_name`,(select group_concat(`user_groups`.`group_name` separator ', ') AS `GROUP_CONCAT(user_groups.group_name SEPARATOR ', ')` from (`user_group` left join `user_groups` on((`user_groups`.`id` = `user_group`.`group_id`))) where (`user_group`.`user_id` = `users`.`id`) group by `user_group`.`user_id`) AS `groups` from `users` */;

--
-- Final view structure for view `v_user_groups`
--

/*!50001 DROP TABLE `v_user_groups`*/;
/*!50001 DROP VIEW IF EXISTS `v_user_groups`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_groups` AS select `user_groups`.`id` AS `id`,`user_groups`.`group_name` AS `group_name`,`user_groups`.`group_code` AS `group_code` from `user_groups` */;

--
-- Final view structure for view `v_user_groups_edit`
--

/*!50001 DROP TABLE `v_user_groups_edit`*/;
/*!50001 DROP VIEW IF EXISTS `v_user_groups_edit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_groups_edit` AS select `user_groups`.`id` AS `id`,`user_groups`.`group_name` AS `group_name`,`user_groups`.`group_code` AS `group_code` from `user_groups` */;

--
-- Final view structure for view `v_user_groups_grid`
--

/*!50001 DROP TABLE `v_user_groups_grid`*/;
/*!50001 DROP VIEW IF EXISTS `v_user_groups_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_groups_grid` AS select `user_groups`.`id` AS `id`,`user_groups`.`group_name` AS `group_name`,`user_groups`.`group_code` AS `group_code` from `user_groups` */;

--
-- Final view structure for view `v_user_profile`
--

/*!50001 DROP TABLE `v_user_profile`*/;
/*!50001 DROP VIEW IF EXISTS `v_user_profile`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_profile` AS select `users`.`id` AS `id`,`users`.`name` AS `name`,`users`.`email` AS `email`,_latin1'' AS `change_password`,_latin1'' AS `old_password`,_latin1'' AS `new_password`,_latin1'' AS `confirm_new_password` from `users` */;

--
-- Final view structure for view `vbrowser_grid`
--

/*!50001 DROP TABLE `vbrowser_grid`*/;
/*!50001 DROP VIEW IF EXISTS `vbrowser_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vbrowser_grid` AS select `v_tpl_page_grid`.`id` AS `id`,`v_tpl_page_grid`.`page_name` AS `page_name`,`v_tpl_page_grid`.`page_description` AS `page_description`,`v_tpl_page_grid`.`template` AS `template`,`v_tpl_page_grid`.`folder` AS `folder`,`v_tpl_page_grid`.`is_default` AS `is_default`,`v_tpl_page_grid`.`default_page` AS `default_page`,`v_tpl_page_grid`.`for_search` AS `for_search`,`v_tpl_page_grid`.`locked` AS `locked`,`v_tpl_page_grid`.`cachable` AS `cachable`,`v_tpl_page_grid`.`language` AS `language`,`v_tpl_page_grid`.`in_draft_state` AS `in_draft_state`,`v_tpl_page_grid`.`edit_date` AS `edit_date`,`v_tpl_page_grid`.`edit_date_draft` AS `edit_date_draft`,`v_tpl_page_grid`.`edit_user` AS `edit_user` from `v_tpl_page_grid` */;

--
-- Final view structure for view `vmbrowser_grid`
--

/*!50001 DROP TABLE `vmbrowser_grid`*/;
/*!50001 DROP VIEW IF EXISTS `vmbrowser_grid`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`t1user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vmbrowser_grid` AS select `v_media_grid`.`id` AS `id`,`v_media_grid`.`media_name` AS `media_name`,`v_media_grid`.`media_description` AS `media_description`,`v_media_grid`.`template` AS `template`,`v_media_grid`.`folder` AS `folder`,`v_media_grid`.`edit_date` AS `edit_date`,`v_media_grid`.`cachable` AS `cachable`,`v_media_grid`.`in_draft_state` AS `in_draft_state`,`v_media_grid`.`language` AS `language` from `v_media_grid` */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-04-08 14:14:26
